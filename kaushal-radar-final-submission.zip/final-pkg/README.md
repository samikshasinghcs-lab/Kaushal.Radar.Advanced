# Kaushal Radar - final submission code (KSISU Skillathon 2026 finale)

> **Repository layout note:** GitHub's phone upload flattened the folders, so run the code from the structured package `kaushal-radar-final.zip` (unzip, `pip install -r requirements.txt`, `python run_all.py`). Files here are the same code without folders.

Route decisions, not rankings. A decision-support prototype for Karnataka's labour-market intelligence: where to look, how sure we are, and no capacity decision until independent evidence agrees. **Nothing here is a government deployment and no department link is live.**

## Run everything
```
pip install -r requirements.txt
python run_all.py          # tests + AI evaluation + demos + regenerates reports/   (about 1 minute)
```

## Layout
| Folder | What | Data |
|---|---|---|
| `core/` | DGPI indicators, decision engine + Corroboration Gate, hash-chained ledger, reliability pipeline, RBAC/security, local API, **departmental file ingestion (`ingest.py`)** | **Real**: Yuvanidhi, GDDP/PCI, MSME (DES Karnataka) in `indicators_v2.csv`. Gate evidence cards other than Yuva Nidhi are MOCK and labelled |
| `ai_layer/` | Token-authenticated AI decision-support pipeline: retrieval, deterministic engine, contradiction/stale/denominator checks, AI analysts, source grounding, numeric guard, hallucination guard, decision gate, human review, audit; 141-case evaluation lab | **Synthetic** evidence; deterministic mock provider (not a language model) |
| `dashboard/` | Dashboard prototype (open `Kaushal_Radar_Dashboard_v0_5_final.html`; the generated `Kaushal_Radar_Dashboard.html` is the earlier build) | Real data; ledger is browser-local |
| `data/` | Indicator table and **synthetic** sample departmental uploads (good, PII, schema drift) | see file names |
| `reports/` | Auto-generated evidence: AI evaluation, security, scalability, traceability, denominators, two-district routing; usability and corroboration are protocols marked NOT RUN | generated |
| `docs/` | OpenAPI v0.1 and data contract (proposed, not deployed) | - |

## Status (what is and is not claimed)
| Claim | Status |
|---|---|
| DGPI on 31 districts, denominator sensitivity | Built, reproducible |
| Corroboration Gate, ledger, rank stability | Built; non-Yuva-Nidhi evidence is mock |
| Departmental upload -> validate -> harmonise -> store -> evidence card -> retrieve | Built and tested on SYNTHETIC sample files |
| AI layer on Raichur question, citations, numeric check, contradiction, abstention, failure handling | Built; run on SYNTHETIC evidence with a mock provider |
| Live LLM evaluation | The Anthropic adapter exists but was never run live here; the 31 real LLM drafts were checked in `core/llm_brief_test.py` |
| Security tests | Automated; core API auth is a **header stub**, not production auth; no independent pen-test |
| AISHE, PLFS, NCS, ITI/NCVT, EPFO, e-Shram | **PROPOSED only. Not ingested.** |
| Usability test with real users | **NOT RUN** (protocol in `reports/USABILITY_REPORT.md`) |
| Independent corroboration of district signals | **NOT DONE** beyond a second denominator |

## Changes since the first submission
See `docs/CHANGES_SINCE_SUBMISSION.md`: brief checker rank check (65/69 -> 69/69, tuned on the same set, NOT held-out), API backlog and caching fix, concurrency test, routing scatter and seat-allocation note in `analysis/`.

## Not yet done (do not claim)
Blind adversarial test set; live-LLM run on all 31 districts; rules-only vs rules+AI comparison; user test with SUS; independent security/DPIA review; any officer conversation or department agreement.

## Known defects (kept visible on purpose)
- Prompt-injection detector is heuristic: 2 of 10 adversarial cases (paraphrase, Hinglish) are not caught.
- `evidence_analyst@1.1.0` regresses 15 evaluation cases; do not promote it.
- Truncating the newest audit entries is not detected without an external anchor.
- `core/analysis_denominators_and_ai_tests.py` and `core/llm_brief_test.py` need the raw source CSVs from the public GitHub repository.
- The `Kaushal-Radar-main` ChatGPT-built code was reviewed and not merged: its modules are small stubs that duplicate stronger ones here.

## v0.3 status
Labels: BUILT_WITH_LIMITATIONS, SYNTHETIC_DEMONSTRATION, PROPOSED, BLOCKED_PENDING_DATA, NOT_RUN (needs a human, a live run or outside access).

| Area | Capability | Status |
|---|---|---|
| Data | AISHE 2023-24 official workbook, state level, tested on the real file (cell provenance, header-drift guard) | BUILT_WITH_LIMITATIONS |
| Data | PLFS Karnataka benchmarks with source URLs (2.3% is secondary-sourced; male/female rows UNVERIFIED) | BUILT_WITH_LIMITATIONS |
| Core | Two-sided matrix, 12 flags (2 on real data, 9 need feeds), intervention cards, human gate | BUILT_WITH_LIMITATIONS |
| Core | Corroboration Gate for every engine; ACTION needs CORROBORATED, self-declared evidence never counts | BUILT_WITH_LIMITATIONS |
| Core | Back-test (needs 2 periods: INSUFFICIENT_DATA on real data today), fairness check, forecasting guard | BUILT_WITH_LIMITATIONS |
| Core | Taluk code path (parser, LGD sub-district codes, k<10 suppression) | SYNTHETIC_DEMONSTRATION (no real taluk source) |
| API | Signed tokens (stub off when KR_JWT_SECRET set), rate limit, lockout, /flags /two-sided /interventions /forecast /pulse /fairness, OpenAPI v0.3, Postman, Swagger page | BUILT_WITH_LIMITATIONS |
| Scale | Idempotent refresh, job queue (retry, dead-letter), backup/restore with manifest, Postgres schema and SQL generator | BUILT; Postgres NOT_RUN |
| Security | Secret scan (runs in CI and in tests), pip-audit in CI, ZAP workflow | Secret scan BUILT; ZAP NOT_RUN |
| AI | Injection patterns (paraphrase, Hinglish); evidence_analyst@1.1.0 regression fixed (35/35); labour/skills/inclusion claim checker 40 cases (held-out 6/10) | BUILT_WITH_LIMITATIONS |
| AI | Kannada/Hindi/Hinglish keyword understanding (draft vocabulary) | BUILT_WITH_LIMITATIONS; native review NOT_RUN |
| AI | Live LLM on 31 districts, blind adversarial set, rules vs rules+AI | NOT_RUN |
| Dashboard | 19 views with real AISHE and PLFS benchmarks | BUILT_WITH_LIMITATIONS |
| Human only | Usability test, independent security review, officer agreement | NOT_RUN |

Commands: `python run_all.py --tests-only`, `python core/build_dashboard.py [--check]`, `python core/gen_api_docs.py`, `python core/secret_scan.py .`.
Tokens: `KR_JWT_SECRET=<16+ bytes> python core/auth_tokens.py issue USER ROLE [DISTRICT]`.

## Final submission notes (2 Nov 2026)
- Brief-checker result on the 31 genuine LLM drafts, as shipped in `core/ai_eval.py`: **27 auto-pass, 1 review, 3 false rejects**; 69/69 injected errors caught (checker tuned on the same set, NOT held-out).
- Scalability (`reports/SCALABILITY_REPORT.md`, synthetic data, one machine): 1M rows 0.34 s median, 5M rows 1.72 s median.
- Data: two public datasets are loaded as static snapshots (Yuva Nidhi, DES MSME). **No live departmental feed exists.** Everything else is PROPOSED; pulse and skills views are SYNTHETIC.
- 98.5% degree holders refers to Yuva Nidhi registrants in this dataset, not Karnataka's workforce; it is why that cohort alone should not drive ITI planning.
- Not claimed: full DPDP compliance, production readiness, live government integration, AI accuracy from synthetic tests.
- Reproduce: `pip install -r requirements.txt && python run_all.py`
