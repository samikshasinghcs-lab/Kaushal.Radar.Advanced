# skills
No real observations are stored here yet. Place source files via adapters/ with provenance. Never add invented values. Status: BLOCKED_PENDING_DATA
