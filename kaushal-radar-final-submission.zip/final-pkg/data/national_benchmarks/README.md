# national_benchmarks
Real, sourced, STATE-LEVEL values only (see ../education/AISHE_Final_Report_2023-24.xlsx and ../labour_market/plfs_karnataka_claims.csv).
No district value is derived from any of these. Status per row is in the CSV.
