"""One command: runs every test suite, the AI evaluation lab, both demos and regenerates all reports.   python run_all.py [--tests-only]"""
import subprocess, sys, os, re
R = os.path.dirname(os.path.abspath(__file__)); C, A = os.path.join(R, "core"), os.path.join(R, "ai_layer"); fails = []
def run(name, cmd, cwd):
    p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True); out = p.stdout + p.stderr; m = re.search(r"Ran (\d+) tests?", out)
    ok = p.returncode == 0; print(f"{'PASS' if ok else 'FAIL'}  {name}" + (f"  ({m.group(1)} tests)" if m else "")); 
    if not ok: fails.append(name); print(out[-1500:])
for t in ("test_engine", "test_pipeline", "test_security", "test_api", "test_audit_tamper", "test_ingest", "test_labour_intelligence", "test_v02_modules", "test_scale_and_injection", "test_real_files", "test_store", "test_v03_modules", "test_api_v03", "test_ai_eval_labour", "test_architecture", "test_dashboard_sync"): run("core/" + t, [sys.executable, t + ".py"], C)
run("ai_layer all tests", [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-t", "."], A)
if "--tests-only" not in sys.argv:
    run("ai_layer evaluation lab (141 labelled cases)", [sys.executable, "-m", "evaluation.runner"], A)
    run("ai_layer Raichur officer-journey demo", [sys.executable, "-m", "demo.run_demo"], A)
    run("core API flow (demo_flow.py)", [sys.executable, "demo_flow.py"], C); run("API concurrency test (load_test.py)", [sys.executable, "load_test.py"], C); run("brief checker eval (ai_eval.py)", [sys.executable, "ai_eval.py"], C); run("departmental ingestion demo", [sys.executable, "ingest_demo.py"], C)
    run("regenerate reports/", [sys.executable, os.path.join("tools", "make_reports.py")], R)
print("\nALL GREEN" if not fails else "\nFAILED: " + ", ".join(fails)); sys.exit(1 if fails else 0)
