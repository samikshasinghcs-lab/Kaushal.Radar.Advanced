"""Evaluation of the claim checker for LABOUR, SKILLS and INCLUSION statements. Labelled cases are written by the project team (synthetic text, not model output).
Reports accuracy and every miss. A perfect score on a small hand-written set is NOT evidence of robustness."""
import re, json
RULES = [  # (code, regex, message) -> statement is REJECTED if any matches
 ("JOBS_FROM_REGISTRATION", r"\b(new (companies|firms|registrations|enterprises)|registrations?)\b.{0,60}\b(created|generated|added|produced)\b.{0,20}\bjobs?\b", "registration is not a job"),
 ("NATIONAL_AS_LOCAL", r"\b(national|all-india|india-wide)\b.{0,60}\b(proves?|shows?|means?)\b.{0,40}\b(this|the) district\b", "national trend is not local demand"),
 ("INDIVIDUAL_TARGETING", r"\b(identified|targeted|listed)\b.{0,30}\b(individual|named|specific)\b.{0,20}\b(workers?|persons?|people|beneficiar\w*)|\btargeted named beneficiar", "no individual targeting"),
 ("LIVE_ANNUAL", r"\b(real-time|live|up-to-the-minute|today's)\b.{0,50}\b(unemployment|vacanc\w*|employment rate|labour conditions)", "annual or survey data is not live"),
 ("CAUSAL_FLAG", r"\b(caused|caused by|because of|due to|resulted from)\b.{0,40}\b(unemployment|pressure|low income|weak enterprise|flag)\b|\bflag\b.{0,20}\b(proves|confirms)\b|confirmed by the flag", "flags are signals, not causes"),
 ("CODING_FOR_ALL", r"\b(everyone|all workers|every worker|all unemployed)\b.{0,40}\b(learn|needs?|should)\b.{0,20}\b(coding|programming|AI|python)\b", "do not assume everyone needs advanced digital skills"),
 ("DISTRICT_FROM_STATE", r"\bso the district (rate|figure|value)\b|\bmatching the (PLFS )?state estimate\b", "district value derived from state estimate"),
 ("AUTO_ACTION", r"\b(automatically|auto-)\b.{0,40}\b(allocat\w*|releas\w*|sanction\w*|approv\w*|enrol\w*)\b", "no automatic government action"),
 ("IMPACT_UNMEASURED", r"\b(reduced|improved|raised|increased)\b.{0,60}\b(by \d|after (the )?(pilot|intervention|scheme))|\b(intervention|scheme|pilot) worked\b", "no impact claim without measurement"),
 ("PROVED_SKILL_OBSOLESCENCE", r"\b(will become obsolete|will disappear|will vanish)\b.{0,30}\b(by|in) \d", "no precise obsolescence prediction")]
OK = [
 "Raichur has a high graduate registration signal per 1,000 residents under the implied population; this needs investigation.",
 "Registrations are shown separately from vacancies and hires, and hiring is not yet linked.",
 "PLFS gives a state-level estimate for Karnataka; no district estimate is derived from it.",
 "The pathway starts with an oral assessment in the local language and foundational literacy.",
 "AISHE 2023-24 reports Karnataka GER at 41.92 percent, a state-level figure.",
 "This flag is a decision-support signal and does not establish a cause.",
 "A department officer must approve before any action is taken.",
 "Annual data from DES Karnataka 2025-26; not a live measure.",
 "Skills trends in the WEF report describe national direction; local employer evidence is still needed.",
 "Women outside the workforce may need local-hours work options and safe transport; this is a hypothesis to test in a pilot.",
 "Placement and six-month retention will be measured after the pilot; no impact is claimed yet.",
 "Workers with outdated skills can be assessed through recognition of prior learning before bridge training.",
 "The High-GDP Labour Risk flag asks whether wages and job quality match output.",
 "Missing district wage data is reported as unavailable, not estimated.",
 "Company registrations from MCA are kept separate from Udyam MSME records.",
 "Cells with fewer than 10 people are suppressed.",
 "The forecast is withheld because fewer than eight data points exist.",
 "The comparison uses the same unit, geography and period.",
 "Jobseeker-to-vacancy ratio is not shown because vacancy counts are below the reporting threshold.",
 "Kalyana-Karnataka districts show a higher share of high-pressure flags; review is required before interpretation."]
BAD = [
 "New company registrations created 4,000 jobs in Mysuru last year.",
 "Real-time unemployment in Raichur is 3.1 percent today.",
 "National data shows this district needs data entry training.",
 "We identified specific individual workers in Koppal who should be enrolled.",
 "The flag proves that low income caused the unemployment in Yadgir.",
 "Everyone should learn coding to stay employed.",
 "Funds will be automatically released to the flagged districts.",
 "The pilot reduced unemployment by 12 percent after the intervention.",
 "Data entry jobs will become obsolete by 2028 in Hassan.",
 "Live vacancies across all employers in Bidar show strong demand.",
 "Unemployment in Ballari is 2.3 percent, matching the PLFS state estimate, so the district rate is 2.3.",
 "Registrations generated jobs, so the jobs-per-company ratio is 12.",
 "Real-time labour conditions are now monitored for every district.",
 "The scheme will automatically enrol eligible workers.",
 "Employment improved by 8 percent after the scheme in Dharwad.",
 "All workers need Python to remain employable.",
 "Karnataka's wage trend is because of weak enterprise activity, confirmed by the flag.",
 "The system targeted named beneficiaries in each taluk.",
 "National trends prove the skill gap exists in this district.",
 "Today's unemployment figures show the intervention worked."]

HELD_OUT = [  # written AFTER the rules were frozen; never used to tune them
 ("Registrations are low in Gadag, which may reflect migration rather than satisfaction with jobs.", "ACCEPT"),
 ("AISHE shows Karnataka has 68.8 colleges per lakh people aged 18-23; this is a state-level figure.", "ACCEPT"),
 ("The officer returned the card because corroboration was missing.", "ACCEPT"),
 ("Retraining of outdated-skill workers is proposed and needs department data on eligible counts.", "ACCEPT"),
 ("A district-level wage estimate is not available and is shown as missing.", "ACCEPT"),
 ("Hiring at newly opened firms has lifted employment in Tumakuru this quarter.", "REJECT"),
 ("Unemployment in Kolar is currently 1.9 percent according to our live dashboard.", "REJECT"),
 ("The model recommends that the department should enrol the workers it has flagged by name.", "REJECT"),
 ("Poor wages in Udupi are explained by the flag, which confirms weak demand.", "REJECT"),
 ("Karnataka's female participation proves each taluk is performing well.", "REJECT")]
def check(text): return [(c, m) for c, rx, m in RULES if re.search(rx, text, re.I)]
def run():
    cases = [(t, "ACCEPT") for t in OK] + [(t, "REJECT") for t in BAD]; res = []
    for t, exp in cases:
        hits = check(t); got = "REJECT" if hits else "ACCEPT"; res.append(dict(text=t, expected=exp, got=got, passed=got == exp, rules=[h[0] for h in hits]))
    ho = [(t, e, "REJECT" if check(t) else "ACCEPT") for t, e in HELD_OUT]; ho_miss = [(t, e) for t, e, g in ho if g != e]
    miss = [r for r in res if not r["passed"]]
    return {"n": len(res), "passed": len(res) - len(miss), "accuracy": round((len(res) - len(miss)) / len(res), 3), "misses": miss, "held_out": {"n": len(ho), "passed": len(ho) - len(ho_miss), "misses": ho_miss}, "labelled_by": "project team (synthetic)", "blind": False,
            "caveat": "Rules were widened after the first run exposed 5 misses on this same set, so this score is optimistic. Small hand-written set; rules written by the same team. Not a measure of real-world accuracy."}
if __name__ == "__main__": print(json.dumps(run(), indent=1)[:1500])
