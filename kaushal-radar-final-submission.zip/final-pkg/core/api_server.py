"""Kaushal Radar API prototype (stdlib only). Local demo of the draft OpenAPI spec: indicators, corroboration gate, decision ledger, audit.
Real data: indicators_v2.csv (DES Karnataka tables). Gate evidence for 'low_vacancy' / 'high_vacancy' scenarios is MOCK and labelled so.
Auth: signed bearer tokens (auth_tokens.py) are required whenever KR_JWT_SECRET is set. Only when it is NOT set (local demo/tests) the legacy header stub (X-User, X-Role, X-District) is accepted.
Production still needs State SSO and key management."""
import json, os, threading, http.server, urllib.parse, functools, csv
import auth_tokens as AT, labour_intelligence as L, intervention_engine as IE, corroboration as C, forecasting as FC, flag_engine as FE, fairness as FR, logging_util as LG
import pandas as pd
import decision_engine as E, security as S, ingest as I

DF = pd.read_csv("indicators_v2.csv").set_index("key")
REG = DF["Grand Total"].to_dict(); DEN = DF["implied_pop"].to_dict()
RANKS = E.ranks(E.dgpi(REG, DEN)); STORE = S.AuditedStore()
LIM = AT.Limiter(max_req=int(os.environ.get("KR_RATE_LIMIT", "300")), window=60, max_fail=5, lock=300)
ENG = IE.Engine(); FLAGS = [f for f in L.all_flags() if f["track"] != "ALL"]; CARDS = {ENG.draft(f): f for f in FLAGS}
KEY2NAME = {k: DF.loc[k, "District"] for k in DF.index}

@functools.lru_cache(maxsize=64)
def _stab(key): return E.rank_stability(REG, DEN, key, draws=500)   # seeded and data is static, so cache per district

def gate_for(key, scenario="real"):
    cards = {"graduate_demand": E.card("graduate_demand", "Yuva Nidhi 2025 (real)", 1, True, 2025, mock=False)}
    if scenario in ("low_vacancy", "high_vacancy"): cards = E.mock_cards(scenario)
    stab = _stab(key)
    g = E.gate(key, RANKS[key] <= 8, stab, cards); g["evidence_is_mock"] = scenario != "real"; return g

class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def send(self, code, obj):
        b = json.dumps(obj).encode(); self.send_response(code); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def who(self):
        a = self.headers.get("Authorization", "")
        if a.startswith("Bearer "):
            try: c = AT.verify(a[7:]); return c["sub"], c["role"], c.get("district")
            except (PermissionError, ValueError, KeyError) as e:
                LIM.failure(self.client_address[0]); LG.log("auth_failed", reason=str(e)); return "invalid-token", "", None
        if os.environ.get("KR_JWT_SECRET"): return "anonymous", "", None            # secret configured: header stub is OFF
        return self.headers.get("X-User", "anonymous"), self.headers.get("X-Role", ""), self.headers.get("X-District")
    def limited(self):
        if LIM.allow(self.client_address[0]): return False
        self.send(429, {"error": "rate_limited_or_locked"}); return True
    def auth(self, action, district=None):
        u, r, ud = self.who()
        try: STORE.access(u, r, action, district, ud); return True
        except PermissionError as e: self.send(403, {"error": "forbidden", "detail": str(e)}); return False
    def do_GET(self):
        if self.limited(): return
        p = urllib.parse.urlparse(self.path); parts = [x for x in p.path.split("/") if x]; q = urllib.parse.parse_qs(p.query)
        if parts == ["health"]: return self.send(200, {"ok": True})
        if parts == ["audit"]:
            if not self.auth("read_audit"): return
            return self.send(200, {"chain_valid": STORE.ledger.verify(), "entries": len(STORE.ledger.rows), "last": STORE.ledger.rows[-3:]})
        if len(parts) == 4 and parts[0] == "ingest" and parts[2] == "evidence-card":
            if not self.auth("read_evidence"): return
            try: card = I.evidence_card(parts[1], int(parts[3]))
            except ValueError: return self.send(400, {"error": "district code must be an integer"})
            return self.send(200 if card and "error" not in card else 404, card or {"error": "unknown upload"})
        if len(parts) == 3 and parts[0] == "districts" and parts[1] in DF.index:
            k = parts[1]
            if parts[2] == "indicators":
                if not self.auth("read_indicators", k): return
                r = DF.loc[k]; return self.send(200, {"district": k, "dgpi_implied": round(float(r.dgpi_per_1000), 2), "dgpi_census2011": round(float(r.dgpi_census), 2),
                    "rank_implied": int(r.rank_implied), "rank_census": int(r.rank_census), "cohort_note": "Yuva Nidhi 2022-23 cohort; registration signal, not unemployment"})
            if parts[2] == "gate":
                if not self.auth("read_routing", k): return
                return self.send(200, gate_for(k, q.get("scenario", ["real"])[0]))
        if parts and parts[0] in ("flags", "two-sided", "interventions", "forecast", "benchmarks", "pulse", "fairness"): return self.v03(parts, q)
        self.send(404, {"error": "not found"})
    def v03(self, parts, q):
        d = q.get("district", [None])[0]
        if d is not None and d not in DF.index: return self.send(400, {"error": "unknown district"})
        if not self.auth("read_routing", d): return                      # district officers must name their own district; listing all is denied
        if parts == ["flags"]:
            fl = [f for f in FLAGS if (d is None or f["district"] == KEY2NAME[d]) and (not q.get("flag") or f["flag"] == q["flag"][0])]
            return self.send(200, {"flags": fl, "count": len(fl), "note": "decision-support signals, not proof of cause; annual data, not live"})
        if parts == ["two-sided"]:
            t = L.two_sided(L.load()); return self.send(200, {k: v for k, v in t.items() if d in (None, k)})
        if parts == ["interventions"]:
            return self.send(200, {"cards": [c for i, c in ENG.cards.items() if d is None or c["district"] == KEY2NAME[d]], "note": "drafts; human approval required"})
        if parts == ["forecast"]:
            return self.send(200, FC.forecast([float(x) for x in q.get("series", [""])[0].split(",") if x] or []))
        if parts == ["benchmarks", "state"]: return self.send(200, {"status": "BUILT_WITH_LIMITATIONS", "level": "state", "source_file": "data/national_benchmarks + data/education", "note": "state level only; never derived to districts"})
        if parts == ["pulse"]: return self.send(200, L.pulse_sample())
        if parts == ["fairness"]: return self.send(200, FR.check())
        self.send(404, {"error": "not found"})
    def do_POST(self):
        if self.limited(): return
        if self.path == "/interventions/decision":
            n = int(self.headers.get("Content-Length", 0)); b = json.loads(self.rfile.read(n) or b"{}"); cid = b.get("id")
            if cid not in ENG.cards: return self.send(404, {"error": "unknown card"})
            dk = next((k for k, v in KEY2NAME.items() if v == ENG.cards[cid]["district"]), None)
            if not self.auth("decide", dk): return
            u, r, _ = self.who(); ev = b.get("evidence") or []
            g = C.gate("two_sided", [e for e in ev if isinstance(e, dict)])        # evidence is judged by the gate; self-declared items are ignored
            try: card = ENG.decide(cid, u, r, b.get("decision", ""), gate=g)
            except PermissionError as e: return self.send(409, {"error": "gate_or_role_blocked", "detail": str(e), "gate": g})
            except ValueError as e: return self.send(400, {"error": str(e)})
            return self.send(201, {"card": card, "gate": g, "chain_valid": ENG.ledger.verify()})
        if self.path.startswith("/ingest"):
            if not self.auth("ingest"): return
            n = int(self.headers.get("Content-Length", 0))
            if n > 20_000_000: return self.send(413, {"error": "file too large"})
            u, r, _ = self.who(); q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            res = I.ingest_csv(self.rfile.read(n), q.get("source", ["unnamed department feed"])[0], int(q.get("ref_year", ["2025"])[0]), u)
            STORE.ledger.record(u, r, "INGEST_" + ("ACCEPTED" if res["accepted"] else "REJECTED"), {k: res.get(k) for k in ("upload_id", "stage", "reason")})
            return self.send(201 if res["accepted"] else 422, res)
        if self.path != "/ledger": return self.send(404, {"error": "not found"})
        n = int(self.headers.get("Content-Length", 0)); body = json.loads(self.rfile.read(n) or b"{}")
        k = body.get("district")
        if k not in DF.index: return self.send(400, {"error": "unknown district"})
        if not self.auth("decide", k): return
        u, r, _ = self.who(); g = gate_for(k, body.get("scenario", "real"))
        try: STORE.ledger.human_decision(g, u, r, body.get("decision", ""), body.get("note", ""))
        except PermissionError as e: return self.send(409, {"error": "gate_blocked", "detail": str(e), "gate": g})
        except ValueError as e: return self.send(400, {"error": str(e)})
        self.send(201, {"logged": True, "gate_status": g["status"], "chain_valid": STORE.ledger.verify()})

class Srv(http.server.ThreadingHTTPServer):
    request_queue_size = 256; daemon_threads = True   # default backlog of 5 refused bursts of concurrent clients

def serve(port=0, host="127.0.0.1"):
    srv = Srv((host, port), H); threading.Thread(target=srv.serve_forever, daemon=True).start(); return srv
if __name__ == "__main__":
    s = serve(8000, os.environ.get("KR_HOST", "127.0.0.1")); print("Kaushal Radar API on port 8000 (Ctrl-C to stop)"); threading.Event().wait()
