"""MCA company records and Udyam MSME records are different universes. They are never merged without a reconciliation record."""
def ratio(a, b):
    if a["source"] != b["source"]: raise ValueError(f"refusing to combine {a['source']} with {b['source']}: definitions and coverage differ")
    return None if not b["value"] else round(a["value"] / b["value"], 3)
def survival(opened, still_active):
    return None if opened in (None, 0) or still_active is None else round(still_active / opened, 3)   # needs verified closures, not registrations
def jobs_per_new_company(new_companies, linked_hires):
    return None if linked_hires is None else round(linked_hires / new_companies, 2)   # blank without a linked hiring series
