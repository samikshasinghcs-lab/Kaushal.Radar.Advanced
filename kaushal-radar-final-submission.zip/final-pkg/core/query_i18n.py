"""English / Kannada / Hindi / Hinglish question understanding for the dashboard question box. Keyword intents only, no translation model.
DRAFT vocabulary: needs review by native speakers. Unknown input abstains. Python source of truth; the dashboard embeds the same map."""
import re, unicodedata
FLAG_TERMS = {
 "Employment Pressure": ["employment pressure", "unemployment", "jobless", "berozgari", "berozgaari", "बेरोज़गारी", "बेरोजगारी", "nirudyoga", "ನಿರುದ್ಯೋಗ", "ಉದ್ಯೋಗ ಒತ್ತಡ", "kam naukri"],
 "High-GDP Labour Risk": ["high gdp", "high income", "rich district", "amir zila", "ज़्यादा आय", "ಹೆಚ್ಚು ಆದಾಯ", "hecchu adaya", "zyada income", "ಶ್ರೀಮಂತ ಜಿಲ್ಲೆ"],
 "Evidence Gap": ["evidence gap", "missing data", "data nahi", "डेटा नहीं", "mahiti illa", "ಮಾಹಿತಿ ಇಲ್ಲ"],
 "Growth Opportunity": ["growth", "badhat", "बढ़त", "belavanige", "ಬೆಳವಣಿಗೆ"]}
INTENT_ASK = ["which", "list", "show", "kaun", "kaunse", "कौन", "कौनसे", "yaava", "ಯಾವ", "ತೋರಿಸು", "dikhao", "दिखाओ"]
INJECT = re.compile(r"(ignore|skip|bypass|bhool|nazarandaz|ನಿರ್ಲಕ್ಷಿಸು).{0,30}(rule|instruction|review|gate|niyam|nirdesh|ನಿಯಮ)|approve.{0,15}(fund|kar do)|manzoor kar do", re.I)
def norm(s): return unicodedata.normalize("NFC", s).lower().strip()
def understand(q, district_names):
    q = norm(q)
    if INJECT.search(q): return {"intent": "REFUSE", "why": "attempt to bypass rules or review"}
    for name in district_names:
        if norm(name) in q: return {"intent": "DISTRICT", "district": name}
    for flag, terms in FLAG_TERMS.items():
        if any(norm(t) in q for t in terms): return {"intent": "LIST_FLAG", "flag": flag}
    return {"intent": "ABSTAIN", "why": "no supported term found"}
