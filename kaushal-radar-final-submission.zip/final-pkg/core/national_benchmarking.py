"""State-level benchmarks only. District estimates are never manufactured from state data."""
def benchmark(state_value, district_value=None):
    return {"state": state_value, "district": district_value, "district_derived_from_state": False, "status": "PROPOSED" if state_value is None else "BUILT_WITH_LIMITATIONS"}
def derive_district_from_state(*a, **k): raise NotImplementedError("Refused: district estimates cannot be derived from state-level data.")
def transferable_policies(): return {"status": "PROPOSED", "needs": "Cited evaluation of the policy plus comparable context; each entry requires a source in claims_register.csv"}
