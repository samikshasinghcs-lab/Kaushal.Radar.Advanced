import unittest, time, os
import auth_tokens as A, audit_anchor as AA, retention as R, data_quality as Q, employment_intelligence as EI, business_intelligence as BI
import skills_transition as ST, workforce_inclusion as WI, national_benchmarking as NB, forecasting as F, flag_engine as FE, intervention_engine as IE
import mock_dpi as M, labour_intelligence as L, labour_market as LM
from decision_engine import Ledger
from adapters.sources import AISHE, REGISTRY
K = b"x" * 32
class Auth(unittest.TestCase):
    def test_roundtrip(self): self.assertEqual(A.verify(A.issue("u", "auditor", key=K), key=K)["role"], "auditor")
    def test_tamper(self):
        t = A.issue("u", "auditor", key=K).split("."); t[1] = t[1][:-2] + "AA"
        with self.assertRaises(PermissionError): A.verify(".".join(t), key=K)
    def test_expired(self):
        with self.assertRaises(PermissionError): A.verify(A.issue("u", "x", ttl=1, key=K, now=1000), key=K, now=2000)
    def test_alg_none_blocked(self):
        import base64, json; h = base64.urlsafe_b64encode(b'{"alg":"none"}').decode().strip("="); 
        with self.assertRaises(PermissionError): A.verify(h + ".e30.x", key=K)
    def test_short_key_refused(self):
        with self.assertRaises(ValueError): A.issue("u", "r", key=b"short")
    def test_rate_limit_and_lockout(self):
        l = A.Limiter(max_req=3, window=60, max_fail=2, lock=100); self.assertTrue(all(l.allow("a", now=1) for _ in range(3))); self.assertFalse(l.allow("a", now=2))
        l.failure("b", now=1); l.failure("b", now=1); self.assertFalse(l.allow("b", now=50)); self.assertTrue(l.allow("b", now=200))
class Anchor(unittest.TestCase):
    def test_truncation_detected(self):
        l = Ledger(); [l.record("u", "r", "a", {"i": i}) for i in range(4)]; a = AA.anchor(l, K); l.rows = l.rows[:2]
        ok, why = AA.verify_anchor(l, a, K); self.assertFalse(ok); self.assertIn("TRUNCATED", why)
    def test_intact(self):
        l = Ledger(); l.record("u", "r", "a", {}); self.assertTrue(AA.verify_anchor(l, AA.anchor(l, K), K)[0])
    def test_forged_anchor(self):
        l = Ledger(); l.record("u", "r", "a", {}); a = AA.anchor(l, K); a["n"] = 0; self.assertFalse(AA.verify_anchor(l, a, K)[0])
class Retention(unittest.TestCase):
    def test_purge_logged(self):
        log = Ledger(); kept, dead = R.purge({"old": 0, "new": time.time()}, "ai_cache", log=log); self.assertEqual(dead, ["old"]); self.assertEqual(log.rows[0]["body"]["action"], "DELETED_EXPIRED")
    def test_consent_withdraw(self):
        c = R.ConsentLog(); c.grant("DeptA", "skills"); self.assertTrue(R.may_ingest(c, "DeptA", "skills")); c.withdraw("DeptA", "skills"); self.assertFalse(R.may_ingest(c, "DeptA", "skills"))
class Quality(unittest.TestCase):
    def test_annual_never_live(self): self.assertFalse(Q.label_ok("annual", True)); self.assertTrue(Q.label_ok("live", True))
    def test_incompatible_comparison(self):
        ok, why = Q.compatible({"unit": "%", "geography": "state", "definition": "a", "period": "2023"}, {"unit": "%", "geography": "district", "definition": "a", "period": "2024"}); self.assertFalse(ok); self.assertEqual(set(why), {"geography", "period"})
    def test_metadata_required(self):
        with self.assertRaises(ValueError): Q.indicator(value=1)
    def test_missing_not_invented(self): self.assertIsNone(LM.lfpr(None, 5, 100)); self.assertIsNone(LM.lfpr(5, 5, 0))
    def test_state_not_district(self): self.assertIsNone(LM.no_district_from_state({"coverage": "state", "value": 9}))
class Intel(unittest.TestCase):
    def test_small_cell(self): self.assertIsNone(EI.jobseeker_vacancy_ratio(5, 100)); self.assertEqual(EI.jobseeker_vacancy_ratio(100, 20), 5.0)
    def test_conversion_blank_without_hires(self): self.assertIsNone(EI.stages(100, None, None)["conversion"])
    def test_mca_udyam_not_mixed(self):
        with self.assertRaises(ValueError): BI.ratio({"source": "MCA", "value": 1}, {"source": "Udyam", "value": 2})
    def test_no_jobs_per_company_without_link(self): self.assertIsNone(BI.jobs_per_new_company(50, None))
    def test_skill_extraction(self): self.assertEqual(ST.extract("Need CNC machine operator with Tally and Kannada"), ["Basic English/Kannada", "Machine operation", "Tally/accounting"])
    def test_shortage_blocked_without_data(self): self.assertEqual(ST.shortage({}, {})["status"], L.BLOCKED)
    def test_pathways_no_coding(self):
        for g in WI.PATH: p = WI.pathway(g); self.assertFalse(p["assumes_coding"]); self.assertFalse(p["individual_targeting"])
    def test_benchmark_refuses_derivation(self):
        with self.assertRaises(NotImplementedError): NB.derive_district_from_state(1)
class Forecast(unittest.TestCase):
    def test_insufficient(self): self.assertEqual(F.forecast([1, 2, 3])["status"], "INSUFFICIENT_DATA")
    def test_valid_with_validation(self):
        r = F.forecast([10 + i + (i % 2) * .1 for i in range(16)]); self.assertEqual(r["status"], "BUILT_WITH_LIMITATIONS"); self.assertIn("beats_naive", r["validation"]); self.assertLess(r["forecast"][0]["lo"], r["forecast"][0]["hi"])
class Flags(unittest.TestCase):
    def test_twelve(self): self.assertEqual(len(FE.FLAGS), 12)
    def test_blocked_without_feed(self):
        for x in FE.evaluate_all():
            if x["status"] != "SEE_labour_intelligence": self.assertEqual(x["status"], L.BLOCKED); self.assertFalse(x["raised"])
    def test_synthetic_inherits_label(self):
        r = FE.evaluate("Wage Risk", {"median_wage": 5, "state_median_wage": 10}, synthetic=True); self.assertTrue(r["raised"]); self.assertEqual(r["status"], L.SYNTH); self.assertEqual(r["human_approval"], "PENDING")
    def test_rule_can_stay_quiet(self): self.assertFalse(FE.evaluate("Wage Risk", {"median_wage": 10, "state_median_wage": 10})["raised"])
class Engine(unittest.TestCase):
    def setUp(self): self.e = IE.Engine(); self.cid = self.e.draft(L.all_flags()[0])
    def test_ai_cannot_bypass(self):
        with self.assertRaises(PermissionError): self.e.decide(self.cid, "bot", "ai_system", "APPROVED_FOR_INVESTIGATION")
        self.assertEqual(self.e.cards[self.cid]["human_approval_status"], "PENDING")
    def test_officer_decision_logged(self): self.e.decide(self.cid, "o1", "department_officer", "RETURNED"); self.assertTrue(self.e.ledger.verify()); self.assertEqual(self.e.ledger.rows[-1]["body"]["action"], "HUMAN_DECISION")
    def test_outcome_needs_followup(self): self.assertEqual(self.e.outcome(self.cid, "m", 1, 2, 3)["status"], "NOT_MEASURED")
class Adapters(unittest.TestCase):
    def test_ok(self): r = AISHE().parse(b"District Name,No. of Colleges,Total Enrolment\nRaichur,10,500\n", "2022-23"); self.assertTrue(r["accepted"]); self.assertEqual(r["rows"][0]["institutions"], "10")
    def test_drift(self): self.assertIn("SCHEMA_DRIFT", AISHE().parse(b"a,b\n1,2\n", "2022")["reason"])
    def test_pii(self): self.assertFalse(AISHE().parse(b"district,aadhaar\n1,2\n", "2022")["accepted"])
    def test_five_registered(self): self.assertEqual(len(REGISTRY), 5)
class Mocks(unittest.TestCase):
    def test_all_mock(self): t = M.consent_request("D", "p"); self.assertTrue(t["mock"]); self.assertTrue(M.api_setu_fetch("x", t["token"])["mock"]); self.assertTrue(M.esign("h", "s")["mock"])
    def test_consent_required(self):
        with self.assertRaises(PermissionError): M.api_setu_fetch("x", "")
if __name__ == "__main__": unittest.main()
