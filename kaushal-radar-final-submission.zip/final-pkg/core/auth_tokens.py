"""Signed-token auth (HS256 JWT, stdlib) + rate limit + lockout. Replaces the X-Role header stub in local use.
Prototype: key management, OIDC/State SSO and token revocation still need an independent review."""
import hmac, hashlib, base64, json, time, os
SECRET = os.environ.get("KR_JWT_SECRET", "").encode()
def _b(x): return base64.urlsafe_b64encode(x).rstrip(b"=").decode()
def _u(s): return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))
def _key(k): 
    k = k or os.environ.get("KR_JWT_SECRET", "").encode()     # read at call time so rotation needs no restart
    if len(k) < 16: raise ValueError("KR_JWT_SECRET must be set (>=16 bytes)")
    return k
def issue(user, role, district=None, ttl=900, key=None, now=None):
    h = _b(json.dumps({"alg": "HS256", "typ": "JWT"}).encode()); n = now or time.time()
    p = _b(json.dumps({"sub": user, "role": role, "district": district, "iat": int(n), "exp": int(n + ttl)}).encode())
    return f"{h}.{p}." + _b(hmac.new(_key(key), f"{h}.{p}".encode(), hashlib.sha256).digest())
def verify(tok, key=None, now=None):
    try: h, p, s = tok.split(".")
    except ValueError: raise PermissionError("malformed token")
    if json.loads(_u(h)).get("alg") != "HS256": raise PermissionError("alg not allowed")  # blocks alg=none
    if not hmac.compare_digest(_b(hmac.new(_key(key), f"{h}.{p}".encode(), hashlib.sha256).digest()), s): raise PermissionError("bad signature")
    c = json.loads(_u(p))
    if (now or time.time()) >= c["exp"]: raise PermissionError("expired")
    return c
class Limiter:
    """Sliding-window rate limit per key + lockout after repeated failures."""
    def __init__(self, max_req=60, window=60, max_fail=5, lock=300): self.m, self.w, self.f, self.l = max_req, window, max_fail, lock; self.hits, self.fails, self.locked = {}, {}, {}
    def allow(self, k, now=None):
        n = now or time.time()
        if self.locked.get(k, 0) > n: return False
        q = [t for t in self.hits.get(k, []) if n - t < self.w]; ok = len(q) < self.m
        if ok: q.append(n)
        self.hits[k] = q; return ok
    def failure(self, k, now=None):
        n = now or time.time(); self.fails[k] = self.fails.get(k, 0) + 1
        if self.fails[k] >= self.f: self.locked[k] = n + self.l; self.fails[k] = 0
    def success(self, k): self.fails[k] = 0

if __name__ == "__main__":   # python auth_tokens.py issue USER ROLE [DISTRICT]   (needs KR_JWT_SECRET)
    import sys; print(issue(sys.argv[2], sys.argv[3], sys.argv[4] if len(sys.argv) > 4 else None))
