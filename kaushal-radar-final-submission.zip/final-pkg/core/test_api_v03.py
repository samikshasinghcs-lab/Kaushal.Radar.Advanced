import unittest, json, os, urllib.request, urllib.error, api_server as A, auth_tokens as AT
K = b"k" * 32
def call(b, m, path, tok=None, body=None, hdr=None):
    h = {"Content-Type": "application/json", **(hdr or {})}
    if tok: h["Authorization"] = "Bearer " + tok
    r = urllib.request.Request(b + path, data=json.dumps(body).encode() if body is not None else None, headers=h, method=m)
    try:
        with urllib.request.urlopen(r) as x: return x.status, json.loads(x.read())
    except urllib.error.HTTPError as e: return e.code, json.loads(e.read())
class T(unittest.TestCase):
    @classmethod
    def setUpClass(c): c.srv = A.serve(0); c.b = f"http://127.0.0.1:{c.srv.server_address[1]}"
    @classmethod
    def tearDownClass(c): c.srv.shutdown()
    def setUp(self): os.environ.pop("KR_JWT_SECRET", None); A.LIM.hits.clear(); A.LIM.fails.clear(); A.LIM.locked.clear()
    def tearDown(self): os.environ.pop("KR_JWT_SECRET", None)
    def tok(self, role, district=None): return AT.issue("u", role, district, key=K)
    def test_stub_works_without_secret(self): self.assertEqual(call(self.b, "GET", "/flags", hdr={"X-User": "u", "X-Role": "auditor"})[0], 200)
    def test_stub_off_when_secret_set(self):
        os.environ["KR_JWT_SECRET"] = K.decode(); self.assertEqual(call(self.b, "GET", "/flags", hdr={"X-User": "u", "X-Role": "administrator"})[0], 403)
    def test_valid_token(self):
        os.environ["KR_JWT_SECRET"] = K.decode(); s, d = call(self.b, "GET", "/flags", tok=AT.issue("u", "auditor", key=K)); self.assertEqual(s, 200); self.assertGreater(d["count"], 30)
    def test_forged_or_bad_token_denied(self):
        os.environ["KR_JWT_SECRET"] = K.decode(); self.assertEqual(call(self.b, "GET", "/flags", tok=AT.issue("u", "administrator", key=b"z" * 32))[0], 403)
    def test_lockout_after_bad_tokens(self):
        os.environ["KR_JWT_SECRET"] = K.decode(); [call(self.b, "GET", "/flags", tok="bad.bad.bad") for _ in range(5)]
        self.assertEqual(call(self.b, "GET", "/flags", tok=AT.issue("u", "auditor", key=K))[0], 429)
    def test_district_officer_scope(self):
        os.environ["KR_JWT_SECRET"] = K.decode(); t = self.tok("district_officer", "raichur")
        self.assertEqual(call(self.b, "GET", "/flags?district=raichur", tok=t)[0], 200); self.assertEqual(call(self.b, "GET", "/flags?district=mysuru", tok=t)[0], 403); self.assertEqual(call(self.b, "GET", "/flags", tok=t)[0], 403)
    def test_flags_filter(self):
        s, d = call(self.b, "GET", "/flags?flag=High-GDP%20Labour%20Risk", hdr={"X-User": "u", "X-Role": "auditor"}); self.assertEqual(d["count"], 5)
    def test_two_sided_forecast_pulse_fairness(self):
        h = {"X-User": "u", "X-Role": "auditor"}
        self.assertEqual(call(self.b, "GET", "/two-sided", hdr=h)[1]["raichur"]["quadrant"], "LOW_INCOME/HIGH_PRESSURE")
        self.assertEqual(call(self.b, "GET", "/forecast?series=1,2,3", hdr=h)[1]["status"], "INSUFFICIENT_DATA")
        self.assertEqual(call(self.b, "GET", "/pulse", hdr=h)[1]["status"], "SYNTHETIC_DEMONSTRATION"); self.assertIn("groups", call(self.b, "GET", "/fairness", hdr=h)[1])
    def test_decision_flow_and_gate(self):
        h = {"X-User": "off1", "X-Role": "department_officer"}; cid = "Raichur:Employment Pressure"
        self.assertEqual(call(self.b, "POST", "/interventions/decision", hdr=h, body={"id": cid, "decision": "APPROVED_FOR_INVESTIGATION"})[0], 201)
        s, d = call(self.b, "POST", "/interventions/decision", hdr=h, body={"id": cid, "decision": "APPROVED_FOR_ACTION", "evidence": [{"category": "supply", "source": "X", "independent": True, "supports": True, "year": 2025, "self_declared": True}]})
        self.assertEqual(s, 409)                                                  # self-declared evidence cannot pass the gate
        ev = [dict(category="supply", source="A", independent=True, supports=True, year=2025), dict(category="outcome", source="B", independent=True, supports=True, year=2025)]
        self.assertEqual(call(self.b, "POST", "/interventions/decision", hdr=h, body={"id": cid, "decision": "APPROVED_FOR_ACTION", "evidence": ev})[0], 201)
    def test_wrong_role_cannot_decide(self): self.assertEqual(call(self.b, "POST", "/interventions/decision", hdr={"X-User": "a", "X-Role": "auditor"}, body={"id": "Raichur:Employment Pressure", "decision": "RETURNED"})[0], 403)
if __name__ == "__main__": unittest.main()
