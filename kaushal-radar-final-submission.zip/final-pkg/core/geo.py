"""Geography-level code path. District data is real today. Taluk files go through the same engines once a taluk source exists;
until then only synthetic taluk rows are used (SYNTHETIC_DEMONSTRATION). Never infers taluk values from district values."""
import csv, io, labour_intelligence as L
LEVELS = ("state", "district", "taluk")
REQUIRED = ("taluk", "district_key", "lgd_subdistrict_code", "income_lakh", "registrants", "population")
def parse_taluk_csv(raw: bytes, known_districts, min_pop=10):
    rows = list(csv.DictReader(io.StringIO(raw.decode("utf-8-sig"))))
    miss = [c for c in REQUIRED if not rows or c not in rows[0]]
    if miss: return {"accepted": False, "reason": f"SCHEMA_DRIFT missing {miss}"}
    out, rejected = [], []
    for r in rows:
        if r["district_key"] not in known_districts: rejected.append((r["taluk"], "unknown district")); continue
        if not r["lgd_subdistrict_code"].strip(): rejected.append((r["taluk"], "missing LGD sub-district code")); continue
        try: pop, reg, inc = float(r["population"]), float(r["registrants"]), float(r["income_lakh"])
        except ValueError: rejected.append((r["taluk"], "non-numeric")); continue
        if reg < min_pop: rejected.append((r["taluk"], "cell below 10 suppressed")); continue
        d = reg / pop * 1000
        out.append(dict(key=r["lgd_subdistrict_code"], District=r["taluk"], income_lakh=inc, dgpi_per_1000=d, dgpi_census=d, msme_jobs_per_1000=0.0))
    return {"accepted": True, "level": "taluk", "rows": out, "rejected": rejected}
def taluk_flags(parsed):
    rows = parsed["rows"]; q = L.two_sided(rows); fl = [x for r in rows for x in L.flags_for(r, q[r["key"]]) if x["track"] != "ALL"]
    for f in fl: f["geography_level"] = "taluk"
    return fl
