"""Advertised jobs are not hires and hires are not sustained employment. Three separate series; ratios refuse small cells."""
MIN = 10
def jobseeker_vacancy_ratio(seekers, vacancies):
    if seekers is None or vacancies is None or seekers < MIN or vacancies < MIN: return None
    return round(seekers / vacancies, 2)
def stages(advertised, hired, retained_6m):
    out = {"advertised": advertised, "verified_hires": hired, "retained_6m": retained_6m}
    out["conversion"] = None if not advertised or hired is None else round(hired / advertised, 2)
    out["note"] = "Conversion is blank unless verified hires are supplied. Advertisements do not prove hiring."
    return out
