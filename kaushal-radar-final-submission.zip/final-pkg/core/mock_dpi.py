"""MOCKS of API Setu, consent and e-Sign flows. Every response carries mock=True. Real integration needs government onboarding."""
import hashlib, time
def api_setu_fetch(dataset, consent_token): 
    if not consent_token or not consent_token.startswith("MOCK-CONSENT-"): raise PermissionError("consent required")
    return {"mock": True, "dataset": dataset, "rows": [], "note": "MOCK. No real department data."}
def consent_request(dept, purpose): return {"mock": True, "token": "MOCK-CONSENT-" + hashlib.sha256(f"{dept}{purpose}{time.time()}".encode()).hexdigest()[:12], "purpose": purpose, "dept": dept}
def esign(doc_hash, signer): return {"mock": True, "doc_hash": doc_hash, "signer": signer, "signature": "MOCK-SIGNATURE", "note": "Not legally valid"}
