"""Builds the unified dashboard from the bundled core dashboard + labour_intelligence.py. Run: python build_dashboard.py
Writes core/ and ../dashboard/ copies so they stay identical (test_dashboard_sync.py checks this)."""
import json, os, sys, csv, labour_intelligence as L, flag_engine as FE, workforce_inclusion as WI, fairness as FR, query_i18n as QI
from adapters import aishe_state as AS
H = os.path.dirname(os.path.abspath(__file__)); SRC = os.path.join(H, "dashboard_base.html")
html = open(SRC, encoding="utf-8").read()
rows = L.load(); q = L.two_sided(rows)
data = dict(rows=[dict(key=r["key"], name=r["District"], inc=r["income_lakh"], dg=r["dgpi_per_1000"], dc=r["dgpi_census"], msme=r["msme_jobs_per_1000"],
            quad=q[r["key"]]["quadrant"], stable=q[r["key"]]["stable_under_census_denominator"]) for r in rows],
            flags={f["district"]: f for f in L.all_flags() if f["track"] != "ALL"},
            cards={f["district"]: L.intervention_card(f) for f in L.all_flags() if f["track"] != "ALL"},
            gaps=L.MISSING_FEEDS, prop=L.PROPOSED_REGISTER, skills=L.SKILLS_MATRIX, path=L.INCLUSION_PATHWAY, vs=L.GOVT_TODAY_VS_RADAR, pulse=L.pulse_sample(), f12=[dict(flag=k, status=("SEE_FLAG_VIEW" if v[1] is None else L.BLOCKED), needs=list(v[0]), dept=v[3]) for k, v in FE.FLAGS.items()], inc={g: WI.pathway(g) for g in WI.PATH},
            aishe=[x for x in AS.extract(os.path.join(H, "..", "data", "education", "AISHE_Final_Report_2023-24.xlsx")) if x["indicator"] in ("colleges_per_lakh_pop_18_23", "ger_all_2023-24", "ger_all_india_2023-24", "ger_sc_2023-24", "ger_st_2023-24", "ptr_all_institutions_regular_and_distance", "enrolment_total", "universities_total")],
            plfs=list(csv.DictReader(open(os.path.join(H, "..", "data", "labour_market", "plfs_karnataka_claims.csv"), encoding="utf-8"))), fair=FR.check(), i18n=QI.FLAG_TERMS,
            rank=AS.colleges_per_lakh_rank(os.path.join(H, "..", "data", "education", "AISHE_Final_Report_2023-24.xlsx")))
JS = r"""
/*KR_V2*/const X=__X__;
const BADGE={B:'<span class="band" style="background:#189787;color:#fff">BUILT WITH LIMITATIONS</span>',S:'<span class="band" style="background:#F6BE3D">SYNTHETIC DEMO</span>',P:'<span class="band" style="background:#5b6b82;color:#fff">PROPOSED, NOT OPERATIONAL</span>',N:'<span class="band" style="background:#b3261e;color:#fff">NOT RUN (human task)</span>'};
const QC={'LOW_INCOME/HIGH_PRESSURE':'#E34A33','HIGH_INCOME/HIGH_PRESSURE':'#7F0000','HIGH_INCOME/LOW_PRESSURE':'#189787','LOW_INCOME/LOW_PRESSURE':'#F6BE3D'};
const xr=k=>X.rows.find(r=>r.key===k),esc=s=>String(s).replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
function lbl(){return '<div class="warn"><b>Annual data, not live.</b> Source: DES Karnataka 2025-26 (GDDP/PCI, MSME), Yuvanidhi 2025, Census 2011 (label 2011). Reliability: medium. Flags are signals for human review, not proof of cause and not instructions.</div>'}
function vTwo(){const mi=med(X.rows.map(r=>r.inc)),md=med(X.rows.map(r=>r.dg));const xs=X.rows.map(r=>r.inc),ys=X.rows.map(r=>r.dg),x0=Math.min(...xs),x1=Math.max(...xs),y0=Math.min(...ys),y1=Math.max(...ys);
 const px=v=>50+(v-x0)/(x1-x0)*520,py=v=>270-(v-y0)/(y1-y0)*240;
 const dots=X.rows.map(r=>`<circle cx="${px(r.inc)}" cy="${py(r.dg)}" r="${r.key===S.sel?9:6}" fill="${QC[r.quad]}" stroke="${r.stable?'#fff':'#000'}" stroke-width="${r.stable?1:2}" onclick="go('flg','${r.key}')" style="cursor:pointer"><title>${r.name}: ${r.quad}${r.stable?'':' (changes under Census denominator)'}</title></circle>`).join('');
 return lbl()+`<div class="row"><div class="col card"><h2>Two-sided matrix: income vs graduate registration pressure</h2><svg viewBox="0 0 600 310"><line x1="${px(mi)}" x2="${px(mi)}" y1="20" y2="270" stroke="#999" stroke-dasharray="4"/><line y1="${py(md)}" y2="${py(md)}" x1="50" x2="580" stroke="#999" stroke-dasharray="4"/>${dots}
 <text x="50" y="300" font-size="11">Per capita income (lakh) →</text><text x="330" y="38" font-size="11" fill="#7F0000">HIGH income / HIGH pressure</text><text x="55" y="38" font-size="11" fill="#E34A33">LOW income / HIGH pressure</text></svg>
 <div class="note">Black ring = quadrant changes when the Census 2011 denominator replaces the implied one. Do not act on those without checks.</div></div>
 <div class="col"><div class="card"><h2>Two tracks</h2><b>Recovery:</b> low-income districts with high pressure get investigate-and-pilot lists.<br><b>Quality:</b> high-income districts are checked for job quality, wages, exclusion and skill shortage. High GDP never means healthy labour; low GDP never means every indicator is poor.<br><br>${['LOW_INCOME/HIGH_PRESSURE','HIGH_INCOME/HIGH_PRESSURE','HIGH_INCOME/LOW_PRESSURE','LOW_INCOME/LOW_PRESSURE'].map(k=>`<div><i style="display:inline-block;width:11px;height:11px;background:${QC[k]}"></i> ${k.replace('/',' / ').replace(/_/g,' ')}: <b>${X.rows.filter(r=>r.quad===k).length}</b></div>`).join('')}</div></div></div>`}
function vFlg(){const f=X.flags[xr(S.sel).name],c=X.cards[xr(S.sel).name];
 return lbl()+`<div class="card"><label>District <select onchange="S.sel=this.value;render()">${opts(S.sel)}</select></label></div>
 <div class="row"><div class="col card"><h2>Flag: ${esc(f.flag)}</h2>${BADGE.B} <b>Track:</b> ${f.track} <b>Confidence:</b> ${f.confidence}<ul class="rt">${f.evidence.map(e=>'<li>'+esc(e)+'</li>').join('')}</ul><b>Limitations</b><ul class="rt">${f.limitations.map(e=>'<li>'+esc(e)+'</li>').join('')}</ul><b>Suggested action:</b> ${esc(f.recommended_action)}<br><b>Department that could respond:</b> ${esc(f.responding_department)}</div>
 <div class="col card"><h2>Intervention card (draft)</h2><table>${Object.entries(c).map(([k,v])=>`<tr><th>${k.replace(/_/g,' ')}</th><td>${esc(Array.isArray(v)?v.join('; '):v)}</td></tr>`).join('')}</table><div class="note">Human approval is PENDING. The engine drafts; only a department officer can approve, and nothing here moves funding.</div></div></div>
 <div class="card"><h2>Evidence Gap: missing feeds</h2>${BADGE.P}<ul class="rt">${Object.entries(X.gaps).map(([k,v])=>`<li><b>${k}</b>: blocked until ${v}</li>`).join('')}</ul></div>`}
function vPul(){const p=X.pulse;return lbl()+`<div class="card"><h2>Labour pulse: formation vs active vs hiring</h2>${BADGE.S} ${BADGE.P}<div class="warn">${p.badge} A real feed needs EPFO/MCA/NCS agreements. Registration is not a job, so no jobs-per-company ratio is shown for real districts.</div>
 <table><tr><th>Month</th><th>Registrations</th><th>Active firms</th><th>Hires</th><th>Hires / registration</th></tr>${p.rows.map(r=>`<tr><td>${r.month}</td><td>${r.registrations}</td><td>${r.active_firms}</td><td>${r.hires??'missing'}</td><td>${r.hires==null?'n/a':(r.hires/r.registrations).toFixed(2)}</td></tr>`).join('')}</table></div>`}
function vInc(){return lbl()+`<div class="row"><div class="col card"><h2>Skills transition matrix</h2>${BADGE.P}<table><tr><th>Existing</th><th>Direction</th><th>Transfers</th><th>Route</th><th>Evidence to cite</th></tr>${X.skills.map(s=>`<tr><td>${s.existing}</td><td>${s.direction}</td><td>${s.transfers}</td><td>${s.route}</td><td>${s.evidence}</td></tr>`).join('')}</table><div class="note">National trends are not local demand. Needs local vacancy and training data before any claim.</div></div>
 <div class="col card"><h2>Pathway for uneducated and outdated-skill workers</h2>${BADGE.P}<ol class="rt">${X.path.map(s=>'<li>'+s+'</li>').join('')}</ol><div class="note">No smartphone or coding assumed. Demo only, no personal data, no individual targeting.</div></div></div>`}
function vVs(){return `<div class="card"><h2>Government today vs Kaushal Radar</h2>${BADGE.B}<table>${X.vs.map(([a,b])=>`<tr><th>${a}</th><td>${b}</td></tr>`).join('')}</table><div class="note">Qualitative. Each line must be backed by a cited source in claims_register.csv before presenting as fact.</div></div>`}
function vPro(){return `<div class="card"><h2>Proposed register</h2>${BADGE.P}<table><tr><th>Idea (vision)</th><th>Evidence</th><th>Data and access</th><th>Proof test to move to built</th></tr>${X.prop.map(p=>'<tr>'+p.map(c=>'<td>'+c+'</td>').join('')+'</tr>').join('')}</table></div>
 <div class="card"><h2>NOT RUN until a human does it</h2>${BADGE.N}<ul class="rt"><li>Usability test with SUS scores</li><li>Independent security and DPIA review</li><li>Officer conversation or signed data agreement</li><li>Live LLM run on 31 districts and blind test set</li></ul></div>`}
""".replace("__X__", json.dumps(data, separators=(",", ":")))+open(os.path.join(H, "dashboard_views_v3.js"), encoding="utf-8").read()+"\nconst VX={..._VX,conf:vConf2};\n"
old = "ev:vEv}[S.view]()"
assert old in html
html = html.replace(old, "ev:vEv,...(window.VX||{})}[S.view]()", 1)
html = html.replace("\nrender();\n</script>", "\nwindow.VX=undefined;" + JS + "\nwindow.VX=VX;render();\n</script>", 1)
outs = [os.path.join(d, "Kaushal_Radar_Dashboard.html") for d in (H, os.path.join(H, "..", "dashboard"))]
if "--check" in sys.argv:
    bad = [o for o in outs if open(o, encoding="utf-8").read() != html]
    print("DASHBOARD OUT OF DATE: " + ", ".join(bad) if bad else "dashboard up to date"); sys.exit(1 if bad else 0)
for o in outs: open(o, "w", encoding="utf-8").write(html)
print("built", len(html))
