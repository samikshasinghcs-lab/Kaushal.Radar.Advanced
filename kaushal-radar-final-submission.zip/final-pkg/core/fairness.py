"""Fairness check across GROUPS OF DISTRICTS (no individual data exists, so individual-level fairness cannot be tested).
Compares flag rates, denominator disagreement and data-gap rates between region groups. Reports disparities; never 'fixes' them silently."""
import labour_intelligence as L
KK = {"bidar", "kalaburagi", "yadgir", "raichur", "koppal", "ballari", "vijayanagar"}   # Kalyana-Karnataka (verify against the notified list)
def check(rows=None, group=lambda r: "KK" if r["key"] in KK else "other"):
    rows = rows or L.load(); q = L.two_sided(rows); g = {}
    for r in rows:
        k = group(r); d = g.setdefault(k, dict(n=0, pressure=0, unstable=0)); d["n"] += 1
        d["pressure"] += q[r["key"]]["quadrant"].endswith("HIGH_PRESSURE"); d["unstable"] += (not q[r["key"]]["stable_under_census_denominator"])
    out = {k: dict(v, pressure_rate=round(v["pressure"] / v["n"], 2), unstable_rate=round(v["unstable"] / v["n"], 2)) for k, v in g.items()}
    rates = [v["pressure_rate"] for v in out.values() if v["n"]]; ratio = (min(rates) / max(rates)) if rates and max(rates) else None
    return {"groups": out, "min_over_max_pressure_rate": None if ratio is None else round(ratio, 2),
            "flag_disparity": ratio is not None and ratio < 0.8, "small_groups": [k for k, v in out.items() if v["n"] < 10],
            "note": "Disparity in flag rates may reflect real differences. Review is required; this is not a bias verdict. Groups under 10 districts are indicative only."}
