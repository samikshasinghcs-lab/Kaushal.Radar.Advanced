import unittest, os
H = os.path.dirname(os.path.abspath(__file__))
class T(unittest.TestCase):
    def test_copies_identical(self):
        a = open(os.path.join(H, "Kaushal_Radar_Dashboard.html"), "rb").read(); b = open(os.path.join(H, "..", "dashboard", "Kaushal_Radar_Dashboard.html"), "rb").read(); self.assertEqual(a, b)
    def test_proposed_and_synthetic_badges_present(self):
        t = open(os.path.join(H, "Kaushal_Radar_Dashboard.html"), encoding="utf-8").read()
        for s in ("PROPOSED, NOT OPERATIONAL", "SYNTHETIC DEMO", "NOT RUN (human task)", "Annual data, not live"): self.assertIn(s, t)
    def test_gate_rejects_self_declared_corroboration(self):
        t = open(os.path.join(H, "Kaushal_Radar_Dashboard.html"), encoding="utf-8").read()
        self.assertIn("Self-declared corroboration is not accepted", t); self.assertIn("BLOCKED by gate", t)
    def test_no_unverified_llm_claim(self):
        t = open(os.path.join(H, "Kaushal_Radar_Dashboard.html"), encoding="utf-8").read(); self.assertNotIn("AI-drafted brief (language model)", t)
    def test_dashboard_up_to_date(self):
        import subprocess, sys; self.assertEqual(subprocess.run([sys.executable, os.path.join(H, "build_dashboard.py"), "--check"], capture_output=True).returncode, 0)
if __name__ == "__main__": unittest.main()
