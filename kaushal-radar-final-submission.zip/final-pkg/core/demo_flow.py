"""Prints one end-to-end sample data flow through the local API (real indicators; mock evidence where labelled)."""
import json, urllib.request, urllib.error, api_server as A
srv = A.serve(0); B = f"http://127.0.0.1:{srv.server_address[1]}"
def call(m, path, role, user="demo", district=None, body=None):
    h = {"X-User": user, "X-Role": role, "Content-Type": "application/json"}; 
    if district: h["X-District"] = district
    req = urllib.request.Request(B + path, data=json.dumps(body).encode() if body is not None else None, headers=h, method=m)
    try:
        with urllib.request.urlopen(req) as r: code, out = r.status, json.loads(r.read())
    except urllib.error.HTTPError as e: code, out = e.code, json.loads(e.read())
    print(f"\n> {m} {path}  [role={role}{', district='+district if district else ''}]\n< {code} {json.dumps(out)[:330]}")
call("GET", "/districts/raichur/indicators", "department_officer")
call("GET", "/districts/raichur/gate", "department_officer")
call("POST", "/ledger", "department_officer", "officer1", body={"district": "raichur", "decision": "ACCEPT_FOR_INVESTIGATION"})
call("GET", "/districts/raichur/gate?scenario=low_vacancy", "department_officer")
call("POST", "/ledger", "department_officer", "officer1", body={"district": "raichur", "decision": "ACCEPT_FOR_INVESTIGATION", "note": "open diagnosis", "scenario": "low_vacancy"})
call("GET", "/districts/mysuru/indicators", "district_officer", district="raichur")
call("GET", "/districts/mysuru/indicators", "district_officer")
call("GET", "/audit", "auditor", "auditor1")
srv.shutdown()
