"""Skill extraction from vacancy text (keyword taxonomy; SYNTHETIC DEMO) + transition matrix. National trends != local demand."""
import re, labour_intelligence as L
TAX = {"Tally/accounting": r"\btally|gst|bookkeep", "Data entry": r"data entry|typing", "Machine operation": r"cnc|lathe|machine operator|plc",
       "Digital payments": r"\bupi\b|pos terminal|digital payment", "Customer service": r"customer (service|support)|call cent", "Basic English/Kannada": r"kannada|english communication",
       "Welding/fitting": r"weld|fitter|fitting"}
def extract(text): return sorted(k for k, rx in TAX.items() if re.search(rx, text, re.I))
def transition_matrix(): return L.SKILLS_MATRIX
def shortage(demand_skills, trained_by_skill):
    """Needs local vacancy counts and training output; otherwise blocked."""
    if not demand_skills or not trained_by_skill: return {"status": L.BLOCKED, "why": "needs local vacancy text and training output"}
    return {"status": L.BUILT_WITH_LIMITATIONS, "gaps": {s: demand_skills[s] - trained_by_skill.get(s, 0) for s in demand_skills if demand_skills[s] > trained_by_skill.get(s, 0)}}
