"""Freshness, completeness, consistency, reliability. Annual data is never 'live'."""
FREQ_DAYS = {"live": 1, "monthly": 31, "quarterly": 92, "annual": 366, "census": 3650}
def freshness(freq, age_days):
    lim = FREQ_DAYS[freq]; return "CURRENT" if age_days <= lim else "STALE" if age_days <= 3 * lim else "VERY_STALE"
def label_ok(freq, shown_as_live): return not (shown_as_live and freq != "live")   # annual/monthly/census must not be labelled live
def completeness(rows, required):
    miss = {c: sum(1 for r in rows if r.get(c) in (None, "")) for c in required}
    return {"missing": miss, "complete": all(v == 0 for v in miss.values()), "pct": round(100 * (1 - sum(miss.values()) / max(1, len(rows) * len(required))), 1)}
def compatible(a, b):
    """Comparisons need same unit, same geography level and overlapping reference period."""
    why = [k for k in ("unit", "geography", "definition") if a.get(k) != b.get(k)]
    if a.get("period") != b.get("period"): why.append("period")
    return (not why), why
REQUIRED_META = ("value", "unit", "source", "reference_period", "coverage", "frequency", "methodology", "missing_status", "verification", "limitations")
def indicator(**kw):
    m = [k for k in REQUIRED_META if k not in kw]
    if m: raise ValueError(f"indicator missing metadata: {m}")
    return kw
