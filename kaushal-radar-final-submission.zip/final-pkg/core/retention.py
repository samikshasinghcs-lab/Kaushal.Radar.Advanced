"""Retention + deletion + consent log (DPDP-oriented prototype). Aggregates only; no personal data is stored by design.
Consent events are appended to a hash-chained ledger. Deletion removes stored objects past retention and logs the deletion."""
import time
from decision_engine import Ledger
RETENTION_DAYS = {"ingested_upload": 365, "ai_cache": 30, "access_log": 730}
class ConsentLog:
    def __init__(self): self.l = Ledger()
    def grant(self, dept, purpose, scope="aggregate", ts=None): self.l.record(dept, "data_provider", "CONSENT_GRANTED", dict(purpose=purpose, scope=scope))
    def withdraw(self, dept, purpose): self.l.record(dept, "data_provider", "CONSENT_WITHDRAWN", dict(purpose=purpose))
    def active(self, dept, purpose):
        st = False
        for r in self.l.rows:
            b = r["body"]
            if b["actor"] == dept and b["payload"].get("purpose") == purpose: st = b["action"] == "CONSENT_GRANTED"
        return st
def purge(objects, kind, now=None, log=None):
    """objects: {id: created_ts}. Returns (kept, deleted_ids). Deletions are logged."""
    n = now or time.time(); lim = RETENTION_DAYS[kind] * 86400
    dead = [i for i, t in objects.items() if n - t > lim]
    if log is not None and dead: log.record("system", "retention_job", "DELETED_EXPIRED", dict(kind=kind, count=len(dead)))
    return {i: t for i, t in objects.items() if i not in dead}, dead
def may_ingest(consents, dept, purpose): return consents.active(dept, purpose)
