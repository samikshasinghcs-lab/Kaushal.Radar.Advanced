"""Back-test flags against LATER data. Needs two periods; with one period it returns INSUFFICIENT_DATA (true for the real data today).
Measures persistence and direction, not causation or policy effect."""
import statistics
def backtest(flags_t0, metric_t0, metric_t1, higher_is_worse=True):
    """flags_t0: {district: bool raised}; metric_*: {district: value}. Returns persistence + change gap between flagged and unflagged."""
    ks = sorted(set(flags_t0) & set(metric_t0) & set(metric_t1))
    if len(ks) < 8: return {"status": "INSUFFICIENT_DATA", "n": len(ks), "need": 8, "why": "needs two periods for the same districts"}
    fl = [k for k in ks if flags_t0[k]]; nf = [k for k in ks if not flags_t0[k]]
    if len(fl) < 2 or len(nf) < 2: return {"status": "INSUFFICIENT_DATA", "n": len(ks), "why": "need at least 2 flagged and 2 unflagged"}
    med1 = statistics.median(metric_t1[k] for k in ks); sign = 1 if higher_is_worse else -1
    persist = sum((metric_t1[k] - med1) * sign > 0 for k in fl) / len(fl); base = sum((metric_t1[k] - med1) * sign > 0 for k in nf) / len(nf)
    d = lambda g: statistics.mean(metric_t1[k] - metric_t0[k] for k in g)
    return {"status": "BUILT_WITH_LIMITATIONS", "n": len(ks), "flagged": len(fl), "persistence_flagged": round(persist, 2), "persistence_unflagged": round(base, 2),
            "mean_change_flagged": round(d(fl), 3), "mean_change_unflagged": round(d(nf), 3), "lift": round(persist - base, 2),
            "note": "Association over one interval, small n. Not evidence that any action worked."}
