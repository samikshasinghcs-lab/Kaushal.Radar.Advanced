"""Barrier-specific pathways. Never assumes advanced coding or AI skills for everyone. Group-level only; no individual targeting."""
PATH = {
 "limited_education": ["Oral/local-language assessment", "Foundational literacy and numeracy", "RPL for existing skills", "Short NSQF bridge", "Apprenticeship"],
 "dropout": ["Re-entry counselling", "Open-school or bridge course", "Vocational module", "Apprenticeship"],
 "women_outside_workforce": ["Local-hours and safe-transport check", "Home-based or nearby work options", "Skill + micro-enterprise support", "Childcare linkage"],
 "informal_rural": ["RPL certification of existing skill", "Cluster-based training", "Market linkage", "Social-security enrolment info"],
 "disability": ["Accessible assessment", "Assistive-tech aware training", "Inclusive employer matching"],
 "migrant": ["Portable skill certificate", "Destination-district placement info", "Return-migration enterprise support"],
 "low_digital_access": ["Assisted kiosk or human guide", "Offline/voice-first material", "Basic digital skills only if the job needs them"],
 "outdated_skills": ["RPL assessment of what still transfers", "Targeted bridge module", "Certification", "Employer trial"]}
def pathway(group):
    if group not in PATH: raise KeyError(group)
    return {"group": group, "steps": PATH[group], "status": "PROPOSED", "assumes_coding": False, "individual_targeting": False,
            "evidence_needed": "Local barrier data (PLFS/e-Shram/Census) and pilot outcomes before any effect is claimed"}
