"""Forecast only with enough history. Linear trend with hold-out validation vs naive; otherwise 'insufficient data'."""
MIN_POINTS = 8
def forecast(series, horizon=3):
    s = [x for x in series if x is not None]
    if len(s) < MIN_POINTS: return {"status": "INSUFFICIENT_DATA", "n": len(s), "need": MIN_POINTS}
    def fit(y):
        n = len(y); xm = (n - 1) / 2; ym = sum(y) / n; b = sum((i - xm) * (v - ym) for i, v in enumerate(y)) / sum((i - xm) ** 2 for i in range(n)); return b, ym - b * xm
    h = max(2, len(s) // 4); tr, te = s[:-h], s[-h:]; b, a = fit(tr)
    mae_m = sum(abs(a + b * (len(tr) + i) - v) for i, v in enumerate(te)) / h; mae_n = sum(abs(tr[-1] - v) for v in te) / h
    b, a = fit(s); resid = [v - (a + b * i) for i, v in enumerate(s)]; sd = (sum(r * r for r in resid) / (len(s) - 2)) ** .5
    pts = [{"t": len(s) + i, "yhat": round(a + b * (len(s) + i), 2), "lo": round(a + b * (len(s) + i) - 1.96 * sd, 2), "hi": round(a + b * (len(s) + i) + 1.96 * sd, 2)} for i in range(horizon)]
    return {"status": "BUILT_WITH_LIMITATIONS", "method": "OLS linear trend", "horizon": horizon, "forecast": pts, "validation": {"holdout": h, "mae_model": round(mae_m, 3), "mae_naive": round(mae_n, 3), "beats_naive": mae_m < mae_n},
            "note": "Uncertainty is a rough 95% band from residuals; a trend is not a prediction of policy effect."}
