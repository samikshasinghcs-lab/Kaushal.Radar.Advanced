-- Same model as core/store.py. STATUS: written, NOT RUN against a Postgres server.
CREATE TABLE IF NOT EXISTS datasets(id BIGSERIAL PRIMARY KEY, source TEXT NOT NULL, period TEXT NOT NULL, content_hash TEXT NOT NULL,
  loaded_at TIMESTAMPTZ NOT NULL DEFAULT now(), status TEXT NOT NULL DEFAULT 'CURRENT', synthetic BOOLEAN NOT NULL DEFAULT FALSE, UNIQUE(source, period, content_hash));
CREATE TABLE IF NOT EXISTS observations(dataset_id BIGINT NOT NULL REFERENCES datasets(id), geo_level TEXT NOT NULL, geo_code TEXT NOT NULL,
  indicator TEXT NOT NULL, value DOUBLE PRECISION, unit TEXT, PRIMARY KEY(dataset_id, geo_level, geo_code, indicator));
CREATE TABLE IF NOT EXISTS jobs(id BIGSERIAL PRIMARY KEY, kind TEXT NOT NULL, key TEXT NOT NULL UNIQUE, payload JSONB NOT NULL, status TEXT NOT NULL DEFAULT 'QUEUED',
  attempts INT NOT NULL DEFAULT 0, run_after TIMESTAMPTZ NOT NULL DEFAULT now(), error TEXT);
-- Claim without double-processing (use in the worker): SELECT ... FROM jobs WHERE status='QUEUED' AND run_after<=now() ORDER BY id FOR UPDATE SKIP LOCKED LIMIT 1;
