"""Tests on REAL government files. AISHE Final Report 2023-24 (uploaded by the project owner). Values were checked by hand against the workbook."""
import os, unittest, csv
from adapters import aishe_state as A
R = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data", "education", "AISHE_Final_Report_2023-24.xlsx")
class T(unittest.TestCase):
    @classmethod
    def setUpClass(c): c.d = {x["indicator"]: x for x in A.extract(R)}
    def test_known_values(self):
        self.assertEqual(self.d["colleges"]["value"], 4529); self.assertAlmostEqual(self.d["colleges_per_lakh_pop_18_23"]["value"], 68.796, 2)
        self.assertEqual(self.d["universities_total"]["value"], 91); self.assertEqual(round(self.d["enrolment_total"]["value"]), 2759933)
        self.assertAlmostEqual(self.d["ger_all_2023-24"]["value"], 41.92, 2); self.assertAlmostEqual(self.d["ger_all_india_2023-24"]["value"], 30.02, 2)
    def test_provenance_and_level(self):
        for x in self.d.values(): self.assertIn(x["coverage"], ("state", "national")); self.assertTrue(x["sheet"] and x["source"] and x["frequency"] == "annual")
    def test_no_district_values(self):
        self.assertFalse(any(x["coverage"] == "district" for x in self.d.values()))
    def test_header_drift_detected(self):
        bad = dict(A.SPEC); bad["4CollegeIndicator"] = (1, {"colleges": (3, "No. of Colleges", "count")})
        old = A.SPEC; A.SPEC = bad
        try:
            with self.assertRaises(ValueError): A.extract(R)
        finally: A.SPEC = old
    def test_missing_state_fails_loudly(self):
        with self.assertRaises(ValueError): A.extract(R, "Atlantis")
    def test_rank(self):
        r = A.colleges_per_lakh_rank(R); self.assertEqual(r["of"] >= 30, True); self.assertLessEqual(r["rank"], 10)
if __name__ == "__main__": unittest.main()
