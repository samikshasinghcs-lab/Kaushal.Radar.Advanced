import unittest, tempfile, os, json
from store import Store, restore
import migrate_to_postgres as M
ROWS = [dict(geo_level="district", geo_code="raichur", indicator="dgpi", value=4.03, unit="per 1000"), dict(geo_level="district", geo_code="mysuru", indicator="dgpi", value=1.2, unit="per 1000")]
class T(unittest.TestCase):
    def test_refresh_idempotent(self):
        s = Store(); self.assertEqual(s.refresh("DES", "2025-26", ROWS)["result"], "LOADED"); self.assertEqual(s.refresh("DES", "2025-26", ROWS)["result"], "UNCHANGED")
        self.assertEqual(s.fingerprint()["observations"], 2)
    def test_changed_data_supersedes_not_overwrites(self):
        s = Store(); s.refresh("DES", "2025-26", ROWS); r2 = [dict(ROWS[0], value=9.9), ROWS[1]]; s.refresh("DES", "2025-26", r2)
        self.assertEqual(s.c.execute("SELECT COUNT(*) FROM datasets WHERE status='SUPERSEDED'").fetchone()[0], 1); self.assertEqual(dict(((a, b), v) for a, b, _, v in s.current("DES", "2025-26"))[("district", "raichur")], 9.9)
    def test_failed_load_rolls_back(self):
        s = Store()
        with self.assertRaises(Exception): s.refresh("DES", "2025-26", [ROWS[0], {"geo_level": "x"}])
        self.assertEqual(s.fingerprint()["datasets"], 0)
    def test_queue_idempotent_retry_dead_letter(self):
        s = Store(); self.assertTrue(s.enqueue("refresh", "DES:2025", {"a": 1})); self.assertFalse(s.enqueue("refresh", "DES:2025", {"a": 1}))
        calls = []
        def bad(p): calls.append(1); raise RuntimeError("boom")
        t = 1000.0
        for _ in range(3): s.run_worker({"refresh": bad}, now=t); t += 10_000
        self.assertEqual(len(calls), 3); self.assertEqual(s.c.execute("SELECT status FROM jobs").fetchone()[0], "DEAD")
    def test_queue_success(self):
        s = Store(); s.enqueue("refresh", "k", {}); self.assertEqual(s.run_worker({"refresh": lambda p: None}), 1); self.assertEqual(s.c.execute("SELECT status FROM jobs").fetchone()[0], "DONE")
    def test_backup_restore_roundtrip(self):
        d = tempfile.mkdtemp(); s = Store(); s.refresh("DES", "2025-26", ROWS); m = s.backup(os.path.join(d, "b.db")); r = restore(os.path.join(d, "b.db")); self.assertEqual(r.fingerprint(), m["fingerprint"])
    def test_corrupt_backup_refused(self):
        d = tempfile.mkdtemp(); s = Store(); s.refresh("DES", "2025-26", ROWS); p = os.path.join(d, "b.db"); s.backup(p)
        with open(p, "r+b") as f: f.seek(200); f.write(b"XXXX")
        with self.assertRaises(ValueError): restore(p)
    def test_postgres_sql_generated(self):
        d = tempfile.mkdtemp(); p = os.path.join(d, "s.db"); s = Store(p); s.refresh("DES", "2025-26", ROWS); s.c.commit(); sql = M.dump(p)
        self.assertIn("ON CONFLICT DO NOTHING", sql); self.assertIn("'raichur'", sql); self.assertIn("FOR UPDATE SKIP LOCKED", sql)
if __name__ == "__main__": unittest.main()
