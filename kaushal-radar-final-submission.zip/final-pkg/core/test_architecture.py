import unittest, re, os
H = os.path.dirname(os.path.abspath(__file__)); doc = open(os.path.join(H, "..", "docs", "ARCHITECTURE.md"), encoding="utf-8").read()
class T(unittest.TestCase):
    def test_every_named_module_exists(self):
        names = set(re.findall(r"\b([a-z_]+(?:/[a-z_]+)?\.(?:py|sql))\b", doc)); self.assertGreater(len(names), 15)
        for n in names: self.assertTrue(os.path.exists(os.path.join(H, n.replace("core/", ""))), n)
    def test_generated_api_docs_exist(self):
        for f in ("kaushal_radar_openapi_v0.3.yaml", "kaushal_radar.postman_collection.json", "swagger.html"): self.assertTrue(os.path.exists(os.path.join(H, "..", "docs", f)), f)
    def test_new_endpoints_in_spec(self):
        import yaml; s = yaml.safe_load(open(os.path.join(H, "..", "docs", "kaushal_radar_openapi_v0.3.yaml"), encoding="utf-8"))
        for p in ("/flags", "/two-sided", "/interventions/decision", "/forecast", "/fairness"): self.assertIn(p, s["paths"])
if __name__ == "__main__": unittest.main()
