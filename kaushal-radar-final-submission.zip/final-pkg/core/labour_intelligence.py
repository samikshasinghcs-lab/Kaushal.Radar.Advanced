"""Kaushal Radar labour intelligence v0.2.
Real inputs: indicators_v2.csv (GDDP/PCI, Yuvanidhi registrants, MSME jobs, Census 2011 pop).
Anything else is SYNTHETIC_DEMONSTRATION or PROPOSED and carries that label. No invented observations.
Flags are decision-support signals, never causation and never automatic government instructions."""
import csv, os, statistics

BUILT_WITH_LIMITATIONS, SYNTH, PROPOSED, BLOCKED, NOT_RUN = ("BUILT_WITH_LIMITATIONS", "SYNTHETIC_DEMONSTRATION",
                                                              "PROPOSED", "BLOCKED_PENDING_DATA", "NOT_TESTED")
HERE = os.path.dirname(os.path.abspath(__file__))

def load(path=os.path.join(HERE, "indicators_v2.csv")):
    with open(path, encoding="utf-8-sig") as f:
        return [{k: (float(v) if k not in ("District", "key") else v) for k, v in r.items()} for r in csv.DictReader(f)]

# ---- Two-sided district development: income axis x registration-pressure axis, checked under BOTH denominators ----
def two_sided(rows):
    mi = statistics.median(r["income_lakh"] for r in rows)
    out = {}
    for den in ("dgpi_per_1000", "dgpi_census"):
        md = statistics.median(r[den] for r in rows)
        for r in rows:
            q = ("HIGH" if r["income_lakh"] >= mi else "LOW") + "_INCOME/" + ("HIGH" if r[den] >= md else "LOW") + "_PRESSURE"
            out.setdefault(r["key"], {})[den] = q
    return {k: {"quadrant": v["dgpi_per_1000"], "stable_under_census_denominator": v["dgpi_per_1000"] == v["dgpi_census"], **v}
            for k, v in out.items()}

QUAD_FLAG = {  # quadrant -> (flag, track, action, department)
    "LOW_INCOME/HIGH_PRESSURE": ("Employment Pressure", "RECOVERY",
        "Investigate local vacancies, ITI/training seats and MSME hiring; then consider apprenticeship and enterprise-support pilots.",
        "Skill Development, Entrepreneurship & Livelihood Dept; Labour Dept"),
    "HIGH_INCOME/HIGH_PRESSURE": ("High-GDP Labour Risk", "QUALITY",
        "High output but many unemployed graduates: check skill mismatch, wage and job-quality data, and who is excluded from growth sectors.",
        "Labour Dept; Industries & Commerce; Higher Education"),
    "HIGH_INCOME/LOW_PRESSURE": ("Growth Opportunity (check quality)", "QUALITY",
        "Low registration is not proof of good jobs. Check wages, informality, female participation and skill shortages before calling it healthy.",
        "Labour Dept; Industries & Commerce"),
    "LOW_INCOME/LOW_PRESSURE": ("Evidence Gap", "RECOVERY",
        "Low income with few registrants may mean low awareness, domicile limits or out-migration. Do not read it as 'fine'.",
        "Skill Development Dept; District administration"),
}
MISSING_FEEDS = {  # each is BLOCKED_PENDING_DATA until a source is actually connected
    "district vacancies and verified hiring": "NCS access agreement",
    "formal payroll trend": "EPFO aggregate-sharing agreement",
    "active-firm and closure data": "MCA route to confirm",
    "informal-worker counts": "e-Shram agreement; PLFS is weak at district level",
    "training seats and placement": "NCVT/Skill India department data",
}

def flags_for(row, quad):
    flag, track, action, dept = QUAD_FLAG[quad["quadrant"]]
    stable = quad["stable_under_census_denominator"]
    f = [dict(district=row["District"], flag=flag, track=track,
              evidence=[f"GDDP/PCI {row['income_lakh']:.2f} lakh (2025-26)", f"DGPI {row['dgpi_per_1000']:.2f} per 1,000 (implied pop.)",
                        f"DGPI {row['dgpi_census']:.2f} per 1,000 (Census 2011 pop., label 2011)", f"MSME jobs {row['msme_jobs_per_1000']:.0f} per 1,000"],
              confidence="MEDIUM" if stable else "LOW",
              limitations=["Registrants are Yuvanidhi 2022-23 pass-outs, not all jobseekers",
                           "Signal under implied vs Census denominators " + ("agrees" if stable else "DISAGREES: act on neither without checks"),
                           "Annual data, not live"],
              recommended_action=action, responding_department=dept, status=BUILT_WITH_LIMITATIONS,
              human_approval="PENDING", causation_claimed=False)]
    f.append(dict(district=row["District"], flag="Evidence Gap", track="ALL", status=BLOCKED,
                  evidence=[f"Missing: {k} ({v})" for k, v in MISSING_FEEDS.items()], confidence="n/a",
                  limitations=["Flag lists missing data; it does not claim a problem exists"],
                  recommended_action="Open data requests through the named routes.", responding_department="IT/BT Dept; DES Karnataka",
                  human_approval="PENDING", causation_claimed=False))
    return f

# ---- Intervention card: 16 required fields; AI/engine can only draft, a named human approves ----
FIELDS = ("district detected_condition supporting_indicators evidence_sources data_freshness confidence affected_population "
          "recommended_intervention responsible_department implementation_pathway required_resources expected_outcome "
          "measurement_metric review_period human_approval_status").split()

def intervention_card(flag):
    return {"district": flag["district"], "detected_condition": flag["flag"], "supporting_indicators": flag["evidence"],
            "evidence_sources": ["DES Karnataka GDDP/PCI 2025-26", "Yuvanidhi 2025", "MSME (Udyam) via DES", "Census 2011"],
            "data_freshness": "Annual; not live", "confidence": flag["confidence"],
            "affected_population": "NOT_ESTIMATED (registrants only; informal workers not counted)",
            "recommended_intervention": flag["recommended_action"], "responsible_department": flag["responding_department"],
            "implementation_pathway": "Flag -> human review -> field check -> pilot design -> approval",
            "required_resources": "TO_BE_COSTED by department", "expected_outcome": "UNPROVEN until pilot measured",
            "measurement_metric": "Placement and 6-month retention in pilot cohort (needs follow-up data)",
            "review_period": "Quarterly", "human_approval_status": "PENDING"}

def approve(card, officer_role, decision):
    if officer_role not in ("department_officer", "administrator"): raise PermissionError("Role cannot approve")
    if decision not in ("APPROVED_FOR_INVESTIGATION", "APPROVED_FOR_ACTION", "RETURNED", "REJECTED"): raise ValueError("Invalid decision")
    return {**card, "human_approval_status": decision}

# ---- Pulse: SYNTHETIC only. Never emits jobs-per-company without a linked hiring series. ----
def pulse_sample():
    rows = [dict(month=f"S{m}", registrations=100 + 4 * m, active_firms=80 + 2 * m, hires=None if m < 4 else 20 + m) for m in range(1, 9)]
    return {"status": SYNTH, "badge": "SYNTHETIC. Not real Karnataka data.", "rows": rows}

def formation_to_hiring_ratio(series):
    if series["status"] != SYNTH and any(r["hires"] is None for r in series["rows"]):
        return None
    got = [r for r in series["rows"] if r["hires"] is not None]
    return {"status": series["status"], "ratio": [round(r["hires"] / r["registrations"], 3) for r in got],
            "note": "registration is not a job; lag between formation and hiring is unknown until real linked data exists"}

# ---- Skills transition + inclusion: structure only. Evidence text names reports; coder must log figures in claims_register.csv ----
SKILLS_MATRIX = [  # status PROPOSED: no local demand evidence yet
    dict(existing="Data entry / clerical", direction="Declining demand (automation exposure)", transfers="Accuracy, domain forms knowledge",
         route="Digital office + data-quality bridge course", evidence="WEF Future of Jobs; NSDC India Skills Report (cite year/URL in claims_register.csv)", status=PROPOSED),
    dict(existing="Manual assembly / textile", direction="Task shift toward machine-operation and QC", transfers="Dexterity, process discipline",
         route="RPL assessment -> NSQF bridge module -> certification", evidence="PMKVY RPL and NSQF design documents", status=PROPOSED),
    dict(existing="Retail / informal trade", direction="Digital payments and logistics tasks growing", transfers="Customer handling, local networks",
         route="Foundational literacy + mobile-first digital skills + apprenticeship", evidence="PLFS informal-employment tables (state level)", status=PROPOSED),
]
INCLUSION_PATHWAY = ["Accessible assessment (oral, local language)", "Human guide, no smartphone assumed", "Foundational literacy / numeracy",
                     "RPL for existing skills", "Bridge training -> certification", "Employer or apprenticeship placement", "6-month follow-up"]

PROPOSED_REGISTER = [  # 4 fields each: vision, evidence, data & access, proof test
    ("Near-real-time labour feed", "EPFO monthly payroll releases show formal jobs only; MCA registration is not an active firm", "EPFO aggregates (agreement); MCA route", "Two consecutive monthly pulls match the published series"),
    ("Company formation -> employment effect", "Registration is not a job (our own rule)", "MCA + hiring feed", "Linked series with >= 12 months and a stated lag"),
    ("Skill transition (emerging/declining)", "WEF Future of Jobs; NSDC skill-gap reports", "NCO-2015 public; vacancy text needs NCS", "Local vacancy text agrees with national direction"),
    ("Informal and uneducated worker counts", "e-Shram and PLFS exist; district PLFS is limited", "e-Shram agreement", "District estimate within stated error bounds"),
    ("Retraining of outdated-skill workers (RPL)", "PMKVY RPL, NSQF", "RPL-eligible counts from department", "Pilot cohort with assessment and retention data"),
    ("High-GDP diagnostics: wages, underemployment", "PLFS wage tables (state level)", "District wage data is weak", "Source with district coverage identified"),
    ("All-India benchmarking", "MoSPI PLFS state estimates", "Public, not yet ingested", "Adapter ingests a real file and test passes"),
    ("Placement, retention, wage outcomes", "Outputs are not outcomes", "Data sharing + follow-up window", "Pilot with a comparison group"),
    ("Taluk-level view", "None yet", "Taluk-level source data", "A source with taluk coverage exists"),
    ("Live NCS/EPFO/e-Shram/MCA adapters", "Access routes on slide 6", "Written agreement", "Signed data contract"),
    ("Real API Setu, consent, e-Sign", "Official DPI documentation", "Government onboarding", "Sandbox credentials issued"),
]

GOVT_TODAY_VS_RADAR = [  # qualitative; verify each line against a cited source before presenting as fact
    ("What exists today", "Separate portals (NCS, e-Shram, EPFO, Udyam, scheme registers) and periodic surveys; each reports on its own schedule and definitions."),
    ("Where it is inefficient", "No one joins them at district level; a registrant count is read as demand; high-GDP districts are rarely checked for job quality."),
    ("What Radar does", "Joins the public tables we can verify, routes each district to a track, and refuses to act without corroboration and a human decision."),
    ("Why that is more efficient", "Officers see which question to ask first, with evidence, limits and department attached, instead of a rank."),
]

def all_flags():
    rows = load(); q = two_sided(rows)
    return [x for r in rows for x in flags_for(r, q[r["key"]])]

if __name__ == "__main__":
    fl = all_flags(); print(len(fl), "flags;", sum(f["flag"] == "High-GDP Labour Risk" for f in fl), "high-GDP labour risk")
