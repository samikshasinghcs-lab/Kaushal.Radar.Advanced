"""Generates the merged OpenAPI v0.3, the Postman collection and the Swagger UI page from one source of truth. Run: python scripts_gen.py"""
import yaml, json, os
H = os.path.dirname(os.path.abspath(__file__)); D = os.path.join(H, "..", "docs")
base = yaml.safe_load(open(os.path.join(D, "kaushal_radar_openapi_v0.1.yaml"), encoding="utf-8")); add = yaml.safe_load(open(os.path.join(D, "kaushal_radar_openapi_v0.2_additions.yaml"), encoding="utf-8"))
paths = dict(base.get("paths", {})); add["paths"].pop("/interventions/{id}/decision", None)
add["paths"]["/interventions/decision"] = {"post": {"summary": "Officer decision on a draft card. APPROVED_FOR_ACTION needs a CORROBORATED gate; self-declared evidence is ignored", "x-status": "BUILT_WITH_LIMITATIONS",
    "requestBody": {"content": {"application/json": {"schema": {"type": "object", "properties": {"id": {"type": "string", "example": "Raichur:Employment Pressure"}, "decision": {"type": "string", "enum": ["APPROVED_FOR_INVESTIGATION", "APPROVED_FOR_ACTION", "RETURNED", "REJECTED"]}, "evidence": {"type": "array", "items": {"type": "object"}}}}}}}}}
add["paths"]["/fairness"] = {"get": {"summary": "Flag-rate disparity across region groups (not a bias verdict)", "x-status": "BUILT_WITH_LIMITATIONS"}}
paths.update(add["paths"])
spec = dict(base); spec["paths"] = paths; spec.setdefault("info", {})["version"] = "0.3.0"
spec.setdefault("components", {}).setdefault("securitySchemes", {}).update(add["securitySchemes"]); spec["security"] = [{"bearerAuth": []}]
yaml.safe_dump(spec, open(os.path.join(D, "kaushal_radar_openapi_v0.3.yaml"), "w", encoding="utf-8"), sort_keys=False, allow_unicode=True)
items = []
for p, ops in paths.items():
    for m, o in ops.items():
        if m.lower() not in ("get", "post"): continue
        it = {"name": f"{m.upper()} {p}", "request": {"method": m.upper(), "header": [{"key": "Authorization", "value": "Bearer {{token}}"}, {"key": "Content-Type", "value": "application/json"}],
              "url": {"raw": "{{base}}" + p, "host": ["{{base}}"], "path": [x for x in p.split("/") if x]}, "description": o.get("summary", "") + " [" + str(o.get("x-status", "")) + "]"}}
        if m.lower() == "post": it["request"]["body"] = {"mode": "raw", "raw": "{}"}
        items.append(it)
json.dump({"info": {"name": "Kaushal Radar API v0.3", "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"}, "variable": [{"key": "base", "value": "http://127.0.0.1:8000"}, {"key": "token", "value": ""}], "item": items},
          open(os.path.join(D, "kaushal_radar.postman_collection.json"), "w"), indent=1)
open(os.path.join(D, "swagger.html"), "w", encoding="utf-8").write('''<!doctype html><meta charset="utf-8"><title>Kaushal Radar API (Swagger UI)</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/swagger-ui/5.17.14/swagger-ui.min.css">
<div id="ui"></div><script src="https://cdnjs.cloudflare.com/ajax/libs/swagger-ui/5.17.14/swagger-ui-bundle.min.js"></script>
<script>SwaggerUIBundle({url:"kaushal_radar_openapi_v0.3.yaml",dom_id:"#ui"})</script>
<!-- Serve this folder (python -m http.server) and run the API on port 8000. Sandbox server: PROPOSED. -->''')
print("paths:", len(paths), "postman items:", len(items))
