import unittest, ai_eval_labour as A
class T(unittest.TestCase):
    def test_reproducible_and_reports_misses(self):
        r = A.run(); self.assertEqual(r["n"], 40); self.assertFalse(r["blind"]); self.assertIn("optimistic", r["caveat"]); self.assertEqual(A.run()["accuracy"], r["accuracy"])
    def test_held_out_is_reported_not_hidden(self):
        r = A.run(); self.assertEqual(r["held_out"]["n"], 10); self.assertEqual(r["held_out"]["passed"] + len(r["held_out"]["misses"]), 10)
    def test_core_rules_catch_core_errors(self):
        for t in ("New company registrations created 900 jobs.", "Real-time unemployment is 3 percent.", "Funds will be automatically released."): self.assertTrue(A.check(t), t)
    def test_never_accepts_causal_flag(self): self.assertTrue(A.check("The flag proves low income caused the unemployment."))
if __name__ == "__main__": unittest.main()
