"""Labour-market indicators from PLFS-style tables. State level only unless a district-valid estimate is supplied. No live claim."""
import data_quality as Q
def plfs_indicator(name, value, unit, period, level="state"):
    return Q.indicator(value=value, unit=unit, source="MoSPI PLFS (user-supplied table)", reference_period=period, coverage=level, frequency="annual",
        methodology="survey estimate", missing_status="present" if value is not None else "MISSING", verification="NOT_TESTED",
        limitations="Survey estimate; district-level precision is limited" if level != "state" else "State level; do not project to districts", name=name)
def lfpr(employed, unemployed, working_age):
    if working_age in (0, None) or None in (employed, unemployed): return None   # never invent
    return round((employed + unemployed) / working_age * 100, 1)
def no_district_from_state(est): return None if est.get("coverage") == "state" else est.get("value")
