import unittest, json, urllib.request, urllib.error, api_server as A
def call(base, method, path, user="u", role="", district=None, body=None):
    h = {"X-User": user, "X-Role": role, "Content-Type": "application/json"}
    if district: h["X-District"] = district
    req = urllib.request.Request(base + path, data=json.dumps(body).encode() if body is not None else None, headers=h, method=method)
    try:
        with urllib.request.urlopen(req) as r: return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e: return e.code, json.loads(e.read())
class T(unittest.TestCase):
    @classmethod
    def setUpClass(c): c.srv = A.serve(0); c.b = f"http://127.0.0.1:{c.srv.server_address[1]}"
    @classmethod
    def tearDownClass(c): c.srv.shutdown()
    def test_indicators_real_data(self):
        s, d = call(self.b, "GET", "/districts/raichur/indicators", role="auditor"); self.assertEqual(s, 200); self.assertAlmostEqual(d["dgpi_implied"], 4.03, 2); self.assertEqual(d["rank_implied"], 1)
    def test_district_officer_scope(self):
        self.assertEqual(call(self.b, "GET", "/districts/raichur/indicators", role="district_officer", district="raichur")[0], 200)
        self.assertEqual(call(self.b, "GET", "/districts/mysuru/indicators", role="district_officer", district="raichur")[0], 403)
        self.assertEqual(call(self.b, "GET", "/districts/mysuru/indicators", role="district_officer")[0], 403)   # no home district: denied
    def test_no_role_denied(self): self.assertEqual(call(self.b, "GET", "/districts/raichur/indicators")[0], 403)
    def test_gate_real_is_insufficient(self):
        s, g = call(self.b, "GET", "/districts/raichur/gate", role="department_officer"); self.assertEqual(g["status"], "EVIDENCE_INSUFFICIENT"); self.assertFalse(g["evidence_is_mock"])
    def test_three_scenarios_route_differently(self):
        st = {sc: call(self.b, "GET", f"/districts/raichur/gate?scenario={sc}", role="auditor")[1]["status"] for sc in ("real", "low_vacancy", "high_vacancy")}
        self.assertEqual(len(set(st.values())), 3); self.assertTrue(call(self.b, "GET", "/districts/raichur/gate?scenario=low_vacancy", role="auditor")[1]["evidence_is_mock"])
    def test_decision_blocked_without_evidence(self):
        s, d = call(self.b, "POST", "/ledger", user="o1", role="department_officer", body={"district": "raichur", "decision": "ACCEPT_FOR_INVESTIGATION"}); self.assertEqual(s, 409); self.assertEqual(d["error"], "gate_blocked")
    def test_decision_allowed_when_corroborated_mock(self):
        s, d = call(self.b, "POST", "/ledger", user="o1", role="department_officer", body={"district": "raichur", "decision": "DEFER", "note": "check vacancies", "scenario": "low_vacancy"}); self.assertEqual(s, 201); self.assertTrue(d["chain_valid"])
    def test_auditor_cannot_decide_and_denial_is_logged(self):
        n = len(A.STORE.ledger.rows); s, _ = call(self.b, "POST", "/ledger", user="a1", role="auditor", body={"district": "raichur", "decision": "DEFER", "scenario": "low_vacancy"}); self.assertEqual(s, 403)
        self.assertGreater(len(A.STORE.ledger.rows), n); self.assertEqual(A.STORE.ledger.rows[-1]["body"]["action"], "ACCESS_DENIED")
    def test_audit_only_for_auditor_and_chain_valid(self):
        self.assertEqual(call(self.b, "GET", "/audit", role="district_officer", district="raichur")[0], 403)
        s, d = call(self.b, "GET", "/audit", role="auditor"); self.assertEqual(s, 200); self.assertTrue(d["chain_valid"])
    def test_unknown_district_404(self): self.assertEqual(call(self.b, "GET", "/districts/atlantis/indicators", role="auditor")[0], 404)
if __name__ == "__main__": unittest.main()
