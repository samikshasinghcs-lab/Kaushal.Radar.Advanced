import sys, os, unittest, scale_test
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "ai_layer"))
class T(unittest.TestCase):
    def test_scale_fast_and_labelled(self):
        r = scale_test.run(); self.assertEqual(r["label"], "SYNTHETIC_DEMONSTRATION"); self.assertLess(r["india_district_750"]["seconds"], 5)
        self.assertEqual(r["taluk_240"]["flags"], 480)
if __name__ == "__main__": unittest.main()
