"""Emits Postgres INSERT SQL from the SQLite store (no driver needed). Usage: python migrate_to_postgres.py store.db > load.sql
Idempotent: ON CONFLICT DO NOTHING. Not run against a live Postgres here."""
import sqlite3, sys
def q(v): return "NULL" if v is None else (str(v) if isinstance(v, (int, float)) else "'" + str(v).replace("'", "''") + "'")
def dump(path):
    c = sqlite3.connect(path); out = [open(__file__.replace("migrate_to_postgres.py", "schema_postgres.sql")).read()]
    for t, cols in (("datasets", "id,source,period,content_hash,status,synthetic"), ("observations", "dataset_id,geo_level,geo_code,indicator,value,unit")):
        for r in c.execute(f"SELECT {cols} FROM {t}"):
            vals = [q(v) for v in r]
            if t == "datasets": vals[-1] = "TRUE" if r[-1] else "FALSE"
            out.append(f"INSERT INTO {t}({cols}) VALUES({','.join(vals)}) ON CONFLICT DO NOTHING;")
    return "\n".join(out)
if __name__ == "__main__": print(dump(sys.argv[1]))
