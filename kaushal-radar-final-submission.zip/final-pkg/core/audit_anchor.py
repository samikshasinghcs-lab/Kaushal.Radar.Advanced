"""Anchors the ledger tail so truncation (deleting the newest rows) is detected. The chain alone cannot see that.
Prototype: in production the anchor goes to a separate write-once store or signed timestamp service."""
import json, hmac, hashlib
def anchor(ledger, key: bytes):
    tail = ledger.rows[-1]["hash"] if ledger.rows else "GENESIS"; msg = json.dumps({"n": len(ledger.rows), "tail": tail}, sort_keys=True)
    return {"n": len(ledger.rows), "tail": tail, "mac": hmac.new(key, msg.encode(), hashlib.sha256).hexdigest()}
def verify_anchor(ledger, a, key: bytes):
    msg = json.dumps({"n": a["n"], "tail": a["tail"]}, sort_keys=True)
    if not hmac.compare_digest(a["mac"], hmac.new(key, msg.encode(), hashlib.sha256).hexdigest()): return False, "anchor forged"
    if len(ledger.rows) < a["n"]: return False, "TRUNCATED: ledger shorter than anchor"
    if a["n"] and ledger.rows[a["n"] - 1]["hash"] != a["tail"]: return False, "REWRITTEN before anchor"
    return ledger.verify(), "ok" if ledger.verify() else "chain broken"
