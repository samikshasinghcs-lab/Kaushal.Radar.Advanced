"""Durable store: idempotent dataset refresh, job queue, backup/restore. SQLite here; schema_postgres.sql is the same model for Postgres.
Postgres itself is NOT RUN in this repo (no server in the build environment). Standard SQL only, so the move is a driver swap plus the migration file."""
import sqlite3, json, hashlib, time, os, shutil
DDL = """
CREATE TABLE IF NOT EXISTS datasets(id INTEGER PRIMARY KEY AUTOINCREMENT, source TEXT NOT NULL, period TEXT NOT NULL, content_hash TEXT NOT NULL,
  loaded_at REAL NOT NULL, status TEXT NOT NULL DEFAULT 'CURRENT', synthetic INTEGER NOT NULL DEFAULT 0, UNIQUE(source, period, content_hash));
CREATE TABLE IF NOT EXISTS observations(dataset_id INTEGER NOT NULL REFERENCES datasets(id), geo_level TEXT NOT NULL, geo_code TEXT NOT NULL,
  indicator TEXT NOT NULL, value REAL, unit TEXT, PRIMARY KEY(dataset_id, geo_level, geo_code, indicator));
CREATE TABLE IF NOT EXISTS jobs(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, key TEXT NOT NULL UNIQUE, payload TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'QUEUED', attempts INTEGER NOT NULL DEFAULT 0, run_after REAL NOT NULL DEFAULT 0, error TEXT);
"""
def _h(rows): return hashlib.sha256(json.dumps(rows, sort_keys=True, default=str).encode()).hexdigest()
class Store:
    def __init__(self, path=":memory:"):
        self.path = path; self.c = sqlite3.connect(path, check_same_thread=False); self.c.executescript(DDL); self.c.commit()
    # ---- idempotent incremental refresh ----
    def refresh(self, source, period, rows, synthetic=False):
        """rows: [{geo_level, geo_code, indicator, value, unit}]. Same content -> UNCHANGED. Changed content for the same period -> new version,
        old one marked SUPERSEDED (never silently overwritten). Whole load is one transaction."""
        h = _h(rows)
        if self.c.execute("SELECT 1 FROM datasets WHERE source=? AND period=? AND content_hash=?", (source, period, h)).fetchone(): return {"result": "UNCHANGED", "hash": h}
        with self.c:
            self.c.execute("UPDATE datasets SET status='SUPERSEDED' WHERE source=? AND period=? AND status='CURRENT'", (source, period))
            cur = self.c.execute("INSERT INTO datasets(source,period,content_hash,loaded_at,synthetic) VALUES(?,?,?,?,?)", (source, period, h, time.time(), int(synthetic)))
            self.c.executemany("INSERT INTO observations VALUES(?,?,?,?,?,?)", [(cur.lastrowid, r["geo_level"], r["geo_code"], r["indicator"], r["value"], r.get("unit")) for r in rows])
        return {"result": "LOADED", "dataset_id": cur.lastrowid, "rows": len(rows), "hash": h}
    def current(self, source, period):
        return self.c.execute("SELECT o.geo_level,o.geo_code,o.indicator,o.value FROM observations o JOIN datasets d ON d.id=o.dataset_id WHERE d.source=? AND d.period=? AND d.status='CURRENT' ORDER BY 1,2,3", (source, period)).fetchall()
    # ---- job queue (idempotent by key, retries with backoff, dead-letter) ----
    def enqueue(self, kind, key, payload, now=None):
        try:
            with self.c: self.c.execute("INSERT INTO jobs(kind,key,payload,run_after) VALUES(?,?,?,?)", (kind, key, json.dumps(payload), now or 0)); return True
        except sqlite3.IntegrityError: return False            # same key already queued or done: not enqueued twice
    def claim(self, now=None):
        n = now or time.time()
        with self.c:
            r = self.c.execute("SELECT id,kind,payload FROM jobs WHERE status='QUEUED' AND run_after<=? ORDER BY id LIMIT 1", (n,)).fetchone()
            if not r: return None
            self.c.execute("UPDATE jobs SET status='RUNNING', attempts=attempts+1 WHERE id=?", (r[0],)); return {"id": r[0], "kind": r[1], "payload": json.loads(r[2])}
    def done(self, jid):
        with self.c: self.c.execute("UPDATE jobs SET status='DONE' WHERE id=?", (jid,))
    def fail(self, jid, err, now=None, max_attempts=3, backoff=30):
        with self.c:
            a = self.c.execute("SELECT attempts FROM jobs WHERE id=?", (jid,)).fetchone()[0]
            if a >= max_attempts: self.c.execute("UPDATE jobs SET status='DEAD', error=? WHERE id=?", (str(err)[:300], jid))
            else: self.c.execute("UPDATE jobs SET status='QUEUED', error=?, run_after=? WHERE id=?", (str(err)[:300], (now or time.time()) + backoff * 2 ** (a - 1), jid))
    def run_worker(self, handlers, now=None):
        n = 0
        while (j := self.claim(now)):
            try: handlers[j["kind"]](j["payload"]); self.done(j["id"])
            except Exception as e: self.fail(j["id"], e, now)
            n += 1
        return n
    # ---- backup / restore with manifest ----
    def fingerprint(self):
        return {t: self.c.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in ("datasets", "observations", "jobs")} | {"hash": _h(self.c.execute("SELECT * FROM observations ORDER BY 1,2,3,4").fetchall())}
    def backup(self, dest):
        d = sqlite3.connect(dest); self.c.backup(d); d.close()
        m = {"fingerprint": self.fingerprint(), "sha256": hashlib.sha256(open(dest, "rb").read()).hexdigest()}; json.dump(m, open(dest + ".manifest.json", "w")); return m
def restore(src, dest=":memory:"):
    m = json.load(open(src + ".manifest.json"))
    if hashlib.sha256(open(src, "rb").read()).hexdigest() != m["sha256"]: raise ValueError("backup corrupted: checksum mismatch")
    s = Store(dest); b = sqlite3.connect(src); b.backup(s.c); b.close()
    if s.c.execute("PRAGMA integrity_check").fetchone()[0] != "ok": raise ValueError("integrity_check failed")
    if s.fingerprint() != m["fingerprint"]: raise ValueError("restored data differs from manifest")
    return s
