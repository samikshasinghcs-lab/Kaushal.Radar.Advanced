"""SYNTHETIC scale test: random rows at taluk (~240) and all-India district (~750) scale. Proves the code scales; says nothing about real data."""
import random, time, labour_intelligence as L
def synth(n, seed=1):
    r = random.Random(seed); return [dict(key=f"s{i}", District=f"S{i}", income_lakh=r.uniform(1, 9), dgpi_per_1000=r.uniform(0, 5), dgpi_census=r.uniform(0, 5), msme_jobs_per_1000=r.uniform(50, 600)) for i in range(n)]
def run():
    out = {"label": "SYNTHETIC_DEMONSTRATION"}
    for name, n in (("taluk_240", 240), ("india_district_750", 750), ("stress_10000", 10000)):
        rows = synth(n); t = time.time(); q = L.two_sided(rows); fl = [x for r in rows for x in L.flags_for(r, q[r["key"]])]; out[name] = {"n": n, "flags": len(fl), "seconds": round(time.time() - t, 3)}
    return out
if __name__ == "__main__": print(run())
