"""Structured JSON logs. Never log personal data or tokens."""
import json, sys, time
def log(event, **kw):
    kw = {k: ("***" if k in ("token", "password", "secret") else v) for k, v in kw.items()}
    sys.stderr.write(json.dumps({"ts": round(time.time(), 3), "event": event, **kw}) + "\n")
