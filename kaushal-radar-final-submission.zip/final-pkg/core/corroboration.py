"""Corroboration Gate for EVERY engine (not only DGPI). A signal may be investigated freely, but an ACTION decision needs independent evidence.
Self-declared corroboration never counts. 'Independent' means a different source owner and a different measurement route."""
ENGINES = {  # engine -> evidence categories it needs, minimum independent categories that must support
 "two_sided": ("supply", "demand", "outcome", "wage"), "employment": ("vacancy", "hires", "retention"), "business": ("registration", "active_status", "employment"),
 "skills": ("local_vacancy_text", "training_output", "employer_survey"), "inclusion": ("participation", "education", "local_access"),
 "wage": ("wage_survey", "payroll", "minimum_wage_check"), "forecast": ("history", "holdout_validation")}
MIN_SUPPORT = 2
def gate(engine, evidence, now_year=2026, max_age=3):
    """evidence: [{category, source, independent: bool, supports: bool, year, self_declared: bool}]"""
    if engine not in ENGINES: raise KeyError(engine)
    need = ENGINES[engine]; good, why = {}, []
    for e in evidence:
        if e.get("self_declared"): why.append(f"ignored self-declared {e.get('category')}"); continue
        if not e.get("independent"): why.append(f"ignored non-independent {e.get('category')}"); continue
        if e["category"] not in need: why.append(f"ignored off-topic {e['category']}"); continue
        if now_year - e.get("year", 0) > max_age: why.append(f"stale {e['category']}"); continue
        good[e["category"]] = e
    sources = {e["source"] for e in good.values()}
    sup = [c for c, e in good.items() if e["supports"]]; con = [c for c, e in good.items() if not e["supports"]]
    if len(good) < MIN_SUPPORT or len(sources) < MIN_SUPPORT: st = "EVIDENCE_INSUFFICIENT"
    elif len(con) >= 2 and len(con) >= len(sup): st = "SIGNALS_DIVERGE"
    elif len(sup) >= MIN_SUPPORT and not con: st = "CORROBORATED"
    else: st = "PARTIAL"
    return {"engine": engine, "status": st, "supporting": sup, "contradicting": con, "missing": [c for c in need if c not in good], "notes": why}
def allows_action(g): return g["status"] == "CORROBORATED"
