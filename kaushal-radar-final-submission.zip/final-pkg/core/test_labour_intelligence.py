import unittest, labour_intelligence as L, decision_engine as E
class T(unittest.TestCase):
    rows = L.load()
    def test_31_districts(self): self.assertEqual(len(self.rows), 31)
    def test_dgpi_reproducible(self):
        r = next(x for x in self.rows if x["key"] == "raichur"); self.assertAlmostEqual(r["Grand Total"] / r["implied_pop"] * 1000, r["dgpi_per_1000"], 3)
    def test_high_gdp_can_flag(self): self.assertTrue(any(f["flag"] == "High-GDP Labour Risk" for f in L.all_flags()))
    def test_low_gdp_can_flag(self): self.assertTrue(any(f["flag"] == "Employment Pressure" for f in L.all_flags()))
    def test_no_causation_no_auto_approval(self):
        for f in L.all_flags(): self.assertFalse(f["causation_claimed"]); self.assertEqual(f["human_approval"], "PENDING")
    def test_card_has_all_fields(self):
        c = L.intervention_card([f for f in L.all_flags() if f["status"] == L.BUILT_WITH_LIMITATIONS][0])
        self.assertEqual(set(c), set(L.FIELDS))
        self.assertEqual(c["human_approval_status"], "PENDING")
    def test_wrong_role_cannot_approve(self):
        c = L.intervention_card(L.all_flags()[0])
        with self.assertRaises(PermissionError): L.approve(c, "analyst", "APPROVED_FOR_INVESTIGATION")
    def test_missing_feeds_blocked_not_invented(self):
        for f in L.all_flags():
            if f["flag"] == "Evidence Gap" and f["track"] == "ALL": self.assertEqual(f["status"], L.BLOCKED)
    def test_synthetic_stays_labelled(self): self.assertEqual(L.pulse_sample()["status"], L.SYNTH)
    def test_ratio_refuses_real_without_hiring(self):
        s = L.pulse_sample(); s["status"] = "REAL"; self.assertIsNone(L.formation_to_hiring_ratio(s))
    def test_proposed_cards_have_4_fields(self):
        for p in L.PROPOSED_REGISTER: self.assertEqual(len(p), 4); self.assertTrue(all(p))
    def test_gate_unchanged(self): self.assertEqual(E.gate("A", True, 0.9, E.mock_cards("insufficient"))["status"], "EVIDENCE_INSUFFICIENT")
if __name__ == "__main__": unittest.main()
