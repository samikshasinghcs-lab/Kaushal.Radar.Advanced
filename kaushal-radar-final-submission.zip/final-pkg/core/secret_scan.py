"""Small secret scanner for CI (no network). Flags private keys, cloud keys, tokens and hard-coded secrets. Run: python core/secret_scan.py [root]"""
import re, os, sys
PATTERNS = {"private_key": r"-----BEGIN (RSA |EC |OPENSSH |)PRIVATE KEY-----", "aws_access_key": r"\bAKIA[0-9A-Z]{16}\b", "github_token": r"\bgh[pousr]_[A-Za-z0-9]{36,}\b",
            "slack_token": r"\bxox[baprs]-[A-Za-z0-9-]{10,}\b", "anthropic_key": r"\bsk-ant-[A-Za-z0-9_-]{20,}\b", "generic_secret": r"(?i)\b(secret|password|passwd|api[_-]?key|token)\b\s*[:=]\s*['\"][A-Za-z0-9/+_\-]{16,}['\"]"}
SKIP_DIR = {".git", "__pycache__", "node_modules"}; SKIP_EXT = {".xlsx", ".zip", ".png", ".jpg", ".pdf", ".pyc", ".db"}
def scan_text(t): return [n for n, p in PATTERNS.items() if re.search(p, t)]
def scan(root="."):
    hits = []
    for d, ds, fs in os.walk(root):
        ds[:] = [x for x in ds if x not in SKIP_DIR]
        for f in fs:
            if os.path.splitext(f)[1] in SKIP_EXT or f == "secret_scan.py" or f.startswith("test_"): continue
            try: t = open(os.path.join(d, f), encoding="utf-8").read()
            except (UnicodeDecodeError, OSError): continue
            hits += [(os.path.join(d, f), n) for n in scan_text(t)]
    return hits
if __name__ == "__main__":
    h = scan(sys.argv[1] if len(sys.argv) > 1 else "."); [print("SECRET?", *x) for x in h]; sys.exit(1 if h else 0)
