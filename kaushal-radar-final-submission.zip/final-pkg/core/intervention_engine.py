"""Turns flags into draft cards, records every human decision on the hash-chained ledger. Engine cannot approve."""
import labour_intelligence as L
from decision_engine import Ledger
class Engine:
    def __init__(self): self.ledger = Ledger(); self.cards = {}
    def draft(self, flag):
        c = L.intervention_card(flag); cid = f"{c['district']}:{c['detected_condition']}"; self.cards[cid] = c
        self.ledger.record("engine", "system", "DRAFTED", {"card": cid}); return cid
    def decide(self, cid, officer, role, decision, gate=None):
        if decision == "APPROVED_FOR_ACTION" and not (gate and gate.get("status") == "CORROBORATED"):
            raise PermissionError("ACTION needs a corroborated gate result; investigation does not")     # self-declared evidence never reaches here
        self.cards[cid] = L.approve(self.cards[cid], role, decision)      # raises for wrong role
        self.ledger.record(officer, role, "HUMAN_DECISION", {"card": cid, "decision": decision}); return self.cards[cid]
    def outcome(self, cid, metric, before, after, months):
        if months < 6 or before is None or after is None: return {"status": "NOT_MEASURED", "why": "needs follow-up window and both measurements"}
        return {"status": "MEASURED_NOT_CAUSAL", "delta": round(after - before, 3), "metric": metric, "note": "no comparison group, so not an impact estimate"}
