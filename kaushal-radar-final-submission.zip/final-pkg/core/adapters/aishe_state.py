"""AISHE Final Report 2023-24 (MoE) state-level adapter. Reads the official workbook, checks the header text at every column it uses
(schema-drift guard), and returns indicators with sheet/cell provenance. STATE LEVEL ONLY: AISHE tables here have no district rows,
so nothing is derived for districts."""
import openpyxl
SRC = "AISHE Final Report 2023-24 (Ministry of Education)"
# sheet -> (header row index, {indicator: (column index, expected header text, unit)})
SPEC = {
 "1.UniNo": (1, {"universities_total": (12, "Grand Total", "count")}),
 "4CollegeIndicator": (1, {"colleges": (2, "No. of Colleges", "count"), "colleges_per_lakh_pop_18_23": (3, "No. of Colleges per lakh population", "per lakh")}),
 "6TotalEnr": (1, {"enrolment_total": (28, "Grand Total", "persons"), "enrolment_ug_total": (13, "Under Graduate", "persons")}),
 "25PTR": (1, {"ptr_all_institutions_regular_and_distance": (2, "All Institutions", "ratio"), }),
 "33 Out Turn": (1, {"outturn_total": (28, "Grand Total", "persons"), "outturn_ug": (13, "Under Graduate", "persons")}),
}
def _rows(wb, name): return list(wb[name].iter_rows(values_only=True))
def _hdr_ok(rows, hrow, col, text):
    h = rows[hrow]; last = None
    for i in range(col + 1):                      # merged headers: the label sits at the first column of its group
        if h[i] is not None: last = h[i]
    return last is not None and " ".join(str(last).split()).lower() == text.lower()
def extract(path, state="Karnataka"):
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True); out = []
    for sheet, (hrow, cols) in SPEC.items():
        rows = _rows(wb, sheet); ri = next((i for i, r in enumerate(rows) if len(r) > 1 and isinstance(r[1], str) and r[1].strip() == state), None)
        if ri is None: raise ValueError(f"SCHEMA_DRIFT: {state} not found in {sheet}")
        for ind, (col, text, unit) in cols.items():
            if not _hdr_ok(rows, hrow, col, text): raise ValueError(f"SCHEMA_DRIFT: {sheet} col {col} header is not '{text}'")
            v = rows[ri][col]
            out.append(dict(indicator=ind, value=v, unit=unit, state=state, period="2023-24", source=SRC, sheet=sheet, row=ri + 1, col=col + 1, coverage="state",
                            frequency="annual", status="BUILT_WITH_LIMITATIONS", limitations="State level; survey response-based; do not project to districts"))
    rows = _rows(wb, "47GER  19")   # GER trend: state label row, then year rows (all M, F, Both, SC..., ST...)
    def ger(label):
        i = next(i for i, r in enumerate(rows) if r and any(isinstance(x, str) and x.strip() == label for x in r))
        return {r[1]: r for r in rows[i + 1:i + 6]}
    for yr in ("2023-24", "2022-23"):
        r = ger(state)[yr]
        for nm, ix in (("ger_all", 4), ("ger_sc", 7), ("ger_st", 10)):
            out.append(dict(indicator=f"{nm}_{yr}", value=r[ix], unit="percent", state=state, period=yr, source=SRC, sheet="47GER  19", row=None, col=ix + 1, coverage="state",
                            frequency="annual", status="BUILT_WITH_LIMITATIONS", limitations="GER depends on the population projection used by AISHE"))
    ai = ger("All India")["2023-24"]
    out.append(dict(indicator="ger_all_india_2023-24", value=ai[4], unit="percent", state="All India", period="2023-24", source=SRC, sheet="47GER  19", row=None, col=5,
                    coverage="national", frequency="annual", status="BUILT_WITH_LIMITATIONS", limitations="National benchmark"))
    return out
def colleges_per_lakh_rank(path, state="Karnataka"):
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True); vals = {}
    for r in _rows(wb, "4CollegeIndicator")[4:]:
        if len(r) > 3 and isinstance(r[1], str) and isinstance(r[3], (int, float)): vals[r[1].strip()] = r[3]
    order = sorted(vals, key=lambda k: -vals[k]); return {"rank": order.index(state) + 1, "of": len(order), "value": vals[state]}
