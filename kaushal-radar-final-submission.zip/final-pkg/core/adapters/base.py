"""Adapter template: one adapter per source. Declares expected columns, maps drift, rejects PII, tags provenance. Add a test per adapter."""
import csv, io, security as S
class Adapter:
    source = ""; frequency = ""; required = (); aliases = {}; geography = ""
    def parse(self, raw: bytes, ref_period):
        rows = list(csv.DictReader(io.StringIO(raw.decode("utf-8-sig")))); cols = rows[0].keys() if rows else []
        ren = {c: self.aliases.get(c.strip().lower(), c.strip().lower()) for c in cols}
        pii = S.reject_pii([v for v in ren.values() if v not in self.required])   # known mapped columns (e.g. 'District Name') are not PII
        if pii: return {"accepted": False, "reason": f"PII columns refused: {pii}"}
        out = [{ren[k]: v for k, v in r.items()} for r in rows]
        drift = sorted(set(self.required) - set(out[0])) if out else list(self.required)
        if drift: return {"accepted": False, "reason": f"SCHEMA_DRIFT missing {drift}", "seen": sorted(ren.values())}
        return {"accepted": True, "source": self.source, "frequency": self.frequency, "geography": self.geography, "reference_period": ref_period, "rows": out, "verification": "NOT_TESTED_ON_OFFICIAL_FILE"}
