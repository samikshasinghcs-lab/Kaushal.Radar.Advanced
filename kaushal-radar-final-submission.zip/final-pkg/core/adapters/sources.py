from adapters.base import Adapter
class AISHE(Adapter): source="AISHE (MoE)"; frequency="annual"; geography="district/state"; required=("district","institutions","enrolment"); aliases={"district name":"district","no. of colleges":"institutions","total enrolment":"enrolment"}
class PLFS(Adapter): source="MoSPI PLFS tables"; frequency="annual"; geography="state"; required=("state","indicator","value","period"); aliases={"state/ut":"state"}
class NCO(Adapter): source="NCO-2015 (MoLE)"; frequency="static"; geography="national"; required=("code","title"); aliases={"nco code":"code","occupation":"title"}
class ITI(Adapter): source="ITI list (DGT/NCVT)"; frequency="annual"; geography="district"; required=("district","iti_name","seats"); aliases={"seat capacity":"seats"}
class Census(Adapter): source="Census 2011"; frequency="decennial (2011)"; geography="district"; required=("district","literacy_pct","sc_pct","st_pct")
REGISTRY = {c.__name__: c for c in (AISHE, PLFS, NCO, ITI, Census)}
