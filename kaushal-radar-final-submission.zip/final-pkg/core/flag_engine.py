"""All 12 flags. Rules run only when the needed feed is supplied; otherwise BLOCKED_PENDING_DATA (never a guess).
Feeds come from authorised department files via ingest.py. Synthetic feeds must carry synthetic=True and the flag inherits it."""
import labour_intelligence as L
FLAGS = {  # flag: (needed feed keys, rule, action, department)
 "Employment Pressure": ((), None, None, None),   # computed by labour_intelligence.two_sided on real data
 "High-GDP Labour Risk": ((), None, None, None),
 "Skill Mismatch": (("vacancy_skills", "trained_skills"), lambda f: any(f["vacancy_skills"].get(s, 0) > 2 * f["trained_skills"].get(s, 0) for s in f["vacancy_skills"]), "Align training to named in-demand skills", "Skill Development Dept"),
 "Business Contraction": (("closures", "openings"), lambda f: f["closures"] > f["openings"], "Verify closures; enterprise support check", "Industries & Commerce"),
 "Wage Risk": (("median_wage", "state_median_wage"), lambda f: f["median_wage"] < 0.8 * f["state_median_wage"], "Check job quality and minimum-wage compliance", "Labour Dept"),
 "Workforce Exclusion": (("group_participation", "overall_participation"), lambda f: f["group_participation"] < 0.7 * f["overall_participation"], "Targeted inclusion pathway pilot", "Labour Dept; Women & Child Dept"),
 "Education Gap": (("share_below_secondary", "vacancy_min_education_secondary"), lambda f: f["share_below_secondary"] > 0.4 and f["vacancy_min_education_secondary"] > 0.5, "Bridge education and RPL", "School/Higher Education; Skill Dept"),
 "Skill Transition": (("declining_occupation_share",), lambda f: f["declining_occupation_share"] > 0.25, "RPL and bridge training for affected workers", "Skill Development Dept"),
 "Training Shortage": (("training_seats", "demand_seats"), lambda f: f["training_seats"] < 0.6 * f["demand_seats"], "Expand or relocate seats", "Skill Development Dept; ITI"),
 "Growth Opportunity": (("openings", "closures", "verified_hires_trend"), lambda f: f["openings"] > f["closures"] and f["verified_hires_trend"] > 0, "Match training to growing employers", "Industries & Commerce"),
 "Rural Employment Gap": (("rural_jobs_within_10km_share",), lambda f: f["rural_jobs_within_10km_share"] < 0.3, "Rural enterprise and transport linkage", "RDPR; Labour Dept"),
 "Evidence Gap": ((), None, None, None)}
def evaluate(flag, feeds=None, synthetic=False):
    need, rule, action, dept = FLAGS[flag]
    if rule is None: return {"flag": flag, "status": "SEE_labour_intelligence"}
    feeds = feeds or {}; miss = [k for k in need if feeds.get(k) is None]
    if miss: return {"flag": flag, "status": L.BLOCKED, "missing": miss, "raised": False}
    raised = bool(rule(feeds))
    return {"flag": flag, "raised": raised, "status": L.SYNTH if synthetic else L.BUILT_WITH_LIMITATIONS, "recommended_action": action, "responding_department": dept,
            "confidence": "LOW" if synthetic else "MEDIUM", "limitations": ["Signal for human review; not proof of cause"], "human_approval": "PENDING", "causation_claimed": False}
def evaluate_all(feeds=None, synthetic=False): return [evaluate(f, feeds, synthetic) for f in FLAGS]
