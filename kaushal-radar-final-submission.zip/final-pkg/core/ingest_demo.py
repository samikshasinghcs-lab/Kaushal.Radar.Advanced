"""Departmental ingestion walk-through over HTTP: upload -> validate -> harmonise -> store -> retrieve evidence card. SAMPLE (synthetic) files."""
import json, os, urllib.request, urllib.error, api_server as A
D = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data", "samples"); srv = A.serve(0); B = f"http://127.0.0.1:{srv.server_address[1]}"
def call(m, path, role, user, body=None):
    req = urllib.request.Request(B + path, data=body, headers={"X-User": user, "X-Role": role}, method=m)
    try:
        with urllib.request.urlopen(req) as r: code, out = r.status, json.loads(r.read())
    except urllib.error.HTTPError as e: code, out = e.code, json.loads(e.read())
    print(f"\n> {m} {path}  [role={role}]\n< {code} {json.dumps(out)[:520]}"); return out
def f(n):
    with open(os.path.join(D, n), "rb") as fh: return fh.read()
r = call("POST", "/ingest?source=SAMPLE%20department%20feed&ref_year=2026", "department_officer", "officer1", f("sample_dept_upload_good.csv"))
call("GET", f"/ingest/{r['upload_id']}/evidence-card/102", "auditor", "auditor1")
call("POST", "/ingest?source=SAMPLE", "department_officer", "officer1", f("sample_dept_upload_with_pii.csv"))
call("POST", "/ingest?source=SAMPLE", "department_officer", "officer1", f("sample_dept_upload_schema_drift.csv"))
call("POST", "/ingest?source=SAMPLE", "district_officer", "d1", f("sample_dept_upload_good.csv"))
call("GET", "/audit", "auditor", "auditor1"); srv.shutdown()
