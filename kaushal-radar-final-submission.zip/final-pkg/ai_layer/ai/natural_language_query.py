"""Natural-language query -> validated, allow-listed query object. No SQL/Python is ever generated."""
import re

from . import districts
from .exceptions import InputRejected
from .schemas import QUERY_SCHEMA, validate

_RULES = [("CONTRADICTIONS", r"contradict|conflict|disagree|inconsisten"),
          ("UNCERTAINTY", r"reliab|uncertain|confiden|stale|trust|denominator|missing|how sure"),
          ("WHY_FLAGGED", r"\bwhy\b|\bflag"),
          ("INDICATORS", r"indicator|ratio|\brate\b|figures|numbers|statistic")]
_ID = re.compile(r"\bKA-\d{3}\b", re.I)


def parse_question(question, district_id=None):
    q = question.lower()
    found = districts.find_districts_in_text(question)
    id_hits = [m.upper() for m in _ID.findall(question)]
    for h in id_hits:
        if not districts.is_valid_id(h):
            raise InputRejected("unknown district identifier in question", code="INVALID_DISTRICT")
    ids = list(dict.fromkeys(found + id_hits))
    if district_id and ids and any(i != district_id for i in ids):
        raise InputRejected("district in question does not match district_id parameter", code="DISTRICT_MISMATCH")
    if not district_id:
        if len(ids) > 1:
            raise InputRejected("one district per query", code="MULTIPLE_DISTRICTS")
        if not ids:
            raise InputRejected("no recognised district in the question", code="NO_DISTRICT")
        district_id = ids[0]
    intent = "FULL_BRIEF"
    for name, rx in _RULES:
        if re.search(rx, q):
            intent = name
            break
    query = {"intent": intent, "district_id": district_id, "district_name": districts.name_of(district_id)}
    return validate(query, QUERY_SCHEMA)
