"""Policy brief assembly. Deterministic facts are always shown; AI sections appear only if validated."""
BANNER_SYNTHETIC = "SYNTHETIC TEST DATA - NOT OFFICIAL GOVERNMENT STATISTICS"
SECTION_ORDER = [("evidence_analyst", "Supporting evidence"), ("contradiction_analyst", "Contradictions and tensions"),
                 ("anomaly_explainer", "Statistical anomalies"), ("uncertainty_explainer", "Uncertainty and data quality"),
                 ("recommendation_explainer", "Decision status explanation"), ("policy_brief", "Suggested investigations")]


def assemble(brief_id, bundle, decision, task_results, validation_passed):
    sections = []
    for task, title in SECTION_ORDER:
        tr = task_results.get(task)
        if tr is None:
            continue
        ok = tr["validation"]["passed"]
        sections.append({
            "section": task, "title": title, "origin": "AI_ADVISORY",
            "status": "VALIDATED" if ok else "WITHHELD_FAILED_VALIDATION",
            "claims": [{"claim_id": c["claim_id"], "kind": c["kind"], "text": c["text"], "evidence_ids": c["evidence_ids"],
                        "indicator_ids": c["indicator_ids"], "numbers": c["numbers"]} for c in tr["output"]["claims"]] if ok else [],
            "violation_codes": sorted({v["code"] for v in tr["validation"]["violations"]}),
        })
    return {
        "brief_id": brief_id, "district": {"id": bundle.district_id, "name": bundle.district_name},
        "banner": BANNER_SYNTHETIC if "SYNTHETIC" in bundle.data_classes else None,
        "data_classes": bundle.data_classes, "reference_date": bundle.reference_date.isoformat(),
        "decision_status": decision["status"], "confidence": bundle.confidence["level"],
        "verification_status": "AUTOMATED_CHECKS_PASSED" if validation_passed else "AUTOMATED_CHECKS_FAILED_AI_TEXT_WITHHELD",
        "verification_note": "Automated checks passing is not human verification; human review is required.",
        "sections": sections,
        "limitations": ["Deterministic values are authoritative; AI text is advisory.",
                        "The AI layer cannot approve funding, authorise action or change the decision status."],
        "human_review": {"required": True, "status": "PENDING"},
    }
