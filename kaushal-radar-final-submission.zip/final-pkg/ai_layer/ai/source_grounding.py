"""Source-grounding engine: every factual claim must cite existing, AUTHORISED evidence."""
import re

ID_IN_TEXT = re.compile(r"\b(?:EV|SRC|IND|CON|AN|SENS|CNT|STALE|CFG|DEC|DEN)_[A-Z0-9_]+\b")
NEEDS_REFS = {"fact", "interpretation"}


def check(output, bundle, store):
    refs = bundle.ref_values()
    authorised = {r["evidence_id"] for r in bundle.records}
    sources_ok = {r["source_id"] for r in bundle.records}
    known_text_ids = authorised | sources_ok | set(refs)
    v = []
    texts = [("summary", output.get("summary", ""))] + [(c["claim_id"], c["text"]) for c in output["claims"]]
    for c in output["claims"]:
        cid = c["claim_id"]
        if c["kind"] in NEEDS_REFS and not (c["evidence_ids"] or c["indicator_ids"]):
            v.append({"code": "MISSING_REFS", "claim_id": cid, "detail": "fact/interpretation without references"})
        for e in c["evidence_ids"]:
            if e in authorised:
                continue
            if store.get(e) is not None:
                v.append({"code": "UNAUTHORISED_EVIDENCE", "claim_id": cid, "detail": "evidence outside the authorised set"})
            else:
                v.append({"code": "UNKNOWN_EVIDENCE", "claim_id": cid, "detail": f"evidence id not found: {e}"})
        for i in c["indicator_ids"]:
            if i not in refs:
                v.append({"code": "UNKNOWN_REF", "claim_id": cid, "detail": f"reference not found: {i}"})
        cited = set(c["evidence_ids"]) | set(c["indicator_ids"])
        for n in c["numbers"]:
            if n["ref"] not in cited:
                v.append({"code": "NUMBER_REF_NOT_CITED", "claim_id": cid, "detail": f"number ref {n['ref']} not listed in claim references"})
    for where, text in texts:
        for tid in sorted(set(ID_IN_TEXT.findall(text))):
            if tid not in known_text_ids:
                v.append({"code": "TEXT_UNKNOWN_ID", "claim_id": where, "detail": f"identifier in text not found/authorised: {tid}"})
    return v
