"""Decision-engine gate. AI never sets or overrides these statuses.

By default a small deterministic rule set maps the bundle to a status. To use the repository's own
decision_engine.py, pass `external_engine(bundle) -> {"status": str, "reason_codes": [..]}`.
"""
STATUSES = ["INSUFFICIENT_EVIDENCE", "DATA_QUALITY_HOLD", "FLAGGED_FOR_REVIEW", "NOT_FLAGGED"]


class DecisionGate:
    def __init__(self, external_engine=None):
        self.external_engine = external_engine

    def evaluate(self, bundle, abstention):
        if self.external_engine:
            r = self.external_engine(bundle)
            status, codes, src = r["status"], list(r.get("reason_codes", [])), "external_decision_engine"
        else:
            src, codes = "builtin_demo_rules", []
            if abstention.abstain:
                status, codes = "INSUFFICIENT_EVIDENCE", list(abstention.reason_codes)
            else:
                stale_primary = [s for s in bundle.stale if s["role"] == "primary"]
                if stale_primary:
                    status, codes = "DATA_QUALITY_HOLD", ["PRIMARY_SOURCE_OUTDATED"]
                elif bundle.flag["status"] == "FLAGGED":
                    status, codes = "FLAGGED_FOR_REVIEW", ["FLAG_RULE_MET"]
                else:
                    status, codes = "NOT_FLAGGED", ["FLAG_RULE_NOT_MET"]
                if any(c["type"] == "GENUINE" for c in bundle.contradictions):
                    codes.append("GENUINE_CONTRADICTION_PRESENT")
                if bundle.denominator_changes:
                    codes.append("DENOMINATOR_BASIS_DIFFERS")
        return {"status": status, "reason_codes": codes, "source": src, "human_review_required": True,
                "ai_may_override": False}

    @staticmethod
    def finalise(decision, validation_passed):
        d = dict(decision)
        d["ai_interpretation_verified"] = bool(validation_passed)
        d["presentable_as_verified"] = bool(validation_passed)
        return d
