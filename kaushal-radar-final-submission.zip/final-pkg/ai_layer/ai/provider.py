"""Provider layer: deterministic mock, real Anthropic adapter, rate limiter, ProviderManager."""
import json
import re
import threading
import time
import urllib.error
import urllib.request
from dataclasses import dataclass

from . import config as cfg
from .exceptions import (MalformedOutput, ProviderFatal, ProviderError, ProviderRateLimit,
                         ProviderTimeout, SchemaValidationError, ConfigError)
from .prompts import get_prompt
from .retry import RetryManager
from .schemas import ANALYST_OUTPUT_SCHEMA, validate


@dataclass
class ProviderResponse:
    text: str
    model: str


class BaseProvider:
    name = "base"
    model = "unknown"

    def complete(self, *, task, system, prompt, context, prompt_version):  # pragma: no cover
        raise NotImplementedError


class MockProvider(BaseProvider):
    """Offline, deterministic, template-based 'interpreter'. NOT a language model."""
    name = "mock"

    def __init__(self, model="mock-deterministic-1"):
        self.model = model

    def complete(self, *, task, system, prompt, context, prompt_version):
        from .mock_analysts import generate
        return ProviderResponse(json.dumps(generate(task, context, prompt_version), sort_keys=True), self.model)


class AnthropicProvider(BaseProvider):
    """Real adapter (Anthropic Messages API). Key is read from ANTHROPIC_API_KEY at call time.

    `transport` is injectable for tests: transport(url, headers, body_bytes, timeout) -> (status, bytes).
    NOT exercised against the live API in this repository's test-suite (no credentials/network).
    """
    name = "anthropic"
    URL = "https://api.anthropic.com/v1/messages"

    def __init__(self, model, timeout_s=20.0, transport=None, env=None, max_tokens=2000):
        self.model, self.timeout_s, self.max_tokens = model, timeout_s, max_tokens
        self._transport = transport or self._urllib_transport
        self._env = env

    @staticmethod
    def _urllib_transport(url, headers, body, timeout):
        req = urllib.request.Request(url, data=body, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.status, r.read()
        except urllib.error.HTTPError as e:
            return e.code, e.read()
        except (TimeoutError, urllib.error.URLError) as e:
            if "timed out" in str(e).lower() or isinstance(e, TimeoutError):
                raise ProviderTimeout("provider timeout") from e
            raise ProviderError("provider connection error") from e

    def complete(self, *, task, system, prompt, context, prompt_version):
        key = cfg.get_api_key(self._env)
        if not key:
            raise ConfigError("ANTHROPIC_API_KEY is not set", code="MISSING_API_KEY")
        body = json.dumps({
            "model": self.model, "max_tokens": self.max_tokens, "system": system,
            "messages": [{"role": "user", "content": prompt + "\n\nCONTEXT_JSON:\n" + json.dumps(context)}],
        }).encode()
        headers = {"content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01"}
        status, raw = self._transport(self.URL, headers, body, self.timeout_s)
        if status == 429:
            raise ProviderRateLimit("rate limited")
        if status in (401, 403, 400):
            raise ProviderFatal(f"provider rejected request ({status})")
        if status >= 500 or status != 200:
            raise ProviderError(f"provider error ({status})")
        try:
            data = json.loads(raw)
            text = "".join(b.get("text", "") for b in data["content"] if b.get("type") == "text")
        except (ValueError, KeyError, TypeError) as e:
            raise MalformedOutput("unparseable provider envelope") from e
        return ProviderResponse(text, self.model)


class RateLimiter:
    """Token bucket. Raises ProviderRateLimit when empty (retryable by RetryManager)."""

    def __init__(self, per_minute, clock=time.monotonic):
        self.capacity = max(1, int(per_minute))
        self.tokens = float(self.capacity)
        self.rate = self.capacity / 60.0
        self.clock = clock
        self._last = clock()
        self._lock = threading.Lock()

    def acquire(self):
        with self._lock:
            now = self.clock()
            self.tokens = min(self.capacity, self.tokens + (now - self._last) * self.rate)
            self._last = now
            if self.tokens < 1:
                raise ProviderRateLimit("local rate limit reached")
            self.tokens -= 1


@dataclass
class CallResult:
    output: dict
    model: str
    prompt_version: str
    attempts: int


_FENCE = re.compile(r"^```(?:json)?\s*(.*?)\s*```$", re.S)


def parse_json_output(text):
    if not isinstance(text, str) or not text.strip():
        raise MalformedOutput("empty provider output")
    t = text.strip()
    m = _FENCE.match(t)
    if m:
        t = m.group(1)
    try:
        obj = json.loads(t)
    except ValueError as e:
        raise MalformedOutput("provider output is not valid JSON") from e
    if not isinstance(obj, dict):
        raise MalformedOutput("provider output is not a JSON object")
    return obj


class ProviderManager:
    def __init__(self, provider, config, retry=None, rate_limiter=None, sleep=time.sleep):
        self.provider, self.config = provider, config
        self.retry = retry or RetryManager(config.max_retries, config.retry_base_delay_s,
                                           config.retry_max_delay_s, sleep=sleep)
        self.rate_limiter = rate_limiter or RateLimiter(config.rate_limit_per_minute)

    @property
    def model(self):
        return self.provider.model

    def complete_json(self, task, context):
        spec = get_prompt(task, self.config.prompt_overrides.get(task))

        def attempt():
            self.rate_limiter.acquire()
            resp = self.provider.complete(task=task, system=spec.system, prompt=spec.instructions,
                                          context=context, prompt_version=spec.version)
            obj = parse_json_output(resp.text)
            try:
                validate(obj, ANALYST_OUTPUT_SCHEMA)
            except SchemaValidationError as e:
                raise MalformedOutput("schema validation failed: " + str(e)) from e
            if obj["task"] != task or obj["prompt_version"] != spec.version:
                raise MalformedOutput("task/prompt_version mismatch in provider output")
            return obj, resp.model

        (obj, model), attempts = self.retry.call(attempt)
        return CallResult(obj, model, spec.version, attempts)


def make_provider(config):
    if config.provider == "mock":
        return MockProvider(config.model)
    if config.provider == "anthropic":
        return AnthropicProvider(config.model, config.request_timeout_s)
    raise ConfigError(f"unknown provider {config.provider}")
