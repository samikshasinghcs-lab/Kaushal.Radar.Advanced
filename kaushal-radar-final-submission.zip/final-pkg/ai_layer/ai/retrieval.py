"""Evidence retrieval: authorisation is enforced BEFORE any record is returned."""
import math
from dataclasses import dataclass, field

from security.access_control import authorize
from security.prompt_injection import quarantine_records
from .evidence_store import METRICS


@dataclass
class RetrievalResult:
    district_id: str
    records: list
    excluded: list = field(default_factory=list)   # internal detail (audit only)

    def ids(self):
        return {r["evidence_id"] for r in self.records}


def _valid_value(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) and v >= 0


def retrieve(store, identity, district_id):
    authorize(identity, "query_district", district_id)
    can_restricted = identity.has("view_restricted_evidence")
    kept, excluded = [], []
    for r in store.district_records(district_id):
        eid = r["evidence_id"]
        if r.get("sensitivity", "public") == "restricted" and not can_restricted:
            excluded.append({"evidence_id": eid, "reason": "RESTRICTED_EVIDENCE"})
        elif r.get("metric") not in METRICS:
            excluded.append({"evidence_id": eid, "reason": "NOT_RELEVANT"})
        elif store.source(r.get("source_id")) is None:
            excluded.append({"evidence_id": eid, "reason": "UNREGISTERED_SOURCE"})
        elif not _valid_value(r.get("value")):
            excluded.append({"evidence_id": eid, "reason": "INVALID_VALUE"})
        else:
            kept.append(dict(r))
    kept, quarantined = quarantine_records(kept)
    for q in quarantined:
        excluded.append({"evidence_id": q["evidence_id"], "reason": "QUARANTINED_INJECTION",
                         "field": q["field"], "matches": q["matches"]})
    return RetrievalResult(district_id, kept, excluded)


def public_exclusions(result):
    """What an end user may see about exclusions: restricted items are only counted, never named."""
    shown = [e for e in result.excluded if e["reason"] != "RESTRICTED_EVIDENCE"]
    restricted = sum(1 for e in result.excluded if e["reason"] == "RESTRICTED_EVIDENCE")
    return {"excluded": [{"evidence_id": e["evidence_id"], "reason": e["reason"]} for e in shown],
            "restricted_withheld_count": restricted}
