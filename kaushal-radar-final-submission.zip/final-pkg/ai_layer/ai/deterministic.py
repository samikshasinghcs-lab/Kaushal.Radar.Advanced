"""Deterministic, authoritative calculations. No AI is involved anywhere in this module.

IMPORTANT: the indicator set and the flag rule here are a transparent *demonstration* rule:
    flagged  <=>  graduate_to_vacancy_ratio >= flag_multiplier x peer median
They are NOT the project's official DGPI. Plug the real DGPI in through `external_flag_fn`
in decision_gate.DecisionGate / see docs/INTEGRATION_NOTES.md.
"""
from dataclasses import dataclass, field
from datetime import date
from statistics import median, mean, pstdev

from .evidence_store import REQUIRED_METRICS, OPTIONAL_METRICS, DENOMINATOR_METRICS

ANOMALY_INDICATORS = ["IND_GVR", "IND_PLR", "IND_TUR", "IND_GPC"]


def _fp(records, metric):
    for r in records:
        if r["metric"] == metric and r.get("role", "primary") == "primary":
            return r
    return None


def compute_indicators(records):
    g, v = _fp(records, "graduates_total"), _fp(records, "vacancies_total")
    s, t, p = _fp(records, "training_seats"), _fp(records, "trained_total"), _fp(records, "placed_total")
    w, lf = _fp(records, "working_age_population"), _fp(records, "labour_force")
    out = {}

    def add(iid, name, num, den, scale, unit, inputs, formula):
        if num is None or den is None or den["value"] <= 0:
            return
        out[iid] = {"indicator_id": iid, "name": name, "value": round(num["value"] / den["value"] * scale, 2),
                    "unit": unit, "inputs": [num["evidence_id"], den["evidence_id"]], "formula": formula}

    add("IND_GVR", "graduate_to_vacancy_ratio", g, v, 1, "ratio", None, "graduates_total / vacancies_total")
    add("IND_PLR", "placement_rate_pct", p, t, 100, "percent", None, "placed_total / trained_total * 100")
    add("IND_TUR", "training_utilisation_pct", t, s, 100, "percent", None, "trained_total / training_seats * 100")
    add("IND_GPC", "graduates_per_1000_working_age", g, w, 1000, "per_1000", None, "graduates_total / working_age_population * 1000")
    add("IND_GPL", "graduates_per_1000_labour_force", g, lf, 1000, "per_1000", None, "graduates_total / labour_force * 1000")
    return out


def peer_indicator_values(store, exclude_district):
    vals = {}
    for did in store.districts():
        if did == exclude_district:
            continue
        recs = [r for r in store.district_records(did) if r.get("sensitivity", "public") == "public"]
        for iid, ind in compute_indicators(recs).items():
            vals.setdefault(iid, []).append(ind["value"])
    return vals


def _age_days(as_of, ref):
    return (ref - date.fromisoformat(as_of)).days


def find_stale(records, sources, ref):
    out = []
    for r in records:
        src = sources.get(r["source_id"])
        age = _age_days(r["as_of"], ref)
        if src and age > src["max_age_days"]:
            out.append({"evidence_id": r["evidence_id"], "source_id": r["source_id"], "age_days": age,
                        "max_age_days": src["max_age_days"], "role": r["role"]})
    out.sort(key=lambda x: x["evidence_id"])
    for i, s in enumerate(out, 1):
        s["stale_id"] = f"STALE_{i:02d}"
    return out


def find_contradictions(records, indicators, config):
    out, by_metric = [], {}
    for r in records:
        by_metric.setdefault(r["metric"], []).append(r)
    for metric in sorted(by_metric):
        grp = by_metric[metric]
        prim = _fp(grp, metric)
        if not prim:
            continue
        for sec in sorted([x for x in grp if x is not prim], key=lambda x: x["evidence_id"]):
            hi = max(abs(prim["value"]), abs(sec["value"]))
            if hi <= 0:
                continue
            rel = abs(prim["value"] - sec["value"]) / hi
            if rel < config.contradiction_rel_threshold:
                continue
            reasons = []
            if prim["definition"].strip().lower() != sec["definition"].strip().lower():
                reasons.append("definition_differs")
            if prim["period"] != sec["period"]:
                reasons.append("period_differs")
            if prim["denominator_basis"] != sec["denominator_basis"]:
                reasons.append("denominator_basis_differs")
            out.append({"type": "MEASUREMENT_DIFFERENCE" if reasons else "GENUINE", "metric": metric,
                        "evidence_ids": [prim["evidence_id"], sec["evidence_id"]],
                        "values": [prim["value"], sec["value"]], "unit": prim["unit"],
                        "source_ids": [prim["source_id"], sec["source_id"]],
                        "delta_pct": round(rel * 100, 2), "reasons": reasons})
    plr, gvr = indicators.get("IND_PLR"), indicators.get("IND_GVR")
    if plr and gvr and plr["value"] >= config.tension_placement_pct and gvr["value"] >= config.tension_ratio:
        out.append({"type": "CROSS_INDICATOR_TENSION", "metric": "placement_vs_vacancy_absorption",
                    "evidence_ids": sorted(set(plr["inputs"] + gvr["inputs"])), "values": [plr["value"], gvr["value"]],
                    "unit": "mixed", "source_ids": [], "delta_pct": None,
                    "indicator_ids": ["IND_PLR", "IND_GVR"], "reasons": ["high_placement_with_low_vacancy_absorption"]})
    for i, c in enumerate(out, 1):
        c["contradiction_id"] = f"CON_{i:02d}"
    return out


def find_anomalies(indicators, peer_vals, config):
    out = []
    for iid in ANOMALY_INDICATORS:
        ind, peers = indicators.get(iid), peer_vals.get(iid, [])
        if not ind or len(peers) < config.min_peers_for_stats:
            continue
        mu, sd = mean(peers), pstdev(peers)
        if sd == 0:
            continue
        z = (ind["value"] - mu) / sd
        if abs(z) >= config.z_threshold:
            out.append({"indicator_id": iid, "metric": ind["name"], "value": ind["value"], "unit": ind["unit"],
                        "peer_mean": round(mu, 2), "peer_sd": round(sd, 2), "z": round(z, 2),
                        "direction": "above" if z > 0 else "below", "inputs": ind["inputs"]})
    for i, a in enumerate(out, 1):
        a["anomaly_id"] = f"AN_{i:02d}"
    return out


def find_denominator_changes(records):
    out = []
    for metric in DENOMINATOR_METRICS:
        grp = sorted([r for r in records if r["metric"] == metric], key=lambda r: r["evidence_id"])
        bases = {r["denominator_basis"] for r in grp}
        if len(grp) >= 2 and len(bases) > 1:
            prim = _fp(grp, metric) or grp[0]
            for sec in [r for r in grp if r is not prim and r["denominator_basis"] != prim["denominator_basis"]]:
                hi = max(prim["value"], sec["value"]) or 1
                out.append({"metric": metric, "evidence_ids": [prim["evidence_id"], sec["evidence_id"]],
                            "bases": [prim["denominator_basis"], sec["denominator_basis"]],
                            "values": [prim["value"], sec["value"]], "unit": prim["unit"],
                            "delta_pct": round(abs(prim["value"] - sec["value"]) / hi * 100, 2)})
    for i, d in enumerate(out, 1):
        d["denominator_id"] = f"DEN_{i:02d}"
    return out


def rank_desc(target, peers):
    return 1 + sum(1 for p in peers if p > target)


def _confidence(stale, contradictions, missing_optional, sens, data_classes):
    points, reasons = 100, []
    for s in stale:
        points -= 25
        reasons.append("SOURCE_PAST_FRESHNESS_LIMIT")
    for c in contradictions:
        d = {"GENUINE": 20, "CROSS_INDICATOR_TENSION": 10, "MEASUREMENT_DIFFERENCE": 5}[c["type"]]
        points -= d
        reasons.append(c["type"])
    if missing_optional:
        points -= 15
        reasons.append("MISSING_OPTIONAL_METRIC")
    if sens.get("ranking") and sens["ranking"]["unstable"]:
        points -= 15
        reasons.append("RANKING_UNSTABLE")
    if any(v["flips"] for v in sens.get("vacancy_scenarios", [])):
        points -= 15
        reasons.append("FLAG_NOT_ROBUST_TO_DENOMINATOR")
    level = "HIGH" if points >= 75 else "MEDIUM" if points >= 50 else "LOW"
    capped = False
    if level == "HIGH" and "SYNTHETIC" in data_classes:
        level, capped = "MEDIUM", True
    return {"level": level, "points": max(points, 0), "reasons": reasons, "synthetic_capped": capped}


@dataclass
class Bundle:
    district_id: str
    district_name: str
    reference_date: date
    records: list
    indicators: dict
    peer: dict
    flag: dict
    contradictions: list
    anomalies: list
    stale: list
    missing_required: list
    missing_optional: list
    denominator_changes: list
    sensitivity: dict
    confidence: dict
    data_classes: list
    config: object = None
    triggers: list = field(default_factory=list)

    def counts(self):
        return {"CNT_RECORDS": len(self.records), "CNT_CONTRADICTIONS": len(self.contradictions),
                "CNT_STALE": len(self.stale), "CNT_ANOMALIES": len(self.anomalies),
                "CNT_PEERS": self.peer.get("n", 0), "CNT_MISSING": len(self.missing_required) + len(self.missing_optional)}

    def ref_values(self):
        """Every reference an AI claim may cite -> (authoritative value, unit)."""
        refs = {}
        for r in self.records:
            refs[r["evidence_id"]] = (r["value"], r["unit"])
        for iid, ind in self.indicators.items():
            refs[iid] = (ind["value"], ind["unit"])
        for c in self.contradictions:
            if c["delta_pct"] is not None:
                refs[c["contradiction_id"]] = (c["delta_pct"], "percent")
            else:
                refs[c["contradiction_id"]] = (None, None)
        for a in self.anomalies:
            refs[a["anomaly_id"]] = (a["z"], "z_score")
            refs[a["anomaly_id"] + "_MEAN"] = (a["peer_mean"], a["unit"])
            refs[a["anomaly_id"] + "_SD"] = (a["peer_sd"], a["unit"])
        for d in self.denominator_changes:
            refs[d["denominator_id"]] = (d["delta_pct"], "percent")
        for s in self.stale:
            refs[s["stale_id"]] = (s["age_days"], "days")
            refs[s["stale_id"] + "_MAX"] = (s["max_age_days"], "days")
        for i, v in enumerate(self.sensitivity.get("vacancy_scenarios", []), 1):
            refs[v["sens_id"]] = (v["alt_ratio"], "ratio")
        rk = self.sensitivity.get("ranking")
        if rk:
            refs["SENS_RANK_GPC"] = (rk["rank_gpc"], "rank")
            refs["SENS_RANK_GPL"] = (rk["rank_gpl"], "rank")
            refs["SENS_RANK_N"] = (rk["n"], "count")
        for k, v in self.counts().items():
            refs[k] = (v, "count")
        if hasattr(self, "decision"):
            refs["DEC_STATUS"] = (None, None)
        refs["CFG_Z_THRESHOLD"] = (self.config.z_threshold, "z_score")
        refs["CFG_MIN_PEERS"] = (self.config.min_peers_for_stats, "count")
        return refs

    def allowed_numbers(self):
        return [v for v, _ in self.ref_values().values() if isinstance(v, (int, float))]


def build_bundle(store, records, district_id, district_name, config, reference_date):
    indicators = compute_indicators(records)
    peer_vals = peer_indicator_values(store, district_id)
    n_peers = len(peer_vals.get("IND_GVR", []))
    peer = {"n": n_peers}
    flag = {"status": "NOT_ASSESSABLE", "rule": f"graduate_to_vacancy_ratio >= {config.flag_multiplier} x peer median"}
    if n_peers >= config.min_peers_for_stats and "IND_GVR" in indicators:
        med = round(median(peer_vals["IND_GVR"]), 2)
        thr = round(config.flag_multiplier * med, 2)
        peer.update({"median_gvr": med, "threshold_gvr": thr})
        indicators["IND_PEER_MEDIAN_GVR"] = {"indicator_id": "IND_PEER_MEDIAN_GVR", "name": "peer_median_graduate_to_vacancy_ratio",
                                             "value": med, "unit": "ratio", "inputs": [], "formula": "median over peer districts"}
        indicators["IND_FLAG_THRESHOLD_GVR"] = {"indicator_id": "IND_FLAG_THRESHOLD_GVR", "name": "flag_threshold",
                                                "value": thr, "unit": "ratio", "inputs": [],
                                                "formula": f"{config.flag_multiplier} x peer median"}
        flag.update({"status": "FLAGGED" if indicators["IND_GVR"]["value"] >= thr else "NOT_FLAGGED",
                     "ratio": indicators["IND_GVR"]["value"], "peer_median": med, "threshold": thr})
    stale = find_stale(records, store.sources, reference_date)
    contradictions = find_contradictions(records, indicators, config)
    anomalies = find_anomalies(indicators, peer_vals, config) if n_peers >= config.min_peers_for_stats else []
    prim_metrics = {r["metric"] for r in records if r["role"] == "primary"}
    missing_req = [m for m in REQUIRED_METRICS if m not in prim_metrics]
    missing_opt = [m for m in OPTIONAL_METRICS if m not in prim_metrics]
    dchanges = find_denominator_changes(records)

    sens = {"vacancy_scenarios": [], "ranking": None}
    g = _fp(records, "graduates_total")
    if flag["status"] in ("FLAGGED", "NOT_FLAGGED") and g:
        k = 0
        for r in sorted(records, key=lambda x: x["evidence_id"]):
            if r["metric"] == "vacancies_total" and r["role"] != "primary" and r["value"] > 0:
                k += 1
                alt = round(g["value"] / r["value"], 2)
                alt_flag = "FLAGGED" if alt >= flag["threshold"] else "NOT_FLAGGED"
                sens["vacancy_scenarios"].append({"sens_id": f"SENS_VAC_{k:02d}", "evidence_id": r["evidence_id"],
                                                  "alt_ratio": alt, "alt_flag": alt_flag, "flips": alt_flag != flag["status"]})
    if "IND_GPC" in indicators and "IND_GPL" in indicators and len(peer_vals.get("IND_GPC", [])) >= config.min_peers_for_stats \
            and len(peer_vals.get("IND_GPL", [])) >= config.min_peers_for_stats:
        ra = rank_desc(indicators["IND_GPC"]["value"], peer_vals["IND_GPC"])
        rb = rank_desc(indicators["IND_GPL"]["value"], peer_vals["IND_GPL"])
        sens["ranking"] = {"rank_gpc": ra, "rank_gpl": rb, "n": min(len(peer_vals["IND_GPC"]), len(peer_vals["IND_GPL"])) + 1,
                           "delta": rb - ra, "unstable": abs(rb - ra) >= config.rank_instability}
    classes = sorted({r["data_class"] for r in records})
    conf = _confidence(stale, contradictions, missing_opt, sens, classes)
    b = Bundle(district_id, district_name, reference_date, records, indicators, peer, flag, contradictions,
               anomalies, stale, missing_req, missing_opt, dchanges, sens, conf, classes, config)
    b.triggers = build_triggers(b)
    return b


def build_triggers(b):
    t = []

    def add(kind, ev, ind=()):
        t.append({"trigger_id": f"TR_{len(t) + 1:02d}", "kind": kind, "evidence_ids": list(ev), "indicator_ids": list(ind)})
    if b.flag["status"] == "FLAGGED":
        gv = b.indicators["IND_GVR"]
        add("FLAG", gv["inputs"], ["IND_GVR"])
    for c in b.contradictions:
        add("CONTRADICTION_" + c["type"], c["evidence_ids"], c.get("indicator_ids", []))
    for s in b.stale:
        add("STALE", [s["evidence_id"]])
    for d in b.denominator_changes:
        add("DENOMINATOR", d["evidence_ids"])
    return t
