"""Response cache: safe, authorised, version-aware. Keys bind to the caller's access scope."""
import copy
import hashlib
import json
import time


def scope_fingerprint(identity):
    return hashlib.sha256(json.dumps({"role": identity.role, "districts": sorted(identity.districts),
                                      "perms": sorted(identity.permissions())}).encode()).hexdigest()[:16]


def make_key(identity, district_id, intent, evidence_fp, prompt_versions, model, reference_date):
    raw = json.dumps({"scope": scope_fingerprint(identity), "district": district_id, "intent": intent,
                      "evidence": evidence_fp, "prompts": prompt_versions, "model": model, "ref": str(reference_date)},
                     sort_keys=True)
    return hashlib.sha256(raw.encode()).hexdigest()


class ResponseCache:
    def __init__(self, ttl_s=900, max_entries=256, clock=time.monotonic):
        self.ttl, self.max, self.clock, self._d = ttl_s, max_entries, clock, {}

    def get(self, key):
        item = self._d.get(key)
        if not item:
            return None
        if self.clock() - item[0] > self.ttl:
            del self._d[key]
            return None
        return copy.deepcopy(item[1])

    def put(self, key, response):
        """Caches only fully validated, non-abstaining responses."""
        if response.get("status") != "OK" or not response.get("validation", {}).get("passed"):
            return False
        if len(self._d) >= self.max:
            self._d.pop(next(iter(self._d)))
        self._d[key] = (self.clock(), copy.deepcopy(response))
        return True
