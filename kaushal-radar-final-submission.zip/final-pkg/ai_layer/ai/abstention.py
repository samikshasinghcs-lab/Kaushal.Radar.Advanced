"""Abstention layer: explicit insufficient-evidence response instead of guessing."""
from dataclasses import dataclass, field


@dataclass
class AbstentionDecision:
    abstain: bool
    reason_codes: list = field(default_factory=list)
    missing_metrics: list = field(default_factory=list)


def decide(bundle, config):
    reasons = []
    if not bundle.records:
        reasons.append("NO_EVIDENCE")
    elif len(bundle.records) < config.min_evidence_records:
        reasons.append("BELOW_MIN_RECORDS")
    if bundle.missing_required and bundle.records:
        reasons.append("MISSING_REQUIRED_METRIC")
    if "IND_GVR" not in bundle.indicators and bundle.records and not bundle.missing_required:
        reasons.append("INDICATOR_NOT_COMPUTABLE")
    primaries = [r for r in bundle.records if r["role"] == "primary"]
    if primaries and len(bundle.stale) >= len(primaries):
        reasons.append("ALL_SOURCES_STALE")
    if bundle.flag["status"] == "NOT_ASSESSABLE" and bundle.records and not reasons:
        reasons.append("INSUFFICIENT_PEERS")
    return AbstentionDecision(bool(reasons), reasons, list(bundle.missing_required))


def response_for(decision):
    return {"abstain": True, "reason_codes": decision.reason_codes, "missing_metrics": decision.missing_metrics,
            "message": "Insufficient evidence to produce a diagnostic brief. No AI interpretation was generated."}
