"""Hallucination guard: unsupported conclusions, invented entities, inflated confidence."""
import re
from . import districts

CAUSAL = re.compile(r"\b(because|due to|caused by|causes?d?|leads? to|led to|as a result|driven by|result of|responsible for|attributable to)\b", re.I)
HEDGE = re.compile(r"\b(may|might|could|suggests?|consistent with|possibly|appears?)\b", re.I)
CONTRA = re.compile(r"contradict|conflict|inconsisten|disagree", re.I)
NO_CONTRA = re.compile(r"\b(no|none|not)\b[^.]{0,40}(contradict|conflict|inconsisten|disagree)", re.I)
ANOM = re.compile(r"anomal", re.I)
NO_ANOM = re.compile(r"\b(no|none|not)\b[^.]{0,60}anomal", re.I)
STALE = re.compile(r"\b(stale|outdated|out of date|expired)\b", re.I)
FLAGGED_YES = re.compile(r"\b(is|are|was|remains)\s+(currently\s+)?flagged\b", re.I)
FLAGGED_NO = re.compile(r"\b(is|are|was)\s+not\s+(currently\s+)?flagged\b", re.I)
STATUS_TOKENS = ["INSUFFICIENT_EVIDENCE", "DATA_QUALITY_HOLD", "FLAGGED_FOR_REVIEW", "NOT_FLAGGED"]
RANK = {"LOW": 0, "MEDIUM": 1, "HIGH": 2}


def check(output, bundle, decision=None):
    v = []
    me = bundle.district_name
    others = [n for n in districts.all_names() if n != me]
    texts = [("summary", "summary", output.get("summary", ""))] + [(c["claim_id"], c["kind"], c["text"]) for c in output["claims"]]
    for where, kind, text in texts:
        for n in others:
            if re.search(r"(?<![A-Za-z])" + re.escape(n) + r"(?![A-Za-z])", text):
                v.append({"code": "ENTITY_NOT_IN_SCOPE", "claim_id": where, "detail": "text names a district outside the query scope"})
                break
        if kind in ("fact", "interpretation"):
            if CAUSAL.search(text) and not (kind == "interpretation" and HEDGE.search(text)):
                v.append({"code": "UNSUPPORTED_CAUSAL_CLAIM", "claim_id": where, "detail": "causal language without hedged interpretation"})
            if CONTRA.search(text) and not bundle.contradictions and not NO_CONTRA.search(text):
                v.append({"code": "UNSUPPORTED_CONTRADICTION", "claim_id": where, "detail": "contradiction asserted but none detected deterministically"})
            if ANOM.search(text) and not bundle.anomalies and not NO_ANOM.search(text):
                v.append({"code": "UNSUPPORTED_ANOMALY", "claim_id": where, "detail": "anomaly asserted but none detected deterministically"})
            if STALE.search(text) and not bundle.stale:
                v.append({"code": "UNSUPPORTED_STALENESS", "claim_id": where, "detail": "staleness asserted but no stale evidence found"})
        if (bundle.contradictions and NO_CONTRA.search(text)) and kind != "suggestion":
            v.append({"code": "FALSE_NEGATION_CONTRADICTION", "claim_id": where, "detail": "denies contradictions that were detected"})
        if bundle.anomalies and NO_ANOM.search(text) and kind != "suggestion":
            v.append({"code": "FALSE_NEGATION_ANOMALY", "claim_id": where, "detail": "denies anomalies that were detected"})
        st = bundle.flag["status"]
        if (FLAGGED_YES.search(text) and st != "FLAGGED") or (FLAGGED_NO.search(text) and st == "FLAGGED"):
            v.append({"code": "FLAG_STATUS_MISMATCH", "claim_id": where, "detail": "text contradicts the deterministic flag status"})
        if decision:
            for tok in STATUS_TOKENS:
                if tok in text and tok != decision["status"]:
                    # allow NOT_FLAGGED inside text only if that is the status
                    v.append({"code": "DECISION_STATUS_MISMATCH", "claim_id": where, "detail": "text names a status other than the decision engine's"})
                    break
    if RANK[output["confidence"]] > RANK[bundle.confidence["level"]]:
        v.append({"code": "CONFIDENCE_INFLATED", "claim_id": "output", "detail": "AI confidence exceeds deterministic confidence"})
    return v
