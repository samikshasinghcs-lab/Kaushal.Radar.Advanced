"""Bounded retries with exponential backoff (no jitter, so tests are deterministic)."""
import time
from .exceptions import (ProviderError, ProviderFatal, ProviderRateLimit, ProviderTimeout,
                         ProviderUnavailable, MalformedOutput)


class RetryManager:
    def __init__(self, max_retries=2, base_delay=0.5, max_delay=8.0, sleep=time.sleep):
        self.max_retries = max(0, int(max_retries))
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.sleep = sleep
        self.retry_on = (ProviderTimeout, ProviderRateLimit, ProviderError, MalformedOutput)

    def call(self, fn):
        attempts, last = 0, None
        for n in range(self.max_retries + 1):
            attempts += 1
            try:
                return fn(), attempts
            except ProviderFatal as e:
                raise ProviderUnavailable("non-retryable provider failure",
                                          details={"attempts": attempts, "last_error": e.code}) from e
            except self.retry_on as e:
                last = e
                if n < self.max_retries:
                    self.sleep(min(self.base_delay * (2 ** n), self.max_delay))
        raise ProviderUnavailable("provider failed after bounded retries",
                                  details={"attempts": attempts,
                                           "last_error": getattr(last, "code", type(last).__name__)}) from last
