"""Builds docs/component_registry.json and docs/COMPONENTS.md by EXECUTING the tests. Run from repo root:
    python -m tools.build_registry
Statuses are computed, never hand-written."""
import importlib
import json
import os
import re
import subprocess
import sys

from tools.components_meta import COMPONENTS

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ORDER = ["NOT_STARTED", "IMPLEMENTED", "UNIT_TESTED", "INTEGRATION_VERIFIED", "SECURITY_VERIFIED", "COMPLETE"]
_cache = {}


def run_mod(mod):
    if mod not in _cache:
        p = subprocess.run([sys.executable, "-m", "unittest", mod], cwd=ROOT, capture_output=True, text=True)
        m = re.search(r"Ran (\d+) tests?", p.stderr)
        _cache[mod] = {"passed": p.returncode == 0, "tests": int(m.group(1)) if m else 0}
    return _cache[mod]


def run_cmd(args):
    return subprocess.run([sys.executable, "-m"] + args, cwd=ROOT, capture_output=True, text=True).returncode == 0


def importable(files):
    for f in files:
        if f.endswith(".py"):
            try:
                importlib.import_module(f[:-3].replace("/", "."))
            except Exception:
                return False
        elif not os.path.exists(os.path.join(ROOT, f)):
            return False
    return True


def main():
    sys.path.insert(0, ROOT)
    demo_ok = {"pipeline": run_cmd(["demo.run_demo"]), "evaluation": run_cmd(["evaluation.runner"])}
    docs_text = write_docs()
    out, total_tests = [], {}
    for c in COMPONENTS:
        impl = importable(c["files"])
        unit = impl and all(run_mod(m)["passed"] for m in c["unit"])
        integ = unit and all(run_mod(m)["passed"] for m in c["integration"])
        sec = integ and all(run_mod(m)["passed"] for m in c["security"])
        fail = all(run_mod(m)["passed"] for m in c["failure"])
        documented = f"### {c['n']}. {c['key']}" in docs_text
        status = ("COMPLETE" if (sec and fail and demo_ok[c["demo"]] and documented) else "SECURITY_VERIFIED" if sec else
                  "INTEGRATION_VERIFIED" if integ else "UNIT_TESTED" if unit else "IMPLEMENTED" if impl else "NOT_STARTED")
        if c["cap"] and ORDER.index(status) > ORDER.index(c["cap"]):
            status = c["cap"]
        out.append({"component": c["key"], "number": c["n"], "group": c["group"], "files": c["files"], "implemented": impl,
                    "unit_tests_passed": bool(unit), "integration_verified": bool(integ), "security_verified": bool(sec),
                    "failure_tests_passed": bool(fail), "demo_available": demo_ok[c["demo"]], "documented": documented,
                    "status": status, "capped_reason": c["limitations"] if c["cap"] else None})
    for m, r in _cache.items():
        total_tests[m] = r
    reg = {"generated_by": "tools/build_registry.py (executes the listed test modules)",
           "test_modules": total_tests, "total_tests_executed": sum(r["tests"] for r in total_tests.values()),
           "status_counts": {s: sum(1 for x in out if x["status"] == s) for s in ORDER}, "components": out}
    with open(os.path.join(ROOT, "docs", "component_registry.json"), "w") as f:
        json.dump(reg, f, indent=1)
    print("tests executed:", reg["total_tests_executed"], "| status counts:", {k: v for k, v in reg["status_counts"].items() if v})
    bad = [x["component"] for x in out if x["status"] not in ("COMPLETE", "SECURITY_VERIFIED")]
    print("below SECURITY_VERIFIED:", bad or "none")


def write_docs():
    L = ["# Components (auto-generated from tools/components_meta.py)", "",
         "Status per component is in `component_registry.json` and is computed by executing tests.", ""]
    grp = None
    for c in COMPONENTS:
        if c["group"] != grp:
            grp = c["group"]
            L += [f"## {grp}", ""]
        L += [f"### {c['n']}. {c['key']}", f"- **Purpose:** {c['purpose']}", f"- **Files:** {', '.join(c['files'])}",
              f"- **Dependencies:** {c['depends']}", f"- **Limitations:** {c['limitations']}",
              f"- **Tests:** unit {', '.join(c['unit'])}; integration {', '.join(c['integration'])}; security {', '.join(c['security'])}", ""]
    text = "\n".join(L)
    with open(os.path.join(ROOT, "docs", "COMPONENTS.md"), "w") as f:
        f.write(text)
    return text


if __name__ == "__main__":
    main()
