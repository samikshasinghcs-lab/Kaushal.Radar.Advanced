"""Lists files in this bundle that already exist in your repo, so you can diff instead of overwrite.
Usage:  python tools/check_collisions.py /path/to/your/Kaushal-Radar"""
import os
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SKIP = {"__pycache__", ".git"}


def main(target):
    clash, new = [], []
    for dp, dn, fn in os.walk(HERE):
        dn[:] = [d for d in dn if d not in SKIP]
        for f in fn:
            if f.endswith(".pyc"):
                continue
            rel = os.path.relpath(os.path.join(dp, f), HERE)
            (clash if os.path.exists(os.path.join(target, rel)) else new).append(rel)
    print(f"{len(new)} files are new; {len(clash)} ALREADY EXIST in your repo (diff these before overwriting):")
    for c in sorted(clash):
        print("  CLASH", c)
    return 1 if clash else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]) if len(sys.argv) > 1 else print(__doc__) or 2)
