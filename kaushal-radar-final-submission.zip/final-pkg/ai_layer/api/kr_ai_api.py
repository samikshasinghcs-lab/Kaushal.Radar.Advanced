"""Minimal stdlib HTTP API for the AI layer.

  GET  /health
  POST /v1/brief    Authorization: Bearer <token>   body: {"question": "...", "district_id": "KA-023"?}
  POST /v1/review   Authorization: Bearer <token>   body: {"brief_id": "BR_...", "decision": "...", "note": "..."}
  GET  /v1/audit/verify   (AUDITOR only)
Identity and role come ONLY from the bearer token via the server-side directory.
"""
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from ai.exceptions import AccessDenied, AuthenticationError
from security.access_control import authorize

HTTP = {"OK": 200, "ABSTAINED": 200, "REVIEW_RECORDED": 200, "REJECTED_INPUT": 400, "REJECTED_INJECTION": 400,
        "REJECTED_PRIVACY": 400, "AUTH_FAILED": 401, "ACCESS_DENIED": 403, "FAILED_PROVIDER": 503}
MAX_BODY = 20000


def _bearer(headers):
    h = {k.lower(): v for k, v in headers.items()}.get("authorization", "")
    return h[7:].strip() if h.lower().startswith("bearer ") else ""


class AIApi:
    def __init__(self, pipeline):
        self.p = pipeline

    def handle(self, method, path, headers, body=b""):
        if method == "GET" and path == "/health":
            return 200, {"status": "ok"}
        token = _bearer(headers)
        if method == "GET" and path == "/v1/audit/verify":
            try:
                authorize(self.p.directory.authenticate(token), "view_audit")
            except AuthenticationError:
                return 401, {"status": "AUTH_FAILED"}
            except AccessDenied:
                return 403, {"status": "ACCESS_DENIED"}
            ok, idx = self.p.ledger.verify()
            return 200, {"chain_valid": ok, "first_bad_index": idx, "entries": len(self.p.ledger.entries())}
        if method == "POST" and path in ("/v1/brief", "/v1/review"):
            if len(body) > MAX_BODY:
                return 413, {"status": "REJECTED_INPUT", "error": {"code": "BODY_TOO_LARGE"}}
            try:
                payload = json.loads(body.decode("utf-8")) if body else {}
            except (ValueError, UnicodeDecodeError):
                return 400, {"status": "REJECTED_INPUT", "error": {"code": "BAD_JSON"}}
            resp = self.p.handle_request(token, payload) if path == "/v1/brief" else self.p.submit_review(token, payload)
            return HTTP.get(resp["status"], 500), resp
        return 404, {"status": "NOT_FOUND"}


def make_server(api, host="127.0.0.1", port=8080):
    class H(BaseHTTPRequestHandler):
        def _go(self, method):
            n = int(self.headers.get("Content-Length") or 0)
            code, obj = api.handle(method, self.path.split("?")[0], dict(self.headers), self.rfile.read(min(n, MAX_BODY + 1)))
            data = json.dumps(obj, default=str).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self):
            self._go("GET")

        def do_POST(self):
            self._go("POST")

        def log_message(self, *a):  # no request logging: avoids leaking tokens/questions
            pass
    return ThreadingHTTPServer((host, port), H)
