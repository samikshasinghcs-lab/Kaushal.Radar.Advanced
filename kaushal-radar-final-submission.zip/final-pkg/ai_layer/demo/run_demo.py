"""Reproducible officer journey (SYNTHETIC data): Why is Raichur flagged?
Run:  python -m demo.run_demo
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ai.config import Config
from ai.evidence_store import REFERENCE_DATE, build_demo_store
from ai.master_pipeline import KaushalAIPipeline
from ai.provider import MockProvider, ProviderManager
from api.kr_ai_api import AIApi
from dashboard.render import render_brief
from security.access_control import UserDirectory

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main():
    cfg = Config()
    d = UserDirectory()
    state_tok = d.register("state_officer_demo", "STATE_OFFICER")
    dist_tok = d.register("raichur_officer_demo", "DISTRICT_OFFICER", ["KA-023"])
    aud_tok = d.register("auditor_demo", "AUDITOR")
    pipe = KaushalAIPipeline(build_demo_store(), d, ProviderManager(MockProvider(), cfg), config=cfg, reference_date=REFERENCE_DATE)
    api = AIApi(pipe)
    out = {}
    hdr = lambda t: {"Authorization": f"Bearer {t}"}
    q = json.dumps({"question": "Why is Raichur flagged?"}).encode()
    code, resp = api.handle("POST", "/v1/brief", hdr(state_tok), q)
    print(f"[1] State officer -> HTTP {code}, decision={resp['decision']['status']}, confidence={resp['brief']['confidence']}, "
          f"automated checks={resp['brief']['verification_status']}")
    print("    contradictions:", [(c["type"], c["metric"]) for c in resp["analysis"]["contradictions"]])
    code2, resp2 = api.handle("POST", "/v1/brief", hdr(dist_tok), q)
    print(f"[2] District officer -> HTTP {code2}, restricted evidence withheld count={resp2['provenance']['restricted_withheld_count']}, "
          f"contradictions={[c['type'] for c in resp2['analysis']['contradictions']]}")
    c3, _ = api.handle("POST", "/v1/brief", hdr(dist_tok), json.dumps({"question": "Why is Mysuru flagged?"}).encode())
    print(f"[3] District officer asking about another district -> HTTP {c3}")
    c4, r4 = api.handle("POST", "/v1/brief", hdr(dist_tok), json.dumps({"question": "Why is Raichur flagged?", "role": "ADMIN"}).encode())
    print(f"[4] Role smuggling attempt -> HTTP {c4}, code={r4['error']['code']}")
    c5, r5 = api.handle("POST", "/v1/review", hdr(state_tok), json.dumps({"brief_id": resp["brief"]["brief_id"], "decision": "ESCALATED_FOR_HUMAN_DECISION",
                                                                          "note": "Reconcile placement audit"}).encode())
    print(f"[5] Human review -> HTTP {c5}, {r5['review']['status']} by {r5['review']['reviewer']}")
    c6, r6 = api.handle("POST", "/v1/review", hdr(state_tok), json.dumps({"brief_id": resp["brief"]["brief_id"], "decision": "APPROVE_FUNDING"}).encode())
    print(f"[6] Attempt to record 'APPROVE_FUNDING' -> HTTP {c6}, code={r6['error']['code']}")
    c7, r7 = api.handle("GET", "/v1/audit/verify", hdr(aud_tok))
    print(f"[7] Audit chain valid={r7['chain_valid']} over {r7['entries']} entries")
    os.makedirs(os.path.join(ROOT, "dashboard"), exist_ok=True)
    with open(os.path.join(ROOT, "dashboard", "demo_brief_raichur.html"), "w", encoding="utf-8") as f:
        f.write(render_brief(resp))
    with open(os.path.join(ROOT, "docs", "demo_response_raichur.json"), "w") as f:
        json.dump(resp, f, indent=1, default=str)
    print("Wrote dashboard/demo_brief_raichur.html and docs/demo_response_raichur.json")
    ok = code == 200 and resp["validation"]["passed"] and c3 == 403 and c4 == 400 and c5 == 200 and c6 == 400 and r7["chain_valid"]
    print("DEMO CHECKS:", "PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
