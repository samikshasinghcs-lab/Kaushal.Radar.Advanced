import os
import tempfile
import unittest

from ai import abstention, privacy
from ai.audit import AuditLedger
from ai.cache import ResponseCache, make_key, scope_fingerprint
from ai.decision_gate import DecisionGate
from ai.exceptions import PrivacyViolation
from security.access_control import Identity
from tests.helpers import raichur_bundle


class PrivacyTests(unittest.TestCase):
    def test_detects_types_without_echoing_values(self):
        body = "23456789012"
        aad = body + privacy.verhoeff_generate(body)
        self.assertTrue(privacy.verhoeff_valid(aad))
        self.assertEqual(privacy.find_pii(f"id {aad}"), ["AADHAAR"])
        self.assertEqual(privacy.find_pii("a@b.com ABCDE1234F 9876543210"), ["EMAIL", "PAN", "PHONE"])
        with self.assertRaises(PrivacyViolation) as cm:
            privacy.enforce({"q": "mail me a@b.com"})
        self.assertNotIn("a@b.com", str(cm.exception.details))

    def test_no_false_positive_on_years_or_ids(self):
        self.assertEqual(privacy.find_pii("2024 2025 2026 and EV_023_GRADUATES_TOTAL 2025-26 18,400"), [])

    def test_blocked_field_names_and_redact(self):
        self.assertTrue(privacy.scan_obj({"applicant_name": "x"}))
        self.assertNotIn("a@b.com", privacy.redact("write a@b.com"))


class AbstentionTests(unittest.TestCase):
    def test_no_abstention_on_full_evidence(self):
        _, _, b = raichur_bundle()
        self.assertFalse(abstention.decide(b, b.config).abstain)

    def test_abstains_on_missing_and_few_records(self):
        _, _, b = raichur_bundle()
        b.records = [r for r in b.records if r["metric"] != "vacancies_total"]
        b.missing_required = ["vacancies_total"]
        d = abstention.decide(b, b.config)
        self.assertTrue(d.abstain)
        self.assertIn("MISSING_REQUIRED_METRIC", d.reason_codes)
        b.records = b.records[:2]
        self.assertIn("BELOW_MIN_RECORDS", abstention.decide(b, b.config).reason_codes)
        b.records = []
        self.assertIn("NO_EVIDENCE", abstention.decide(b, b.config).reason_codes)


class AuditTests(unittest.TestCase):
    def test_chain_detects_tampering_and_redacts_secrets(self):
        with tempfile.TemporaryDirectory() as td:
            path = os.path.join(td, "audit.jsonl")
            L = AuditLedger(path)
            L.append("A", "u1", "r1", {"api_key": "sk-secret", "note": "mail a@b.com", "n": 1})
            L.append("B", "u1", "r2", {"x": 2})
            self.assertEqual(L.verify(), (True, None))
            with open(path) as fh:
                blob = fh.read()
            self.assertNotIn("sk-secret", blob)
            self.assertNotIn("a@b.com", blob)
            L._entries[0]["payload"]["n"] = 99
            self.assertEqual(L.verify(), (False, 0))


class CacheTests(unittest.TestCase):
    def ident(self, role, d=()):
        return Identity("u", role, frozenset(d))

    def test_scope_bound_keys_prevent_cross_role_leak(self):
        a, b = self.ident("STATE_OFFICER"), self.ident("DISTRICT_OFFICER", ["KA-023"])
        args = ("KA-023", "FULL_BRIEF", "fp", {"t": "1.0.0"}, "m", "2026-10-31")
        self.assertNotEqual(make_key(a, *args), make_key(b, *args))
        self.assertEqual(make_key(b, *args), make_key(self.ident("DISTRICT_OFFICER", ["KA-023"]), *args))
        self.assertNotEqual(scope_fingerprint(b), scope_fingerprint(self.ident("DISTRICT_OFFICER", ["KA-001"])))

    def test_only_validated_ok_responses_cached_ttl_and_version_aware(self):
        t = [0]
        c = ResponseCache(ttl_s=10, clock=lambda: t[0])
        self.assertFalse(c.put("k", {"status": "OK", "validation": {"passed": False}}))
        self.assertFalse(c.put("k", {"status": "ABSTAINED", "validation": {"passed": True}}))
        self.assertTrue(c.put("k", {"status": "OK", "validation": {"passed": True}}))
        self.assertIsNotNone(c.get("k"))
        t[0] = 11
        self.assertIsNone(c.get("k"))
        i = self.ident("STATE_OFFICER")
        self.assertNotEqual(make_key(i, "KA-023", "X", "fp", {"t": "1.0.0"}, "m", "d"), make_key(i, "KA-023", "X", "fp", {"t": "1.1.0"}, "m", "d"))


class GateTests(unittest.TestCase):
    def test_statuses_and_ai_cannot_override(self):
        _, _, b = raichur_bundle()
        g = DecisionGate()
        d = g.evaluate(b, abstention.decide(b, b.config))
        self.assertEqual(d["status"], "FLAGGED_FOR_REVIEW")
        self.assertTrue(d["human_review_required"] and not d["ai_may_override"])
        self.assertFalse(g.finalise(d, False)["presentable_as_verified"])
        b.stale[0]["role"] = "primary"
        self.assertEqual(g.evaluate(b, abstention.decide(b, b.config))["status"], "DATA_QUALITY_HOLD")

    def test_external_engine_hook(self):
        _, _, b = raichur_bundle()
        g = DecisionGate(external_engine=lambda bundle: {"status": "NOT_FLAGGED", "reason_codes": ["X"]})
        self.assertEqual(g.evaluate(b, abstention.decide(b, b.config))["source"], "external_decision_engine")


if __name__ == "__main__":
    unittest.main()
