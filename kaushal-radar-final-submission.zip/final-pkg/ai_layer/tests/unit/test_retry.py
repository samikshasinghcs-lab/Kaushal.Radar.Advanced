import unittest

from ai.exceptions import MalformedOutput, ProviderFatal, ProviderTimeout, ProviderUnavailable
from ai.retry import RetryManager


class RetryTests(unittest.TestCase):
    def test_retries_then_succeeds_with_backoff(self):
        sleeps, calls = [], []

        def fn():
            calls.append(1)
            if len(calls) < 3:
                raise ProviderTimeout("t")
            return "ok"
        r, attempts = RetryManager(3, 0.5, 8, sleep=sleeps.append).call(fn)
        self.assertEqual((r, attempts, sleeps), ("ok", 3, [0.5, 1.0]))

    def test_bounded_and_never_silent(self):
        calls = []

        def fn():
            calls.append(1)
            raise MalformedOutput("m")
        with self.assertRaises(ProviderUnavailable) as cm:
            RetryManager(2, 0, sleep=lambda s: None).call(fn)
        self.assertEqual(len(calls), 3)
        self.assertEqual(cm.exception.details["attempts"], 3)

    def test_fatal_not_retried(self):
        calls = []

        def fn():
            calls.append(1)
            raise ProviderFatal("bad key")
        with self.assertRaises(ProviderUnavailable):
            RetryManager(5, 0, sleep=lambda s: None).call(fn)
        self.assertEqual(len(calls), 1)


if __name__ == "__main__":
    unittest.main()
