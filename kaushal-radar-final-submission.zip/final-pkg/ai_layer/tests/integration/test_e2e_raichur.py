"""Required end-to-end scenario: 'Why is Raichur flagged?' (13-step officer journey)."""
import json
import unittest

from api.kr_ai_api import AIApi
from dashboard.render import render_brief
from evaluation.fault_injection import MutatingProvider
from tests.helpers import make_world


class E2E(unittest.TestCase):
    def test_full_officer_journey(self):
        p, _, t = make_world()
        api = AIApi(p)
        code, r = api.handle("POST", "/v1/brief", {"Authorization": f"Bearer {t['state']}"}, json.dumps({"question": "Why is Raichur flagged?"}).encode())
        self.assertEqual(code, 200)                                                                # 1-2 authN + district access
        self.assertTrue(r["provenance"]["evidence_ids"])                                           # 3 authorised evidence retrieved
        self.assertEqual(next(i for i in r["analysis"]["indicators"] if i["indicator_id"] == "IND_GVR")["value"], 8.76)  # 4 deterministic
        self.assertEqual(r["analysis"]["flag"]["status"], "FLAGGED")                               # 5 supporting evidence
        self.assertEqual({c["type"] for c in r["analysis"]["contradictions"]},
                         {"GENUINE", "MEASUREMENT_DIFFERENCE", "CROSS_INDICATOR_TENSION"})         # 6 contradictory evidence
        self.assertEqual(r["analysis"]["stale"][0]["evidence_id"], "EV_023_VACANCIES_TOTAL_S1")    # 7 freshness
        self.assertTrue(r["analysis"]["denominator_changes"] and r["analysis"]["sensitivity"]["vacancy_scenarios"])  # 8 denominators
        self.assertTrue(r["brief"]["sections"])                                                    # 9 brief
        self.assertTrue(r["validation"]["passed"])                                                 # 10 claims + numbers validated
        self.assertEqual(r["decision"]["status"], "FLAGGED_FOR_REVIEW")                            # 11 decision-engine status
        self.assertEqual(r["human_review"], {"required": True, "status": "PENDING"})               # 12 human review required
        code, rv = api.handle("POST", "/v1/review", {"Authorization": f"Bearer {t['state']}"},
                              json.dumps({"brief_id": r["brief"]["brief_id"], "decision": "ESCALATED_FOR_HUMAN_DECISION", "note": "Reconcile audit"}).encode())
        self.assertEqual(code, 200)
        types = [e["event_type"] for e in p.ledger.entries()]
        self.assertIn("AI_REQUEST", types)                                                         # 13 interaction + review audited
        self.assertIn("HUMAN_REVIEW", types)
        self.assertEqual(p.ledger.verify(), (True, None))
        html = render_brief(r)
        self.assertIn("FLAGGED_FOR_REVIEW", html)
        self.assertIn("SYNTHETIC TEST DATA", html)

    def test_dashboard_escapes_html(self):
        p, _, t = make_world()
        r = p.handle_request(t["state"], {"question": "Why is Raichur flagged?"})
        r["brief"]["sections"][0]["claims"][0]["text"] = "<script>alert(1)</script>"
        self.assertNotIn("<script>alert", render_brief(r))

    def test_test_fails_if_ai_invents_source_changes_number_or_concludes_unverified(self):
        for m in ({"op": "add_evidence_ref", "ref": "EV_999_INVENTED"}, {"op": "scale_number", "factor": 2, "number_index": 2},
                  {"op": "add_claim", "claim": {"claim_id": "Z", "kind": "fact", "text": "Raichur is failing because of poor colleges.", "evidence_ids": ["EV_023_GRADUATES_TOTAL"]}}):
            p, _, t = make_world(MutatingProvider([dict({"task": "evidence_analyst"}, **m)]))
            r = p.handle_request(t["state"], {"question": "Why is Raichur flagged?"})
            self.assertFalse(r["validation"]["passed"])
            self.assertNotEqual(r["brief"]["verification_status"], "AUTOMATED_CHECKS_PASSED")
            self.assertNotIn("Raichur is failing", json.dumps(r["brief"]))


if __name__ == "__main__":
    unittest.main()
