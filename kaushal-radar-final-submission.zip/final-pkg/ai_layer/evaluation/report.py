"""Renders evaluation results to Markdown and a static HTML dashboard (values come from results.json only)."""
import html
import json


def pct(x):
    return "n/a" if x is None else f"{x * 100:.1f}%"


def write_markdown(r, path):
    L = ["# Kaushal Radar AI - Evaluation Report (auto-generated)", "",
         "> **All cases are SYNTHETIC and labelled by construction.** They test the guards and pipeline, not real-world accuracy. "
         "The default provider is a deterministic template mock, not a language model. Language quality was not assessed (needs human review).", "",
         f"- Cases: **{r['dataset']['cases']}**  |  behaved as labelled: **{r['overall']['passed']}**  |  failed: **{r['overall']['failed']}**",
         f"- Behaviour accuracy: **{pct(r['overall']['behaviour_accuracy'])}** (not a claim of real-world accuracy)", "",
         "## By scenario", "", "| Scenario | Cases | Passed | Rate |", "|---|---|---|---|"]
    for k, v in sorted(r["by_scenario"].items()):
        L.append(f"| {k} | {v['cases']} | {v['passed']} | {pct(v['pass_rate'])} |")
    L += ["", "## Metrics", "", "| Metric | Value |", "|---|---|"]

    def prf_row(name, d):
        L.append(f"| {name} precision / recall / F1 | {pct(d['precision'])} / {pct(d['recall'])} / {pct(d['f1'])} (TP {d['tp']}, FP {d['fp']}, FN {d['fn']}) |")
    prf_row("Contradiction detection", r["contradiction_detection"])
    prf_row("Abstention", r["abstention"])
    prf_row("Stale-evidence detection", r["stale_detection"])
    prf_row("Numeric defect detection", r["numeric"]["defect_detection"])
    prf_row("Injected hallucination detection", r["hallucination"]["injected_hallucination_detection"])
    prf_row("Bad-reference detection", r["source_attribution"]["bad_reference_detection"])
    L += [f"| Numeric error rate (accepted outputs, independent check) | {pct(r['numeric']['numeric_error_rate'])} over {r['numeric']['numeric_values_checked_independently']} values |",
          f"| Numeric values not independently verifiable | {r['numeric']['numeric_values_not_independently_verified']} |",
          f"| Unsupported-claim rate (accepted outputs) | {pct(r['hallucination']['unsupported_claim_rate'])} over {r['hallucination']['claims_in_accepted_outputs']} claims |",
          f"| Source attribution accuracy | {pct(r['source_attribution']['source_attribution_accuracy'])} |",
          f"| Factual recall of independently computed facts | {pct(r['factual']['factual_recall'])} |",
          f"| Adversarial/malformed cases handled | {r['robustness']['handled_correctly']}/{r['robustness']['adversarial_cases']} |",
          f"| False-block rate on legitimate requests | {pct(r['robustness']['false_block_rate_on_legitimate'])} |", ""]
    L += ["## Failures (honest list)", ""]
    if r["failures"]:
        L += ["| Case | Scenario | Difficulty | Expected | Observed |", "|---|---|---|---|---|"]
        L += [f"| {f['case_id']} | {f['scenario']} | {f['difficulty']} | {f['expected']} | {f['observed']} |" for f in r["failures"]]
    else:
        L.append("None.")
    L += ["", "## Provider comparison (guard effectiveness)", "", "| Provider | Cases | Rejected by guards | Defective outputs accepted |", "|---|---|---|---|"]
    for k, v in r["provider_comparison"].items():
        L.append(f"| {k} | {v['cases']} | {v['rejected_by_guards']} | {v['defective_outputs_accepted']} |")
    p = r["prompt_version_comparison"]
    L += ["", "## Prompt-version regression", "",
          f"{p['from']} -> {p['to']} on {p['cases']} cases: pass {p['pass_from']} -> {p['pass_to']}; regressions: {p['regressions'] or 'none'}; fixes: {p['fixes'] or 'none'}.",
          "", "## Caveats", ""] + [f"- {c}" for c in r["caveats"]]
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")


_CSS = ("body{font:15px system-ui,sans-serif;margin:0;padding:16px;max-width:900px;margin:auto;color:#1a1a1a;background:#fff}"
        "h1{font-size:20px}h2{font-size:16px;margin-top:24px}table{border-collapse:collapse;width:100%;font-size:13px}"
        "th,td{border:1px solid #ccc;padding:5px 8px;text-align:left}th{background:#f2f2f2}.warn{background:#fff3cd;padding:10px;border-radius:6px}"
        ".ok{color:#1a7f37}.bad{color:#b42318}@media(prefers-color-scheme:dark){body{background:#111;color:#eee}th{background:#222}td,th{border-color:#444}.warn{background:#3a3000}}")


def write_dashboard(r, path):
    e = html.escape
    rows = "".join(f"<tr><td>{e(k)}</td><td>{v['cases']}</td><td>{v['passed']}</td><td>{pct(v['pass_rate'])}</td></tr>" for k, v in sorted(r["by_scenario"].items()))
    fails = "".join(f"<tr><td>{e(f['case_id'])}</td><td>{e(f['scenario'])}</td><td>{e(f['difficulty'])}</td><td>{e(f['expected'])}</td><td class='bad'>{e(f['observed'])}</td></tr>" for f in r["failures"]) or "<tr><td colspan=5>None</td></tr>"
    prov = "".join(f"<tr><td>{e(k)}</td><td>{v['cases']}</td><td>{v['rejected_by_guards']}</td><td>{v['defective_outputs_accepted']}</td></tr>" for k, v in r["provider_comparison"].items())
    m = [("Contradiction F1", r["contradiction_detection"]["f1"]), ("Abstention F1", r["abstention"]["f1"]),
         ("Numeric error rate", r["numeric"]["numeric_error_rate"]), ("Unsupported-claim rate", r["hallucination"]["unsupported_claim_rate"]),
         ("Source attribution", r["source_attribution"]["source_attribution_accuracy"]), ("Adversarial handled", r["robustness"]["handled_rate"])]
    mrows = "".join(f"<tr><td>{e(a)}</td><td>{pct(b)}</td></tr>" for a, b in m)
    doc = (f"<!doctype html><html lang=en><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'>"
           f"<title>Kaushal Radar AI evaluation</title><style>{_CSS}</style><h1>Kaushal Radar - AI evaluation dashboard</h1>"
           f"<p class=warn><b>SYNTHETIC cases, constructed labels.</b> Generated from evaluation/results.json by evaluation/report.py; "
           f"nothing here is computed in the browser. Not evidence of real-world accuracy.</p>"
           f"<p>{r['overall']['passed']} / {r['dataset']['cases']} cases behaved as labelled; <b class=bad>{r['overall']['failed']} failed</b> (listed below).</p>"
           f"<h2>Key metrics</h2><table><tr><th>Metric</th><th>Value</th></tr>{mrows}</table>"
           f"<h2>By scenario</h2><table><tr><th>Scenario</th><th>Cases</th><th>Passed</th><th>Rate</th></tr>{rows}</table>"
           f"<h2>Failures</h2><table><tr><th>Case</th><th>Scenario</th><th>Difficulty</th><th>Expected</th><th>Observed</th></tr>{fails}</table>"
           f"<h2>Provider comparison</h2><table><tr><th>Provider</th><th>Cases</th><th>Rejected by guards</th><th>Defective accepted</th></tr>{prov}</table>"
           f"<h2>Caveats</h2><ul>{''.join('<li>' + e(c) + '</li>' for c in r['caveats'])}</ul></html>")
    with open(path, "w", encoding="utf-8") as f:
        f.write(doc)
