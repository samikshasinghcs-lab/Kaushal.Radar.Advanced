"""Factual accuracy on accepted outputs: do expected (independently computed) facts appear?"""
from .metrics_util import rate


def compute(results):
    acc = [r for r in results if r["observed"] == "ACCEPT" and r["metrics"]["facts_expected"]]
    exp = sum(r["metrics"]["facts_expected"] for r in acc)
    found = sum(r["metrics"]["facts_found"] for r in acc)
    return {"cases_evaluated": len(acc), "expected_facts": exp, "facts_found": found, "factual_recall": rate(found, exp),
            "note": "Facts are independently re-computed by the dataset generator; subjective language quality is NOT assessed (needs human review)."}
