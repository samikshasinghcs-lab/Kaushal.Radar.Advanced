"""Regression testing across prompt versions, providers and stored baselines."""
import json
import os

from .fault_injection import MutatingProvider, SLOPPY_MODES
from .harness import run_case

HERE = os.path.dirname(os.path.abspath(__file__))
BASELINE = os.path.join(HERE, "baseline_results.json")


def compare(baseline, current):
    b = {r["case_id"]: r["passed"] for r in baseline}
    c = {r["case_id"]: r["passed"] for r in current}
    return {"regressions": sorted(k for k in c if k in b and b[k] and not c[k]),
            "fixes": sorted(k for k in c if k in b and not b[k] and c[k]),
            "new_cases": sorted(k for k in c if k not in b), "removed_cases": sorted(k for k in b if k not in c)}


def save_baseline(results, path=BASELINE):
    with open(path, "w") as f:
        json.dump([{"case_id": r["case_id"], "passed": r["passed"], "observed": r["observed"]} for r in results], f, indent=1)


def load_baseline(path=BASELINE):
    if not os.path.exists(path):
        return None
    with open(path) as f:
        return json.load(f)


def prompt_version_comparison(cases, to="1.1.0"):
    pool = [c for c in cases if not c["input"]["mutations"] and c["expected_behaviour"] in ("ACCEPT", "DETECT_CONTRADICTION", "FLAG_STALE", "FLAG_MISSING")]
    a = [run_case(c, prompt_overrides={"evidence_analyst": "1.0.0"}) for c in pool]
    b = [run_case(c, prompt_overrides={"evidence_analyst": to}) for c in pool]
    d = compare(a, b)
    return {"cases": len(pool), "from": "evidence_analyst@1.0.0", "to": f"evidence_analyst@{to}",
            "pass_from": sum(r["passed"] for r in a), "pass_to": sum(r["passed"] for r in b), **d}


def provider_comparison(cases):
    pool = [c for c in cases if c["scenario"] in ("clean_evidence", "conflicting_evidence")]
    out = {}
    base = [run_case(c) for c in pool]
    out["mock_clean"] = {"cases": len(pool), "accepted_valid": sum(r["observed"] != "REJECT_OUTPUT" and r["passed"] for r in base),
                         "rejected_by_guards": sum(r["observed"] == "REJECT_OUTPUT" for r in base), "defective_outputs_accepted": 0}
    for mode, muts in SLOPPY_MODES.items():
        res = [run_case(c, provider=MutatingProvider(muts)) for c in pool]
        rej = sum(r["observed"] == "REJECT_OUTPUT" for r in res)
        out[mode] = {"cases": len(pool), "accepted_valid": 0, "rejected_by_guards": rej, "defective_outputs_accepted": len(pool) - rej}
    return out
