"""Hallucination evaluation: unsupported claims in accepted outputs + detection of injected ones."""
from .metrics_util import prf, rate


def compute(results):
    acc = [r["metrics"] for r in results if r["observed"] == "ACCEPT"]
    ct, cu = sum(m["claims_total"] for m in acc), sum(m["claims_unsupported"] for m in acc)
    h = [r for r in results if r["scenario"] in ("unsupported_conclusion", "prohibited_recommendation")]
    tp = sum(1 for r in h if r["observed"] == "REJECT_OUTPUT" and r["passed"])
    return {"claims_in_accepted_outputs": ct, "unsupported_claims_in_accepted_outputs": cu, "unsupported_claim_rate": rate(cu, ct),
            "injected_hallucination_detection": prf(tp, 0, len(h) - tp), "injected_cases": len(h)}
