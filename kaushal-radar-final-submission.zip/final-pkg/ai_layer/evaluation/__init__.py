"""AI evaluation laboratory (SYNTHETIC, constructed cases). See docs/EVALUATION_REPORT.md for limits."""
