"""Runs a labelled case through the REAL pipeline and checks it against construction-time labels."""
import json
import secrets
from datetime import date

from ai.config import Config
from ai.evidence_store import EvidenceStore, SOURCES, make_record, peer_raw, records_from_raw, METRICS
from ai.master_pipeline import KaushalAIPipeline
from ai.provider import MockProvider, ProviderManager, RateLimiter
from evaluation.fault_injection import MutatingProvider
from security.access_control import UserDirectory

BLOCK = {"REJECTED_INPUT", "REJECTED_INJECTION", "REJECTED_PRIVACY"}
DENY = {"ACCESS_DENIED", "AUTH_FAILED"}


def build_store(inp):
    did = inp["store_district"]
    recs = []
    for pd, raw in peer_raw(7).items():
        if pd != did:
            recs += records_from_raw(pd, raw)
    if not inp.get("no_records"):
        for m in METRICS:
            if m in inp["raw"] and m not in inp["remove_metrics"]:
                v = -5 if inp.get("invalid_values") else inp["raw"][m]
                recs.append(make_record(did, m, v, as_of=inp["record_as_of"].get(m, "2026-06-30"), notes=inp.get("all_notes", "")))
    for spec in inp["extra_records"]:
        s = dict(spec)
        recs.append(make_record(did, s.pop("metric"), s.pop("value"), **s))
    return EvidenceStore(recs, dict(SOURCES))


def build_pipeline(case, prompt_overrides=None, provider=None, config=None):
    inp = case["input"]
    cfg = config or Config(max_retries=2, prompt_overrides=prompt_overrides or {})
    d = UserDirectory()
    u = inp["user"]
    tok = d.register("eval_user", u["role"], u["districts"])
    if inp["token"] == "invalid":
        tok = "invalid-" + secrets.token_hex(8)
    prov = provider or (MutatingProvider(inp["mutations"]) if inp["mutations"] else MockProvider())
    pm = ProviderManager(prov, cfg, sleep=lambda s: None, rate_limiter=RateLimiter(100000))
    p = KaushalAIPipeline(build_store(inp), d, pm, config=cfg, reference_date=date.fromisoformat(inp["reference_date"]))
    return p, tok


def observed_label(resp):
    s = resp["status"]
    if s in BLOCK:
        return "BLOCK_INPUT"
    if s in DENY:
        return "DENY_ACCESS"
    if s == "FAILED_PROVIDER":
        return "FAIL_CLOSED"
    if s == "ABSTAINED":
        return "ABSTAIN"
    return "ACCEPT" if resp["validation"]["passed"] else "REJECT_OUTPUT"


def violation_codes(resp):
    return sorted({v["code"] for t in resp.get("validation", {}).get("per_task", {}).values() for v in t["violations"]})


def _claims(resp, section=None):
    out = []
    for s in (resp.get("brief") or {}).get("sections", []):
        if section is None or s["section"] == section:
            out += s["claims"]
    return out


def _close(a, b, rel=0.005, ab=0.01):
    return abs(a - b) <= max(ab, rel * max(abs(a), abs(b)))


def check_case(case, resp):
    exp, obs = case["expected_behaviour"], observed_label(resp)
    facts = case["expected_facts"]
    of = lambda t: [f for f in facts if f["type"] == t]
    an = resp.get("analysis", {})
    ok, why = True, []

    def need(cond, msg):
        nonlocal ok
        if not cond:
            ok = False
            why.append(msg)
    need(obs == exp or (exp in ("DETECT_CONTRADICTION", "FLAG_STALE", "FLAG_MISSING", "FLAG_DENOMINATOR", "LOW_CONFIDENCE",
                                "QUARANTINE_EVIDENCE", "WITHHOLD_RESTRICTED") and obs == "ACCEPT"), f"observed {obs}, expected {exp}")
    if not ok:
        return ok, obs, "; ".join(why)
    if exp == "ACCEPT":
        for f in of("flag_status"):
            need(an["flag"]["status"] == f["value"], "flag status mismatch")
        need(not an["contradictions"] or case["expected_contradictions"], "unexpected contradictions")
    elif exp == "REJECT_OUTPUT":
        codes = violation_codes(resp)
        for f in of("violation_code"):
            need(f["code"] in codes, f"expected violation {f['code']}, got {codes}")
    elif exp == "ABSTAIN":
        rc = resp["abstention"]["reason_codes"]
        for f in of("abstain_reason"):
            need(f["code"] in rc, f"expected reason {f['code']}, got {rc}")
        for f in of("missing_metric"):
            need(f["metric"] in resp["abstention"]["missing_metrics"], "missing metric not reported")
        need(resp["decision"]["status"] == "INSUFFICIENT_EVIDENCE" and not resp["brief"]["sections"], "abstention must produce no AI sections")
    elif exp == "BLOCK_INPUT":
        for f in of("error_code"):
            need(resp["error"]["code"] == f["code"], f"error code {resp['error']['code']} != {f['code']}")
    elif exp == "DETECT_CONTRADICTION":
        got = {(c["type"], c["metric"]) for c in an["contradictions"]}
        for f in of("contradiction"):
            need((f["contradiction_type"], f["metric"]) in got, f"contradiction not detected: {f} in {got}")
        need({c["type"] for c in an["contradictions"]} == set(case["expected_contradictions"]), "contradiction type set differs")
        cited = {e for c in _claims(resp, "contradiction_analyst") for e in c["evidence_ids"]}
        for s in case["expected_sources"]:
            need(s in cited, f"AI claims do not cite {s}")
    elif exp == "FLAG_STALE":
        ids = {s["evidence_id"] for s in an["stale"]}
        txt = " ".join(c["text"] for c in _claims(resp, "uncertainty_explainer"))
        for f in of("stale_evidence"):
            need(f["evidence_id"] in ids, "stale evidence not detected")
            need(f["evidence_id"] in txt, "uncertainty text does not mention stale evidence")
        for f in of("decision_status"):
            need(resp["decision"]["status"] == f["value"], f"decision {resp['decision']['status']} != {f['value']}")
        for f in of("decision_status_not"):
            need(resp["decision"]["status"] != f["value"], "stale secondary must not force a quality hold")
    elif exp == "FLAG_MISSING":
        txt = " ".join(c["text"] for c in _claims(resp, "uncertainty_explainer"))
        for f in of("missing_optional"):
            need(f["metric"] in an["missing_optional"] and f["metric"] in txt, "missing optional metric not reported")
    elif exp == "FLAG_DENOMINATOR":
        for f in of("denominator_change"):
            need(any(d["metric"] == f["metric"] for d in an["denominator_changes"]), "denominator change not detected")
        for f in of("flag_flips"):
            need(any(v["flips"] for v in an["sensitivity"]["vacancy_scenarios"]) == f["value"], "flag-flip expectation differs")
        need({c["type"] for c in an["contradictions"]} == set(case["expected_contradictions"]), "contradiction type set differs")
    elif exp == "LOW_CONFIDENCE":
        need(an["confidence"]["level"] == "LOW" and resp["brief"]["confidence"] == "LOW", "confidence not LOW")
    elif exp == "QUARANTINE_EVIDENCE":
        quar = {e["evidence_id"] for e in resp["provenance"]["excluded"] if e["reason"] == "QUARANTINED_INJECTION"}
        for f in of("quarantined"):
            need(f["evidence_id"] in quar, "injected evidence not quarantined")
            need(f["evidence_id"] not in {e for c in _claims(resp) for e in c["evidence_ids"]}, "quarantined evidence cited")
        need("ignore" not in " ".join(c["text"] for c in _claims(resp)).lower(), "injected text leaked into claims")
    elif exp == "WITHHOLD_RESTRICTED":
        for f in of("withheld_evidence"):
            need(f["evidence_id"] not in resp["provenance"]["evidence_ids"], "restricted evidence reached the model context")
            need(f["evidence_id"] not in {e for c in _claims(resp) for e in c["evidence_ids"]}, "restricted evidence cited")
        need(resp["provenance"]["restricted_withheld_count"] >= 1 and not an["contradictions"], "restricted handling wrong")
    return ok, obs, "; ".join(why)


def case_metrics(case, resp, obs):
    """Independent numeric / attribution / unsupported-claim measurements on ACCEPTed outputs."""
    m = {"numeric_total": 0, "numeric_wrong": 0, "numeric_unverified": 0, "claims_total": 0, "claims_unsupported": 0,
         "facts_expected": 0, "facts_found": 0, "sources_expected": 0, "sources_found": 0}
    if obs != "ACCEPT":
        return m
    exp_nums = {f["ref"]: f["value"] for f in case["expected_facts"] if f["type"] == "number"}
    got = []
    inp = case["input"]
    allowed = set(case["allowed_evidence_ids"]) | {f"EV_{inp['store_district'][-3:]}_{x['metric'].upper()}{x.get('suffix', '')}"
                                                   for x in inp["extra_records"]}
    cited = set()
    for c in _claims(resp):
        if c["kind"] in ("fact", "interpretation"):
            m["claims_total"] += 1
            if any(e not in allowed for e in c["evidence_ids"]):
                m["claims_unsupported"] += 1
        cited |= set(c["evidence_ids"])
        for n in c["numbers"]:
            if n["ref"] in exp_nums:
                m["numeric_total"] += 1
                got.append((n["ref"], n["value"]))
                if not _close(n["value"], exp_nums[n["ref"]]):
                    m["numeric_wrong"] += 1
            else:
                m["numeric_unverified"] += 1
    req = {f["ref"]: f["value"] for f in case["expected_facts"] if f["type"] == "number" and f.get("required", True)}
    m["facts_expected"] = len(req)
    m["facts_found"] = sum(1 for r, v in req.items() if any(g == r and _close(gv, v) for g, gv in got))
    m["sources_expected"] = len(case["expected_sources"])
    m["sources_found"] = sum(1 for s in case["expected_sources"] if s in cited)
    return m


def run_case(case, prompt_overrides=None, provider=None, config=None):
    p, tok = build_pipeline(case, prompt_overrides, provider, config)
    resp = p.handle_request(tok, case["input"]["payload"])
    ok, obs, why = check_case(case, resp)
    metrics = case_metrics(case, resp, obs)
    if metrics["numeric_wrong"]:
        ok, why = False, (why + "; " if why else "") + "accepted output disagrees with independently computed numbers"
    if metrics["claims_unsupported"]:
        ok, why = False, (why + "; " if why else "") + "accepted output cites evidence outside the labelled allowed set"
    pred = {"contradiction": bool(resp.get("analysis", {}).get("contradictions")),
            "stale": bool(resp.get("analysis", {}).get("stale")),
            "abstain": obs == "ABSTAIN", "blocked": obs in ("BLOCK_INPUT", "DENY_ACCESS", "FAIL_CLOSED", "REJECT_OUTPUT")}
    return {"case_id": case["case_id"], "scenario": case["scenario"], "difficulty": case["difficulty"],
            "severity": case["severity"], "expected": case["expected_behaviour"], "observed": obs, "passed": ok,
            "detail": why, "defect": case["defect_injected"], "violation_codes": violation_codes(resp),
            "pred": pred, "metrics": metrics}


def load_dataset(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]
