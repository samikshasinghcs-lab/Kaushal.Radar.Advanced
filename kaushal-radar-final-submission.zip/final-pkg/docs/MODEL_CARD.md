# Model card and AI-use register
Status: DRAFT. Not independently reviewed. Verify legal references against the official DPDP Act 2023 and Rules text before relying on them.

**Purpose:** draft district briefs and answer questions from stored evidence. It cannot approve, fund or change status.
**Current implementation:** deterministic mock analysts. A live LLM run on all 31 districts and a blind test set are NOT_RUN. Report results even if AI adds nothing over rules.
**Inputs:** aggregate district indicators only. No personal data. Retrieved text is treated as untrusted (prompt-injection scan, v0.2 adds paraphrase and Hinglish patterns, still heuristic).
**Guards:** schema validation, source grounding, numeric check, abstention, human approval gate.
**Known limits:** injection detection is pattern-based; hard cases can still pass. Evaluation cases are synthetic, so accuracy figures are prototype evidence only.
**Fairness check (PROPOSED):** compare flag rates across KK vs non-KK districts and across denominators; log disagreements. Individual-level fairness cannot be tested because no individual data is held.

| AI use | Human oversight | Status |
|---|---|---|
| Brief drafting | Officer reads and approves | mock |
| Question answering | Abstains when evidence is missing | mock |
| Skill extraction | Sample text only | SYNTHETIC |
| Recommendation card | Officer approves/returns/rejects | built, human gate tested |
