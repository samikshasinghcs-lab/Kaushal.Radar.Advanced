# Changes in v0.3
- Real AISHE 2023-24 workbook ingested (state level). PLFS Karnataka benchmarks logged with sources; unverified rows marked.
- evidence_analyst@1.1.0 regression fixed; 1.2.0 kept only as a labelled test fixture.
- API now uses signed tokens, rate limits and lockout; new endpoints; decision endpoint enforces the gate.
- Durable store, job queue, backup/restore, Postgres SQL (not run), CI secret scan, ZAP workflow (not run).
- Held-out result for the labour claim checker is 6/10; the tuned-set score is optimistic and labelled so.
