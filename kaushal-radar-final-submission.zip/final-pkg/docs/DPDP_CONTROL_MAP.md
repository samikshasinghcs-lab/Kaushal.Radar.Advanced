# DPDP clause-to-control map
Status: DRAFT. Not independently reviewed. Verify legal references against the official DPDP Act 2023 and Rules text before relying on them.

| DPDP Act 2023 area | Control in Kaushal Radar | Where | Status |
|---|---|---|---|
| s.5 Notice | Purpose and data-source labels on every card | dashboard, data contract | BUILT_WITH_LIMITATIONS |
| s.6 Consent / s.7 legitimate uses | Consent log, ingestion refused without active consent; state-function basis to be confirmed by Legal | core/retention.py | BUILT_WITH_LIMITATIONS |
| s.8(4)-(5) Security safeguards | RBAC, signed tokens, rate limit, lockout, encryption at rest, TLS test, hash-chained audit with tail anchor | security.py, auth_tokens.py, audit_anchor.py | BUILT_WITH_LIMITATIONS |
| s.8(6) Breach intimation | Breach runbook | docs/BREACH_RUNBOOK.md | PROPOSED process |
| s.8(7) Erasure when purpose served | Retention periods and logged purge | retention.py | BUILT_WITH_LIMITATIONS |
| Data minimisation | PII column block, aggregates only, small cells (<10) suppressed | security.py, ingest.py | BUILT_WITH_LIMITATIONS |
| s.9 Children | No individual-level data accepted | ingest.py | BUILT_WITH_LIMITATIONS |
| s.10 Significant fiduciary duties (DPIA, audit) | DPIA draft; independent audit | docs/DPIA.md | NOT_RUN (human) |
| s.13 Grievance redressal | Contact route to be named by the department | n/a | PROPOSED |
