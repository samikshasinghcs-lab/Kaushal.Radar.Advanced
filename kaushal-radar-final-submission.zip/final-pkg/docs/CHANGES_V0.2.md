# Changes in v0.2
- Dashboard base now uses the stricter Corroboration Gate (self-declared corroboration is rejected and the attempt is logged), plus the Implied-vs-Census rank-difference flag.
- Not ported: the standalone's AI-drafted brief card (no verified live-LLM run in this bundle) and the Clear demo entries button.
- New modules, governance code and documents listed in README. Claims register has PENDING_SOURCE_PULL rows that need real sources.
