# Changes since the submitted zip
1. core/ai_eval.py: rank check added (ordinal must match the engine rank for the basis the sentence names). Brief-checker injected-hallucination catch 65/69 -> 69/69; genuine drafts unchanged (27 pass / 1 review / 3 false rejects). CAVEAT: tuned on the same 69 cases, so this is a regression fix, NOT held-out accuracy. A blind set is still needed.
2. core/api_server.py: connection backlog 5 -> 256 and per-district rank-stability cached (it re-ran a 500-draw simulation on every gate call).
3. core/load_test.py (new): before fix at 100 clients: 10/2000 requests failed, p95 2.1 s. After: 200 clients, 4,000 requests, 0 errors, p95 149 ms, audit chain valid. Single process on one machine, local loopback, mock gate evidence; not a production load test.
4. analysis/: routing scatter + seat-allocation comparison.
Update slide 4 numbers (65/69 -> 69/69, with the tuning caveat) before presenting.
