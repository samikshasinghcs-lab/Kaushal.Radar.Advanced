# DPIA (draft)
Status: DRAFT. Not independently reviewed. Verify legal references against the official DPDP Act 2023 and Rules text before relying on them.

**Processing:** district aggregates from public tables; optional authorised department files (aggregates only).
**Personal data:** none by design; PII columns are rejected at ingestion.
**Risks:** re-identification from small cells (mitigated by k=10 suppression); misuse of rankings as funding decisions (mitigated by gate and human approval); stale or mixed-definition data (mitigated by labels and compatibility checks); AI error (grounding and abstention).
**Residual risk:** prototype security not independently tested. DPIA reviewer: NOT_RUN.
