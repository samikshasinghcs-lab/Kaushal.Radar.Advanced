# Architecture (matches the code; `core/test_architecture.py` fails if a named module disappears)

```mermaid
flowchart LR
  subgraph Sources
    A1[DES Karnataka / Yuvanidhi / Census 2011: real, annual]
    A2[AISHE 2023-24 workbook: real, state level]
    A3[PLFS tables: state level]
    A4[NCS / EPFO / MCA / e-Shram: BLOCKED_PENDING_DATA]
  end
  A1 --> P[pipeline.py + data_quality.py]
  A2 --> AD[adapters/aishe_state.py + adapters/sources.py]
  A3 --> AD
  A4 -.mock only.-> MK[mock_dpi.py]
  AD --> P
  P --> ST[(store.py: idempotent refresh, job queue, backup/restore)]
  ST -.same model.-> PG[(schema_postgres.sql: not run)]
  ST --> ENG
  subgraph ENG[Engines]
    LI[labour_intelligence.py: two-sided + flags]
    FE[flag_engine.py: 12 flags]
    LM[labour_market.py / employment_intelligence.py / business_intelligence.py]
    SK[skills_transition.py / workforce_inclusion.py / national_benchmarking.py]
    FC[forecasting.py]
  end
  ENG --> CG[corroboration.py: gate for every engine]
  CG --> IE[intervention_engine.py: drafts, human decision, outcome]
  IE --> LG[(Ledger + audit_anchor.py)]
  IE --> API[api_server.py: signed tokens, rate limit, RBAC]
  API --> UI[Dashboard 19 views]
  API --> OA[OpenAPI v0.3 / Postman / Swagger]
  AI[ai_layer: grounded briefs, injection scan] --> API
  FR[fairness.py] --> API
  BT[backtest.py: needs 2 periods] --> IE
```
Human steps outside the diagram: officer approval, usability test, independent security review, data agreements.
