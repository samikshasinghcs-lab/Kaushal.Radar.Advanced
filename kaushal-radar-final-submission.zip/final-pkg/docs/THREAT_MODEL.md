# Threat model (STRIDE, draft)
Status: DRAFT. Not independently reviewed. Verify legal references against the official DPDP Act 2023 and Rules text before relying on them.

| Threat | Example | Control | Gap |
|---|---|---|---|
| Spoofing | Forged role header | Signed tokens, expiry, alg pinned | Key management, SSO |
| Tampering | Edit or truncate audit | Hash chain + HMAC tail anchor | Anchor must live in separate write-once store |
| Repudiation | Officer denies decision | Ledger records actor and role | |
| Information disclosure | District officer reads other district | Scope check, small-cell suppression | Pen test NOT_RUN |
| Denial of service | Request flood | Rate limit, lockout | Gateway-level limits |
| Elevation | Role escalation | Deny-by-default RBAC | |
| Prompt injection | Poisoned evidence text | Quarantine, schema, human gate | Heuristic detector |
