# Breach runbook (draft)
Status: DRAFT. Not independently reviewed. Verify legal references against the official DPDP Act 2023 and Rules text before relying on them.

1. Contain: revoke tokens, rotate KR_JWT_SECRET, stop ingestion.
2. Assess: use the audit ledger to list affected objects; check anchor for truncation.
3. Notify: department data owner and the competent authority as the Act and Rules require (confirm timelines with Legal).
4. Recover: restore from backup, re-verify ledger chain.
5. Review: add a regression test; record in the ledger.
